########################################################################
########################################################################
##### File: HatterBot version 1.4.0                                #####
##### by: 0rx                                                      #####
##### http://remaire.chatango.com 				   #####
##### http://tango-hyoo.chatango.com 				   #####
##### This bot script is made with the help of some great friends  #####
##### with that, this bot is made for educational purposes only.   #####
##### You're free to copy this script as long as you credit those  #####
##### people below.                                                #####
##### Credits:    - Poeticartist1 (Owner of Nadashiki)             #####
#####             - TryHardHusky(Horny Bot Maker)                  #####
#####             - Thelorgorenk(Author)                           #####
#####             - Agunq(Fellow Bot Maker)                        #####
#####             - Peoples from http://khususme.chatango.com      #####
########################################################################
########################################################################
  

## YOU WILL NEED THE ch2.PY TO RUN THIS BOT!
## YOU CAN GET IT FROM HERE http://pastebin.com/MBwdSZsW
import ch2  
import random
import sys
import os
import re
import cgi
import codecs
import traceback
import time
import datetime
import urllib
import binascii
import json
import __future__

##############################################################
lockdown = False
activated = True
##############################################################
## Timer Stuff ###############################################

startTime = time.time()

##     End     ###############################################
##############################################################

##############################################################
## rpg variables
 ############################################
##############################################################


## rpg mode
rpgbool = False #boolean - a true of false variable - 
bossparty=False #boolean - a true of false variable - used to test if rpg battle is active
bossdead=True
boss=""
bosslife=0

#weapon and monster list

weaponlist=["Buster Sword","Battle Axe","Bow and Arrow","LongSword","Spear","Ice Sword","Vorpal Sword","fire sword","flamberge","Gunblade","Wooden Staff","Mage Staff","Battle Axe","War Hammer","Flame Dragon Sword"]
monsterlist=["Imperial soldier","WolfBeast","Imp","Incubus","Electric Blob","Spinnaroug","Fenrir","Kyuubi","Undine","Efreet","Shadow","Volt","Flameberge","Gnome","Luna","Sol","Ninja","BigSpider","FlyingSword","LivingSword","IceWolf","FireWolf","BabyDragon","BigDragon","IceDragon","LightingDragon","FireDragon","Leviathan","Chocobo","Titan","LightingWolf","DarkWolf","DarkDragon","Bahamut","Asura","Mindflayer","Sylph","Whyt","Remora","Golem","Syldra","Phoenix","Carbuncle","Kirin","Bismarck","CaithSith","Catoblepas","Alexander","Raiden","Phantom","Unicorn","Siren","Midgardsormr","Lakshmi","Seraph","Scizor","Quetzalli","Crusader","Valigarmanda","KnightsOfTheRound","Kjata","Typhoon","Hades","Quezacotl","Pandemona","Panda","Cerberus","Souleaterleon","Ark","Atomos","Anima","Ixion","Valefor","TheMagusSisters","Yojimbo","Belias","Mateus","Adrammeclech","Zalera","Shemhazai","Hashmal","Zeromus","Exodus","Cuchulainn","Famfrit","Chaos""Ultima","Zodiark","Alraune","Garchimacera","Glacies","Tenebrea","Ignis","Ventus","Solum","Lumen","Tonitrus","Agua","Jp","Aska","Celsuis","Maxwel","Martel","Corrine","Ratatosk"]
highdemons=["Ragnarock","Zehel","Leviathan","Hades","Lucifer","Belphegor","Hitotsume","Astaroth","King Paimon","Azazel","Diablo","Mephisto","Zahard","Golliath","Dremora","Ignitazel","Cerberus","Belial","Legion","Judah","Cain","Nero","Draco","Fellaises","Crux","Dagan"]
lowdemons=["Succubus","Andriel","Tierra","Gargoyle","Rikishi","Cormetrax","Glorriette","Thundergale","Midnite","Pledias","Topheliorcs","Gremillions","Gremli","Tartaros","Reamorex","Celts","Kelper","Blood-Elf","Dark Bertha","Champion Crux","Hellscale","Treiath","Plesseoth","Dimereas","Flare","Frosticque","Temir","Faramir","Lettisseus","Seth","War","Pestillence","Death","cyrix"]
gods=["Tyrael","Michael","Gabriel","Totemis","Hermes","Mr.Bean","Bishamonten","Yakou","Amaterasu","Susanoo","Batousai","Spitfire","Gabishi","Gilgamesh","Aura","Urek Mazino"]
bosslist=["Lich King","Lightning Hero","Biohazard","Flame Emperor"]
maps=["Heaven","World","Hell"]
city=["Remaire","Deandled Ben","Greek","Skyrocks","Arpenia","Dragillia","Rifullian","Penwood","Winter Country"]

## End #######################################################
##############################################################

##############################################################
## File Stuff ################################################

## Love Meter Logs
def lomet(args):
 lomet = dict()
 f = open("lovelog.txt", "r")
 for line in f.readlines():
  try:
    if len(line.strip())>0:
      user1, meter = json.loads(line.strip())
      lomet[user1] = json.dumps(meter)
  except:
    print("fails")
 f.close()

# SN Notifs
def notif(args):
 notif = []
 f = open("notif.txt", "r")
 print("[INF]Loading Notifs...")
 for name in f.readlines():
   if len(name.strip())>0: notif.append(name.strip())
 f.close

## Last Seen History
def roomhist(args):
 filename = "roomhist.txt"#the text file you need to have in same place as bot
 hist = dict()
 f = open(filename, 'r') #open status.txt and make a writing variable called file
 print("[INF]LOADING ROOMHIST")#print to console
 time.sleep(1)#pause for one second
 for line in f.readlines():
   if len(line.strip())>0:
    nama, waktu, ruang, body = json.loads(line.strip())
    hist[nama] = json.dumps([waktu, ruang, body])
 f.close()#close the file

## ROOMLOG
def roomlog(args):
 filename = "roomlog.txt"#the text file you need to have in same place as bot
 roomlog =[]
 f = open(filename, 'r') #open status.txt and make a writing variable called file
 print("[INFO]LOADING ROOMLOG")#print to console
 time.sleep(1)#pause for one second
 for name in f.readlines():
   if len(name.strip())>0: roomlog.append(name.strip())
 f.close()#close the file

## PMLOG
def pmlog(args):
 filename = "pmlog.txt"#the text file you need to have in same place as bot
 pmlog=[]
 f = open(filename, 'r') #open status.txt and make a writing variable called file
 print("[INFO]LOADING PMLOG")#print to console
 time.sleep(1)#pause for one second
 for name in f.readlines():
   if len(name.strip())>0: pmlog.append(name.strip())
 f.close()#close the file

## Main RPG
def rpg(args):
 rpg = dict()
 f = open("rpg/rpg.txt", "r") # read-only
 print("[INF]Loading RPG...")
 time.sleep(1)
 for line in f.readlines():
  try:
    if len(line.strip())>0:
      user,weapon,hp,lvl,exp= json.loads(line.strip())
      rpg[user] = json.dumps([weapon,hp,lvl,exp])
  except:
    print("[ERROR]Cant load rpg: %s" % line)
 f.close()

## RPG City
def city(args):
 city = dict()
 f = open("rpg/city.txt", "r")
 for line in f.readlines():
  try:
    if len(line.strip())>0:
      user, town = json.loads(line.strip())
      city[user] = json.dumps([city])
  except:
    print("error city")
 f.close()

## RPG Money
def flicks(args):
 flicks = dict()
 f = open("rpg/flicks.txt", "r")
 for line in f.readlines():
  try:
    if len(line.strip())>0:
      user, coins = json.loads(line.strip())
      flicks[user] = json.dumps([coins])
  except:
    print("error flicks")
 f.close()

## RPG Inventory
def inven(args):
 inven = dict()
 f = open("rpg/inven.txt", "r")
 for line in f.readlines():
  try:
    if len(line.strip())>0:
      user, inv[items] = json.loads(line.strip())
      inven[user] = json.dumps(items)
      items = []
      for name in items.readlines():
        if len(name.strip())>0: bosshunt.append(name.strip())
  except:
    print("error inven")
 f.close()

## Map status
def maps(args):
 maps = dict()
 f = open("rpg/maps.txt", "r")
 for line in f.readlines():
  try:
    if len(line.stip())>0:
      user, mapstat = json.loads(line.strip())
      maps[user] = json.dumps(mapstat)
  except:
    print("error maps")
 f.close()

##Bosshunt
#bosshunt = []
#f = open("rpg/bosshunt.txt", "r")
#for line in f.readlines():
#  try:
#    if len(line.strip())>0:
#      boss, user = json.loads(line.strip())
#      bosshunt[boss] = json.dumps(user)
#f.close()

##Bosshunt
def bosshunt(args):
 bosshunt = []
 f = open("rpg/bosshunt.txt", "r")
 for name in f.readlines():
   if len(name.strip())>0: bosshunt.append(name.strip())
 f.close()

##Currentboss
def currentboss(args):
 currentboss = []
 f = open("rpg/currentboss.txt", "r")
 for name in f.readlines():
   if len(name.strip())>0: currentboss.append(name.strip())
 f.close()

##Boss Exp
def bossexp(args):
 bossexp = []
 f = open("rpg/bossexp.txt", "r")
 for name in f.readlines():
   if len(name.strip())>0: bossexp.append(name.strip())
 f.close()

##monsterhunt
def monhunt(args):
 monhunt = dict()
 f = open("rpg/monhunt.txt", "r")
 for line in f.readlines():
  try:
    if len(line.strip())>0:
      user, monster, monsterlife = json.loads(line.strip())
      monhunt[user] = json.dumps([monster, monsterlife])
  except:
    print("error monhunt")
 f.close()

## Total Monster Life
def tmonlife(args):
 tmonlife = dict()
 f = open("rpg/tmonlife.txt", "r")
 for line in f.readlines():
  try:
    if len(line.strip())>0:
      monster, monlife = json.loads(line.strip())
      tmonlife[monster] = json.dumps(monlife)
  except:
    print("error tmonlife")
 f.close()

##Monster Exp
def monexp(args):
 monexp = []
 f = open("rpg/monexp.txt", "r")
 for name in f.readlines():
   if len(name.strip())>0: monexp.append(name.strip())
 f.close()

## Nicknames
def nicks(args):
 nicks=dict()#empty list
 f=open ("Nicks.txt","r")#r=read w=right
 print ("[INF]Loading Nicks...")#print
 time.sleep(1)
 for line in f.readlines():#loop through eachline and read each line
    try:#try code
        if len(line.strip())>0:#strip the whitespace checkgreater than 0
            user , nick = json.loads(line.strip())
            nicks[user] = json.dumps(nick)
    except:
        print("[Error]Can't load nick %s" % line)

## definitions
def dict(args):
 dictionary = dict() #volatile..
 f = open("definitions.txt", 'r') #read-only
 print("[INF]Loading Definitions...")
 time.sleep(1)
 for line in f.readlines():
  try:
    if len(line.strip())>0:
      word, definitions, name = json.loads(line.strip())
      dictionary[word] = json.dumps([definitions, name])
  except:
    print("{ERROR]Cant load Definitions: %s" % line)
 f.close()

## Locks##
def locks(args):
 locks = []
 f = open("locks.txt", 'r')
 time.sleep(1)
 for name in f.readlines():
   if len(name.strip())>0: locks.append(name.strip())
 f.close()

##OWNER##
def spermitted(args):
 spermitted = []
 f = open("spermitted.txt", "r") #read-only
 print("[INF]Loading Supreme Masters...")
 time.sleep(1)
 for name in f.readlines():
   if len(name.strip())>0: spermitted.append(name.strip())
 f.close()

##MODS##
def permitted(args):
 permitted = []
 f = open("permitted.txt", "r")
 print("[INF]Loading Mods...")
 time.sleep(1)
 for name in f.readlines():
   if len(name.strip())>0: permitted.append(name.strip())
 f.close()

##Arch-Knights##
def hpermitted(args):
 hpermitted = []
 f = open("hpermitted.txt", "r") #read-only
 print("[INF]Loading Arch-Knights....")
 time.sleep(1)
 for name in f.readlines():
   if len(name.strip())>0: hpermitted.append(name.strip())
 f.close()

##Players##
def whitelist(args):
 whitelist = []
 f = open("whitelist.txt", "r") #read-only
 print("[INF]Loading Players...")
 time.sleep(1)
 for name in f.readlines():
   if len(name.strip())>0: whitelist.append(name.strip())
 f.close()

##Peeps##
def friend(args):
 friend = []
 f = open("friend.txt", "r") # read-only
 print("[INF]Loading Friends...")
 time.sleep(1)
 for name in f.readlines():
   if len(name.strip())>0: whitelist.append(name.strip())
 f.close()
#password
def password(args):
 password = "123"
##botname
def botname(args):
 botname = "Switchzer"
##Rooms##
def rooms(args):
 rooms = []
 f = open("rooms.txt", "r") #read-only
 print("[INF]Loading Rooms...")
 time.sleep(1)
 for name in f.readlines():
   if len(name.strip())>0: rooms.append(name.strip())
 f.close()

##deathlist
def dlist(args):
 dlist = []
 f = open("dlist.txt", "r")
 for name in f.readlines():
   if len(name.strip())>0: dlist.append(name.strip())
 f.close()

blacklist = ['botteh','mechabot','nadashiki','aqunq','justhoax','ragebot','illogic','vbotfun','mystou']
specials = ['thelorgorenk','sarashiki23','ampunganz','galaksi2','dovion','frizki','hide72','handikaecchihunter','padomo','kotezmyname','hime72']
def everything_between(text,begin,end):
 
    idx1=text.find(begin)
 
    idx2=text.find(end,idx1)
 
    return ' '.join(text[idx1+len(begin):idx2].strip().split())
  
def saveNicks():
    print("[SAVE] SAVING NICKS...")
    f = open("Nicks.txt", "w")
    for user in nicks:
        nick = json.loads(nicks[user])
        f.write(json.dumps([user, nick])+"\n")
    f.close()
   
def sntonick(username):
    user = username.lower()
    if user in nicks:
        nick = json.loads(nicks[user])
        return nick
    else:
        return user
## End #######################################################
##############################################################


##############################################################
## Define Stuff ##############################################


## End #######################################################
##############################################################

##############################################################
########          Mon Nov 18 2013 22:15:33 WIB        ########
##############################################################

if sys.version_info[0] > 2:
  import urllib.request as urlreq
else:
  import urllib2 as urlreq


##############################################################
## Time Stuff ################################################

def getUptime():
  """
  Returns the number of seconds since the programs started.
  """
  #do return startTime if you want the process start time

  return time.time() - startTime

## System Uptime
def uptime():

  try:
    f = open( "/proc/uptime")
    contents = f.read().split()
    f.close()
  except:
    return "Cannot open uptime file"

  total_seconds = float(contents[0])

  ## Helper vars:
  MINUTE = 60
  HOUR = MINUTE * 60
  DAY = HOUR * 24

  ## Get the days, hours, etc:
  days = int( total_seconds / DAY )
  hours = int( ( total_seconds % DAY ) / HOUR )
  minutes = int( ( total_seconds % HOUR ) / MINUTE )
  seconds = int( total_seconds % MINUTE )

  ## Build up the pretty string (like this: "N days. N hours, N minutes, N seconds")
  string = ""
  if days > 0:
    string += str(days) + " " + (days == 1 and "day" or "days" ) + ", "
  if len(string) > 0 or hours > 0:
    string += str(hours) + " " + (hours == 1 and "hour" or "hours" ) + ", "
  if len(string) > 0 or minutes > 0:
    string += str(minutes) + " " + (minutes == 1 and "minute" or "minutes" ) + ", "
  string += str(seconds) + " " + (seconds == 1 and "second" or "seconds" )

  return string;

## End #########################################################
################################################################

################################################################  
## Important TestBot Class #####################################
class TestBot(ch2.RoomManager):
  def onInit(self):
    self.setNameColor("FF9966")
    self.setFontColor("33CCFF")
    self.setFontFace("1")
    self.setFontSize(12)
    self.enableBg()  
    self.enableRecording()
   
  def saveAll(self):
    room = self._Room
    f = open("owner.txt", "w")
    f.write("\n".join(owner))
    f.close()
    f = open("mod.txt", "w")
    f.write("\n".join(mod))
    f.close()
    f = open("registered.txt", "w")
    f.write("\n".join(registered))
    f.close()
    f = open("blacklist.txt", "w")
    f.write("\n".join(blacklist))
    f.close()
    f = open("locks.txt", "w")
    f.write("\n".join(locks))
    f.close()
    f = open("rooms.txt", "w")
    f.write("\n".join(self.roomnames))
    f.close()
 
 
  def getAccess(self, user):
    room = self._Room
    if user.name in owner and not user.name in blacklist: return 5
    elif user.name in mod and not user.name in blacklist: return 4
    elif user.name in registered and user.name in room.ownername and not user.name in blacklist: return 3
    elif user.name in registered and user.name in room.modnames and not user.name in blacklist: return 2
    elif user.name in registered and not user.name in room.ownername and not user.name in room.modnames and not user.name in blacklist: return 1
    elif user.name in blacklist: return -1
    else: return 0

##############################################################
## Connecting and Disconnecting crap #########################
  
  def onConnect(self, room):
    print("[+] Mad Hatter Connected to "+room.name)
    
  def onReconnect(self, room):
    print("[+] Mad Hatter Reconnected to "+room.name), room.message("Reconnected")
    
  def onDisconnect(self, room):
    print("[+] Mad Hatter Disconnected from "+room.name)
    
  def onJoin(self, room, user):
    print("[+] "+user.name+" joined "+room.name)
    if lockdown: return
    if self.getAccess(user) == 5:
      time.sleep(2)
      room.message("*Bows down to "+ user.name +"*")
      return
   # if self.getAccess(user) == 3:
    #  time.sleep(2)
     # room.message("Arch Knight is present")
      #return
   # elif self.getAccess(user) == 4 and not user.name == "ramielsama":
    #  time.sleep(2)
     # room.message("Wellcome back "+sntonick(user.name)+" !!", True)
      #return
    elif user.name == "ramielsama":
      time.sleep(2)
      room.message("Wellcome back "+sntonick(user.name)+" ! *Hugs and kisses My Fallen Angel*", True)
      return
  def onConnectFail(self, room):
    print("[ERR} Room Not Found")
      
  def onBan(self, room, user, target):
    print("someone got banned in "+room.name)

## End #######################################################
##############################################################

##############################################################
## Setting up Commands #######################################
  
  def onMessage(self, room, user, message):
    global activated
    global lockdown
    ## rpg game
    global rpgbool
    #global monster
    #global monsterlife
    global bossparty
    global bosslist
    global boss
    global bosslife
    global bossdead
    #Print to console
    if room.getLevel(self.user) > 0:
      print("[%s]\033[94m[MSG]\033[0m\033[31m[LVL %s]\033[0m[%s][%s] %s: %s" % (time.strftime("%d/%m/%y- %H:%M:%S", time.localtime(time.time())), self.getAccess(user), room.name, message.ip, user.name.title(), message.body))
    else:
      print("[%s]\033[94m[MSG]\033[0m\033[31m[LVL %s]\033[0m[%s][%s] %s: %s" % (time.strftime("%d/%m/%y- %H:%M:%S", time.localtime(time.time())), self.getAccess(user), room.name, message.ip, user.name.title(), message.body))

    # SN Notif
    if user.name in notif and user.name in spermitted:
      room.message(user.name+", you got a note left unread. Do 'readnote to read it")
      notif.remove(user.name)

    ##RoomHist
    nama = user.name
    hist[nama] = json.dumps([(time.strftime("%d/%m/%y- %H:%M:%S", time.localtime(time.time()))), room.name, message.body])

    ##roomlog
    roomlog.append("[%s]\033[LVL %s]\033[%s] %s: %s" % (time.strftime("%d/%m/%y- %H:%M:%S", time.localtime(time.time())), self.getAccess(user), room.name, user.name.capitalize(), message.body))
    if user.name in dlist: return
    if self.user == user: return #ignore self(bot)
    if self.getAccess(user) < 4 and not activated: return #ignore everyone when in lockdown
    if user.name in blacklist: return #ignore blacklisted user
    if self.getAccess(user) < 3 and room.getLevel(user) < 1 and room.name in locks: return #ignore rank 1 and 2 when room locked
    if message.body.startswith(".") or message.body.startswith("?") or message.body.startswith(",") or message.body.startswith("!") or message.body.startswith(";"): return
   # if user.name in sasaran:
    #  room.message(+user.name+", you have %s note, do 'readnote to read it" % int(sasaran), True)
    if "'wl me" == message.body:
      if room.getLevel(user) < 1 and self.getAccess(user) == 0:
        friend.append(user.name)
        room.message(user.name+" can use me now. ^^")
      else: room.message("You're silly >_>")
    if "'help" == message.body:
      if room.getLevel(user) < 1 and self.getAccess(user) == 0:
        room.message("you can use me by typing 'wl me (include the single quote)")
      if room.getLevel(user) < 1 and self.getAccess(user) == 1:
        room.message("Your rank is 1 [Citizen] , You can see the available command by typing 'cmds (include the single quote) || If you're interested in using more of my commands, you can type 'register (include the single quote)")
      if room.getLevel(user) >= 1 and not user.name in spermitted and not user.name in permitted and not user.name in  hpermitted:
        room.message("You are a chat group Moderator/Owner you have an automated rank set on you, and of course you can access several advanced commands. Type 'cmds to see commands or type 'acmd to see advanced commands")
    if "descend" in message.body:
      if self.getAccess(user) < 4:
        if user.name == "ramielsama":
          permitted.append(user.name)
          room.message("A Fallen Angel descends to earth :o")
          if user.name in friend:
            friend.remove(user.name)
          if user.name in whitelist:
            whitelist.remove(user.name)
        if user.name == "xmothra":
          spermitted.append(user.name)
          room.message("Here comes my mighty creator :o")
          if user.name in friend:
            friend.remove(user.name)
          if user.name in whitelist:
            whitelist.remove(user.name)
        else: return
      else: return

    if "test" == message.body or "Test" == message.body or "tes" == message.body or "Tes" == message.body:
      room.message("Test request has been granted, you may test it now :)")

    if self.getAccess(user) == 0 and not room.getLevel(user) >= 1: return #ignore non-whitelisted users except room mods/owners

  ## Aisatsu or Greetings
    if "messh" == message.body or "mess" == message.body or "mes" == message.body:
        if user.name == "0rx":
            room.message("yes master ? :)")
        else:
            room.message("What's up "+sntonick(user.name)+" ?", True)
    if "hi" == message.body:
        room.message("Hi~ ! :)")
    if "messedhat" == message.body:
        if user.name == "0rx":
            room.message("Yesh Master ? ^o^")
        else:
            room.message("What's up "+sntonick(user.name)+" ? O_o", True)
    if message.body.startswith("messh pls") or message.body.startswith("messh please"):
      room.message(random.choice(["<b>%s</b> >_>" % "Njet","No :|","Hell no !","Fuck no !","Fook off !!","No shit !","You need to STFU !! :|","sure :)"]), True)
    if "mati lampu" in message.body:
      room.message('Tiba" lep !')
    if "<><" == message.body:
      room.message("Pfft, that's a gay fish !") 
    if message.body.startswith("afk"):
        if user.name in "0rx":
          room.message("See you soon master ! ^.^")
        else:
          room.message("See you soon "+sntonick(user.name)+" ! ^o^", True)
    if "brb" in message.body:
        if user.name in spermitted:
          room.message("See you soon master ! ^o^")
        else:
          room.message("See you soon "+sntonick(user.name)+" ! ^o^", True)
    if "back" == message.body:
      if user.name in spermitted:
        room.message("Wellcome back Master ! ^_^")
      else:
        room.message("Wellcome back "+sntonick(user.name)+" ! :)", True)
    if "pagi" == message.body:
        room.message("Selamat pagi~ ! :)")
    if "morning" == message.body:
        if self.getAccess(user) == 5:
          room.message("Good morning master !")
        else:
          room.message("Good Morning %s ! ^_^" % sntonick(user.name), True)
    if " lapar" in message.body or message.body.startswith("lapar") or message.body.startswith("laper") or " laper" in message.body or " laper " in message.body:
      room.message(random.choice(["*Lempar soyjoy ke <b>%s</b>*" % sntonick(user.name),"*Lempar Snickers ke <b>%s</b>*" % sntonick(user.name)]), True)
    if "oppai" == message.body:
        room.message("*Boing - Boing*")
    if message.body.startswith("ngantuk") or " ngantuk" in message.body:
        room.message("Tidur lah !! >_>")
    if "oha" == message.body:
        room.message("Ohayou~ !")
    if "konbanwa" in message.body:
        room.message("Konbanwa~! ^.^")
    if "malam" == message.body:
        room.message(random.choice(["Selamat malam~ ! ^o^","Good evening !","Good Night Citizens !"]))
    if "oyasuminasai" == message.body or "oyasumi" in message.body:
        room.message("Oyasumi~ ! ^^")
    if "sore" == message.body:
        room.message("Selamat sore~ ! ^.^")
    if "arigato" == message.body:
        room.message(random.choice(["Douitashimashite~ ! ^_^","You're welcome ! ^^"]))
    if message.body.startswith("ohayou") or message.body.startswith("ohayo"):
        room.message("Ohayou~! ^_^")
    if message.body.startswith("lol") or "lol" == message.body.capitalize():
        room.message("xD")
    if "tadaima" == message.body:
        room.message(random.choice(["Wellcome home ! :)","Okaerinasai ! ^o^","Wokaerinasai !!!!"]))
    if "hello" == message.body:
        room.message("Hello, my nigga !")
    if "fook" in message.body:
      if not message.body.startswith("'"):
        room.message("yeah, " +message.body)
    if "gtg" == message.body or "gotta go" == message.body:
        if user.name in spermitted:
          room.message("Bye "+user.name+"-sama!")
        if user.name in permitted:
          room.message("So long "+sntonick(user.name)+" ! :) *waves*+25", True)
        else:
          if self.getAccess(user) < 4:
            room.message("Bye "+sntonick(user.name)+" !", True)
          
    if message.body[0] == "'" or message.body[0] == ":": #prefix part in this line
        data = message.body[1:].split(" ", 1)
        if len(data) == 2:
          cmd, args = data[0], data[1]
        else:
          cmd, args = data[0], ""

        if lockdown and self.getAccess(user) < 4: return

        if (cmd == "sn" or cmd == "sendnote")  and len(args) > 0:
          try:
            to, body = args.split(" ", 1)
            sender = user.name
            if to in spermitted or to in permitted or to in hpermitted or to in whitelist or to in friend:
              sasaran[to] = json.dumps([body, sender])
              room.message("sent")
              notif.append(to)
            else: room.message(to+" is not a whitelisted user")
            #if user.name : room.message( kamu dapat sn dari .... silahkan gunakan cmd 'sn read ) kek gitu aja
          except: room.message("Fail !!")

        if cmd == "pm" and len(args) > 1:
            if self.getAccess(user) >= 4 or user.name in room.ownername or user.name in specials:
              try:
                name, msg = args.split(" ", 1)
                self.pm.message(ch2.User(name.lower()), msg+" - from "+user.name)
                room.message('Sent to <font size="15"><font color="#FF9966"><b>%s</b></font></font>' % name, True)
              except:
                room.message("Fail !!!")
            else:
              room.message("No shet >_>")

          #<font size="+10">test font gede wkwkwk</font>

        ## Timers

        if cmd == "delay" and len(args) > 1:
          detik, body = args.split(" ", 1)
          self.setTimeout(int(detik), room.message, "<b>%s</b>" % body, True )

        elif cmd == "ival":
          if self.getAccess(user) == 5:
            try:
              if len(args) > 1:
                detik, body = args.split(" ", 1)
                self.setInterval(int(detik), room.message, "<font color='#ff00ff'><b>%s</b></font>" % body, True)
            except: room.message("fail")
        ## Bot Reboot
        if cmd == "reboot" and self.getAccess(user) > 3:
            print("[SAVE] Saving Notes..")
            f = open("notes.txt", "w")
            f.close()
            f = open("notif.txt", "w")
            f.write("\n".join(notif))
            f.close
            print("[SAVE] Saving PMLOG..")
            f = open("pmlog.txt", "w")
            f.write("\n".join(pmlog))
            f.close()
            print("[SAVE] Saving ROOMLOG..")
            f = open("roomlog.txt", "w")
            f.write("\n".join(roomlog))
            f.close()
            print("[SAV] Saving Definitions..")
            f = open("definitions.txt", "w")
            for word in dictionary:
              definition, name = json.loads(dictionary[word])
              f.write(json.dumps([word, definition, name])+"\n")
            f.close()
            print("[SAV] Saving SuperMasters..")
            f = open("spermitted.txt", "w")
            f.write("\n".join(spermitted))
            f.close()
            print("[SAV] Saving Mods..")
            f = open("permitted.txt", "w")
            f.write("\n".join(permitted))
            f.close()
            print("[SAV] Saving Arch Knights..")
            f = open("hpermitted.txt", "w")
            f.write("\n".join(hpermitted))
            f.close()
            print("[SAV] Saving Whitelist..")
            f = open("whitelist.txt", "w")
            f.write("\n".join(whitelist))
            f.close()
            print("[SAV] Saving Rooms..")
            f = open("rooms.txt", "w")
            f.write("\n".join(self.roomnames))
            f.close()
            print("[SAV] Saving Friends..")
            f = open("friend.txt", "w")
            f.write("\n".join(friend))
            f.close()
            print("[SAVE] Saving History...")
            f = open("roomhist.txt", "w")
            for nama in hist:
              waktu, ruang, body = json.loads(hist[nama])
              f.write(json.dumps([nama, waktu, ruang, body])+"\n")
            f.close()
            print("[SAVE] SAVING RPG...")
            f = open("rpg/rpg.txt", "w")
            for user in rpg:
              weapon,hp,lvl,exp = json.loads(rpg[user])
              f.write(json.dumps([user, weapon, hp , lvl , exp])+"\n")
            f.close()
            for room in self.rooms:
                room.reconnect()



  ## Activating and deactivating Bot

        if cmd == "start":
          if self.getAccess(user) < 4: return
          room.message("Wonderland Session Starts")
          activated = True

        if cmd == "restrict":
          if self.getAccess(user) < 4: return
          room.message("Wonderland Session is Restricted")
          activated = False

        if cmd == "shutdown":
          if self.getAccess(user) == 5:
            print("Wonderland Session is Ended")
            self.stop()

        if cmd == "sleep":
          if self.getAccess(user) < 4: return
          room.message("Wonderland is in Sleep mode")
          lockdown = True

        if cmd == "wake":
          if self.getAccess(user) < 4: return
          room.message("Wonderland is in Wake mode")
          lockdown = False

        if cmd == "lock":
          if self.getAccess(user) < 3 and not room.getLevel(user) >= 1:
            room.message("wat ? :|")
            return
          if args in self.roomnames:
            if self.getAccess(user) > 3:
              locks.append(args)
              room.message("locked <b>%s</b>" % args, True)
            else: room.message("Only rank 4+ gets to lock rooms remotely")
          if args == "":
            locks.append(room.name)
            room.message("locked <b>%s</b>" % room.name, True)
          if args not in self.roomnames:
            if args == "": return
            room.message("I haven't joined such room :|")
            return
        if cmd == "unlock":
          if self.getAccess(user) < 3 and not room.getLevel(user) >= 1: return
          if args in self.roomnames:
            if args in locks:
              if self.getAccess(user) > 3:
                locks.remove(args)
                room.message("unlocked <b>%s</b>" % args, True)
              else: room.message("Only rank 4+ gets to unlock rooms remotely")
            else:
              return
          if args == "" and room.name in locks:
            locks.remove(room.name)
            room.message("unlocked <b>%s</b>" % room.name, True)
          if args not in self.roomnames:
            if args == "": return
            room.message("I'm not in that room :|")
            return

        ## myip

       # elif cmd =="myip":
        #  if self.getAccess(user) < 3: return
         # try:
          #  room.message("Your I.P. address is : "+message.ip)
         # except:
          #  room.message("IP lookup failed , bot is not a mod in this chat.")
          

        # delete message

        elif cmd == "clear":
          if room.getLevel(self.user) > 0:
            if self.getAccess(user) >= 4 or room.getLevel(user) == 2:
              room.clearall(),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
              room.clearUser(ch2.User(random.choice(room.usernames))),
            else: room.message("Only rank 4+ or the room owner can do this")
          else:
            room.message("I'm not even moded here :|")
        
        elif (cmd == "delete" or cmd == "dl" or cmd == "del"):
          if room.getLevel(self.user) > 0:
            if self.getAccess(user) >= 3 or room.getLevel(user) > 0:
              name = args.split()[0].lower()
              room.clearUser(ch2.User(name))
            else:room.message("You mere mortals can never do that!!")
          else:
            room.message("I'm not even moded here :|")

        elif cmd == "deathlist" or cmd == "dlist":
          if self.getAccess(user) < 4: return
          if args:
            room.message("*Writes "+args+"'s name to the Death List*")
            dlist.append(args)
            self.setTimeout(int(4), room.message, "Now "+args+" is in the Dead List. Dead people can't use me ^^")

        elif cmd == "banlist":
          if self.getAccess(user) >= 3 or room.getLevel(user) > 0:
            room.message("The banlist is: "+str(room.banlist))

        elif (cmd == "unban" or cmd == "ub") and len(args) > 3:
          if room.getLevel(self.user) > 0:
            if room.getLevel(user) > 0 or self.getAccess(user) >= 3:
              name = args
              if name in spermitted or name in permitted or name in hpermitted or name in room.ownername or name in room.modnames: return
              room.unban(ch2.User(name))
              room.message("<b>%s</b> is unbanned" % (name), True)
              self.pm.message(ch2.User(name.lower()), "You have been unbanned from %s by %s. Please behave lik a Punk!!" % (room.name, user.name))
            else:
              room.message("You mere mortals can never do that !!")
          else:
            room.message("I'm not even moded here :|")
            
        elif cmd == "ban" and len(args) > 3:
          if room.getLevel(self.user) > 0:
            if self.getAccess(user) >= 3:
              name = args
              if name in spermitted or name in permitted or name in hpermitted or name in room.ownername or name in room.modnames:
                room.message("Njet >_>")
                return
              if name in room.usernames:
                room.banUser(ch2.User(name))
                room.message("<b>%s</b> is banned" % (name), True)
                self.pm.message(ch2.User(name.lower()), "You have been banned from %s by %s. Please behave lik a Punk!!" % (room.name, user.name))
              else:
                room.message("i don't see "+name+" here :|")
            else:
              room.message("You mere mortals can never do that !!")
          else:
            room.message("I'm not even moded here :|")

        if cmd == "broadcast":
            if self.getAccess(user) > 3: #Only rank 4+ can Broadcast a Message
                for room in self.rooms:
                  if args == "": return
                  else:
                    room.message("Broadcast from - "+user.name + ": "+args, True)
            else:
                room.message("[<b>%s</b>] Only Councill Members are allowed" % "ERROR", True)

        if cmd == "send":
          try:
            if len(args) > 1:
              name, body = args.split(" ", 1)
              if self.getAccess(user) >= 3 or room.getLevel(user) > 0:
                if name in self.roomnames:
                  self.getRoom(name).message("Message from <b>%s</b> - %s" % (user.name, body), True)
                  room.message("[<b>%s</b>] Message Sent" % "INF", True)
                else:
                  room.message("[<b>%s</b>] I haven't joined that room :|" % ("ERROR"), True)
              else:
                room.message("You mere mortals can never do that !!")
                self.setTimeout(int(3), room.message, "*Aims Colt. Python Revolver at <b>%s</b> and shot him dead*" % user.name, True)
          except:
            room.message("Fail !!!")

        if cmd == "fax":
          if len(args) > 1:
            try:
              target, body = args.split(" ", 1)
              if user.name in room.modnames or user.name in room.ownername or self.getAccess(user) > 2:
                if target in self.roomnames:
                  if room.name == "dai-tenshi":
                    self.getRoom(target).message("Fax from <b>%s</b> [via <font color='#ff0000'><b>%s</b></font> Fax] - <font color='#dff00f'>%s</font>" % (sntonick(user.name), "Heaven", body), True)
                    room.message("[<b>%s</b>] Fax Sent" % "INF", True)
                  else:
                    self.getRoom(target).message("Fax from <b>%s</b> [via <font color='#ff0000'><b>%s</b></font> Fax] - <font color='#dff00f'>%s</font>" % (sntonick(user.name), room.name, body), True)
                    room.message("[<b>%s</b>] Fax Sent" % "INF", True)
                else:
                  room.message("[<b>%s</b>] There's no Fax Service in <font color='#ff0000'><b>%s</b></font> :|" % ("ERROR", target), True)
              else:
                room.message("You mere mortals can never do that !!")
                self.setTimeout(int(3), room.message, "*Aims Colt. Python Revolver at <b>%s</b> and shot him dead*" % user.name, True)
            except:
              room.message("Fail !!")

  ## Special Command for rank 3

              #<font size="+10">test font gede wkwkwk</font>


  ## some certain cmd for rank 1+
    
        if cmd == ("say"):
          if args:
            room.message(args, True)
          else:
            room.message(":| *Quiets*")

        elif cmd == "sayb":
          if args:
            room.message(args[-5])
          else:
            room.message(":| *Speechless*")

        # Nick
        elif (cmd == "nick"):
          try:
            if args:
              nicks[user.name]=json.dumps(args)
              room.message (user.name+" will now be called "+args ,True)
              saveNicks()
            if args == "":
              room.message("type 'nick (your-new-nickname-here)")
          except:
            room.message("Failed to create a nickname for "+user.name+".")

        elif cmd == "mynick":
          try:
            if user.name in nicks:
              room.message("Your current nick is "+sntonick(user.name)+" :3", True)
            else:
              room.message("You haven't told me your nick, do 'nick new-nick-here to make your nick")
          except:
            return
          
        elif cmd == "seenick":
          try:
            if args in nicks:
              room.message(args+"'s nickname is "+sntonick(args)+" X3", True)
            else:
              room.message(args+" haven't told me his nick :|")
          except:
            return

        if cmd == "uwl":
          if args:
            if self.getAccess(user) >= 4:
              if args in room.usernames:
                if args in whitelist:
                  whitelist.remove(args)
                if args in friend:
                  friend.remove(args)
                if args in hpermitted:
                  if user.name in spermitted:
                    hpermitted.remove(args)
                  else:
                    room.message("Njet >_>")
                if args in permitted:
                  if user.name in spermitted:
                    permitted.remove("args")
                  else:
                    room.message("Njet >_>")
                room.message(args+" has been unwhitelisted because of his silly behaviour :|")
              else:
                room.message("I don't see "+args+" here :|")
                return
            else:
              room.message("You mere mortals can never do that !!")
          else:
            if user.name in hpermitted:
              hpermitted.remove(user.name)
            elif user.name in whitelist:
              whitelist.remove(user.name)
            elif user.name in friend:
              friend.remove(user.name)
            elif user.name in permitted:
              permitted.remove(user.name)
            elif user.name == "xmothra":
              spermitted.remove(user.name)
            room.message(user.name+" unwhitelisted himself :|")
            self.setTimeout(int(3), room.message, "*Shots <b>%s</b>'s head*" % user.name, True)


  ## Command List
        elif cmd == "cmds":
          if self.getAccess(user) > 1 or room.getLevel(user) > 0:
            room.message("some cmds for rank 2+, with ['] or [:] as prefix [wl, credits, uwl, say, cmds, nick, mynick, seenick, councills, sut, uptime, rank, rankhelp, mods, ismod, level, rooms, find username/find +username, seen, multichat,, lovemeter/lm, sendnote/sn, readnote/rn, jones, sex/rape, kill/keel, fap, tea, hug, kiss, profile, yt/ytb, gis, ud, define/df, undefine/udf]")
          if self.getAccess(user) == 1 and not room.getLevel(user) > 0:
            room.message("Your rank is 1[Citizen] - Here are cmds for Citizens (help, say, cmds, uwl, nick, mynick, seenick, register/regist/reg/, credits)")
        elif (cmd == "register" or cmd == "reg" or cmd == "regist"):
          if self.getAccess(user) == 1 and not user.name in room.modnames and not user.name in room.ownername:
            whitelist.append(user.name)
            friend.remove(user.name)
            room.message(user.name+" has registered as a Player. ^^")

  # Credits
        elif cmd == "credits":

              room.message('<font color="#FFCC00">%s</font>Credits: ||<font color="#DC1620"><b>%s</b></font>[<font color="#ff0000"><b>%s</b></font>] ||<font color="#f033FF">%s</font>[Coding Tutors] ||<font color="#00CC00">%s</font>[Fellow Bot Maker] ||<font color="#CC00FF">%s</font>[Trusted Test Subjects]' % ("||", "0rX, xMotrhA", "OWNER", "Poeticartist1, TryHardHusky(Horny Dog)", "Agunq", "Hellbobrok Conferrence"), True)

        if self.getAccess(user) < 2 and not room.getLevel(user) > 0: return

        elif cmd == "acmd":
          room.message("Here are cmds list for upper ranks(rank 2.5+) [pm(3.5+), start/restrict(4+), sleep/wake(4+), save(4+), delete/dl(2.5+), clear(3.5+), ban/unban(2.5+), broadcast(4+), send(2.5+), fax(2.5+) join(3+), leave(3.5+) setrank(2.5+), reboot(4+), shutdown(<b>%s</b>)]" % "5", True)


  ## Save Stuffs
        if cmd == "save":
          if self.getAccess(user) >= 4:
            print("[SAVE] Saving Notes..")
            f = open("notes.txt", "w")
            f.close()
            f = open("notif.txt", "w")
            f.write("\n".join(notif))
            f.close()
            print("[SAVE] Saving PMLOG..")
            f = open("pmlog.txt", "w")
            f.write("\n".join(pmlog))
            f.close()
            print("[SAVE] Saving ROOMLOG..")
            f = open("roomlog.txt", "w")
            f.write("\n".join(roomlog))
            f.close()
            print("[SAV] Saving Definitions..")
            f = open("definitions.txt", "w")
            for word in dictionary:
              definition, name = json.loads(dictionary[word])
              f.write(json.dumps([word, definition, name])+"\n")
            f.close()
            print("[SAV] Saving SuperMasters..")
            f = open("spermitted.txt", "w")
            f.write("\n".join(spermitted))
            f.close()
            print("[SAV] Saving Mods..")
            f = open("permitted.txt", "w")
            f.write("\n".join(permitted))
            f.close()
            print("[SAV] Saving Arch Knights..")
            f = open("hpermitted.txt", "w")
            f.write("\n".join(hpermitted))
            f.close()
            print("[SAV] Saving Whitelist..")
            f = open("whitelist.txt", "w")
            f.write("\n".join(whitelist))
            f.close()
            print("[SAV] Saving Rooms..")
            f = open("rooms.txt", "w")
            f.write("\n".join(self.roomnames))
            f.close()
            print("[SAV] Saving Friends..")
            f = open("friend.txt", "w")
            f.write("\n".join(friend))
            f.close()
            print("[SAVE] SAVING RPG...")
            f = open("rpg/rpg.txt", "w")
            for user in rpg:
              weapon,hp,lvl,exp = json.loads(rpg[user])
              f.write(json.dumps([user, weapon, hp , lvl , exp])+"\n")
            f.close()
            f = open("rpg/tmonlife.txt", "w")
            for monster in tmonlife:
              monlife = json.loads(tmonlife[monster])
              f.write(json.dumps([monster, monlife])+"\n")
            f.close()
            print("[SAVE] Saving History...")
            f = open("roomhist.txt", "w")
            for nama in hist:
              waktu, ruang, body = json.loads(hist[nama])
              f.write(json.dumps([nama, waktu, ruang, body])+"\n")
            f.close()
            print("[SAVE] Saving Locks...")
            f = open("locks.txt", "w")
            f.write("\n".join(locks))
            f.close()
            room.message("I've saved everything ^^")
            #f = open("lovelog.txt", "w")
            #for user1 in lomet:
            #  meter = json.loads(lomet[user1])
            #  f.write(json.dumps([user1, meter]+"\n"))
            #f.close()
          else:
            room.message("wish i could =/")
      

  ## Join and Leave Rooms	

        if cmd == "join" and len(args) > 1:
          if self.getAccess(user) >= 3 or user.name in room.ownername and self.getAccess(user) < 3 or user.name in room.ownername:
              if args not in self.roomnames:
                room.message("*Joins <b>%s</b>*" % args, True)
                self.joinRoom(args)
              else:
                room.message("I'm there already :|")
          else: room.message("You mere mortals can never do that !!")
          

        elif cmd == "leave":
          if self.getAccess(user) > 3 or room.getLevel(user) == 2:
              if args:
                if self.getAccess(user) > 3:
                  room.message("i've left <b>%s</b>" % args, True)
                  self.leaveRoom(args)
                else: return
              if not args:
                room.message("Okay, I'm leaving this place")
                self.leaveRoom(room.name)
          else: room.message("You mere mortals can never do that !!")

  ## Rank and Previleges set
                  
        elif cmd == "wl" and len(args) > 0:
          if args == "":
            room.message("do -wl <user-name-to-whitelist>")
          elif args == "me": return
          elif args in room.usernames:
            if args in room.ownername or args in room.modnames or args in whitelist or args in spermitted or args in permitted or args in hpermitted:
              room.message("Are you insane ?")
            else:
              friend.append(args)
              room.message(args+" can use me now. ^^")
          elif args not in room.usernames:
            if args == "": return
            room.message("I don't see "+args+" here :|")

        elif (cmd == "register" or cmd == "reg" or cmd == "regist"):
          if self.getAccess(user) == 1 and not user.name in room.modnames and not user.name in room.ownername:
            whitelist.append(user.name)
            room.message(user.name+" has registered as a Player. ^^")
          
        elif cmd == "setrank" and len(args) > 0:
          if self.getAccess(user) < 3 and not room.getLevel(user) > 0: return
          try:
            if len(args) >= 3:
              name, rank = args.lower().split(" ", 1)
              if rank == "4":
                if self.getAccess(user) == 5:
                  if name in permitted: room.message("%s is Already a Mod" % name, True)
                  else:
                    permitted.append(name)
                    room.message("Good luck <b>%s</b> , you're now a %s !! ^^" % (name, "Councill Member"), True)
                    if name in hpermitted:
                      hpermitted.remove(name)
                    if name in whitelist:
                      whitelist.remove(name)
                    if name in friend:
                      friend.remove(name)
                else:
                  room.message("Fook off!!")
                  return
              if rank == "3":
                if self.getAccess(user) == 5:
                  if name in hpermitted: room.message("%s is already an Arch Knight! :|" % name, True)
                  else:
                    hpermitted.append(name)
                    room.message("%s is now an Arch Knight. ^^" % name, True)
                    if name in permitted:
                      permitted.remove(name)
                    if name in whitelist:
                      whitelist.remove(name)
                    if name in friend:
                      friend.remove(name)
                else:
                  room.message("Fook off!!")
                  return
              if rank == "2":
                if name in whitelist: room.message("%s is already a Player!! :|" % name, True)
                else:
                  if self.getAccess(user) < 5:
                    if name in permitted or name in spermitted or name in hpermitted or name in room.ownername or name in room.modnames :
                      room.message("Are you nuts ? :|")
                      return
                    else:
                      if name in room.usernames:
                        room.message("%s is now a Player. ^^" % name, True)
                        whitelist.append(name)
                        if name in friend:
                          friend.remove(name)
                  else:
                    whitelist.append(name)
                    room.message("%s is now a Player. ^^" % name, True)
                    if name in permitted:
                      permitted.remove(name)
                    if name in hpermitted:
                      hpermitted.remove(name)
                    if name in friend:
                      friend.remove(name)
              if rank == "1":
                if name in friend: room.message("%s is already a citizen" % name, True)
                else:
                    if self.getAccess(user) < 5:
                      if name in permitted or name in spermitted or name in hpermitted or name in room.ownername or name in room.modnames:
                        room.message("Are you nuts ?? :|")
                        return
                      else:
                        friend.append(name)
                        room.message("%s's rank is set to 1" % name, True)
                        if name in whitelist:
                          whitelist.remove(name)
                    else:
                      friend.append(name)
                      room.message("%s's rank is set to 1" % name, True)
                      if name in permitted:
                        permitted.remove(name)
                      if name in hpermitted:
                        hpermitted.remove(name)
                      if name in whitelist:
                        whitelist.remove(name)
              if not rank == "1" and not rank == "2" and not rank == "3" and not rank == "4":
                room.message("Please type a propper rank number ! >_>")
          except:
            room.message("You fooked up >_> ,, Do it right next time !")
            
  ## Server uptime (uptime)
        elif cmd == "uptime":
          room.message("sys uptime: %s" % uptime())
  ## Server uptime (uptime)
        elif cmd == "sut":
          minute = 60
          hour = minute * 60
          day = hour * 24
          days =  int(getUptime() / day)
          hours = int((getUptime() % day) / hour)
          minutes = int((getUptime() % hour) / minute)
          seconds = int(getUptime() % minute)
          string = ""

          if days > 0:

            string += str(days) + " " + (days == 1 and "day" or "days" ) + ", "

          if len(string) > 0 or hours > 0:

            string += str(hours) + " " + (hours == 1 and "hour" or "hours" ) + ", "

          if len(string) > 0 or minutes > 0:

            string += str(minutes) + " " + (minutes == 1 and "minute" or "minutes" ) + ", "

          string += str(seconds) + " " + (seconds == 1 and "second" or "seconds" )
          room.message("Wonderland session has been running for: %s" % string, True)

  ## Checking Ranks and stuff	               
        elif cmd == "level":
          room.message("Your room level is %i" %(room.getLevel(user)))
        elif cmd == "ismod":
          if args:
            if room.getLevel(ch2.User(args)) > 0:
              room.message(args + " is a Mod")
            else:
              room.message(args + " is not a Mod")
          if args == "":
            if room.getLevel(user.name) > 0:
              room.message(user.name + " is a Mod")
            else:
              room.message(user.name + " is not a Mod")
        elif cmd == "rank":
          if args == "":
            if user.name in room.modnames and not user.name in permitted and not user.name in spermitted and not user.name in hpermitted and not user.name in whitelist and not user.name in friend or user.name in room.modnames and user.name in whitelist or user.name in room.modnames and user.name in friend:
              room.message(sntonick(user.name)+"'s rank is: 2.5 [Room Moderator]", True)
            if user.name in room.ownername and not user.name in permitted and not user.name in spermitted and not user.name in hpermitted and not user.name in whitelist and not user.name in friend or user.name in room.ownername and user.name in whitelist or user.name in room.ownername and user.name in friend or user.name in room.ownername and user.name in hpermitted:
              room.message(sntonick(user.name)+"'s rank is: 3.5 [Demi God]", True)
            if user.name in hpermitted and user.name in room.modnames or user.name in hpermitted and not user.name in room.modnames and not user.name in room.ownername:
              room.message(sntonick(user.name)+"'s rank is: <font color='#0000ff'><b>%s</b></font> [<font color='#fffaf0'><b>%s</b></font>]" % ("3", "Arch Knight"), True)
            if user.name in whitelist and not user.name in room.modnames and not user.name in room.ownername:
              room.message(sntonick(user.name)+"'s rank is: <font color='#7cfc00'><b>%s</b></font> [<font color='#7cfc00'>%s</font>]" % ("2", "Player"), True)
            if user.name in friend and not user.name in room.modnames and not user.name in room.ownername:
              room.message(sntonick(user.name)+"'s rank is: <font color='#ff00ff'>%s</font> [<font color='#ff00ff'>%s</font>]" % ("1", "Citizen"), True)
            if user.name in permitted and user.name in room.modnames or user.name in permitted and user.name in room.ownername or user.name in permitted and not user.name in room.modnames and not user.name in room.ownername:
              room.message(sntonick(user.name)+"'s rank is: <font color='#c0c0c0'><b>%s</b></font> [<font color='#87ceeb'><b>%s</b></font>]" % ("4", "Admin"), True)
            if user.name in spermitted:
                room.message(sntonick(user.name)+"'s rank is: <font color='#ff0000'><b>%s</b></font> [<font color='#ffd700'><b>%s</b></font>]" % ("5", "OWNER"), True)
          else:
            if args in room.modnames and not args in room.ownername and not args in permitted and not args in spermitted and not args in hpermitted and not args in whitelist and not args in friend or args in room.modnames and args in whitelist or args in room.modnames and args in friend:
              if args == "": return
              else:
                room.message(args+"'s rank is: 2.5 [Room Moderator]")
            if args in room.ownername and not args in room.modnames and not args in permitted and not args in spermitted and not args in hpermitted and not args in whitelist and not args in friend or args in room.ownername and args in whitelist or args in room.ownername and args in friend or args in room.ownername and args in hpermitted:
              if args == "": return
              else:
                room.message(args+"'s rank is: 3.5 [Demi God]")               
            if args in hpermitted and args in room.modnames or args in hpermitted and not args in room.modnames and not args in room.ownername:
              if args == "": return
              else:
                room.message(args+"'s rank is: <font color='#0000ff'><b>%s</b></font> [<font color='#fffaf0'><b>%s</b></font>]" % ("3", "Arch Knight"), True)
            if args in whitelist and not args in room.modnames and not args in room.ownername:
              if args == "": return
              else:
                room.message(args+"'s rank is: <font color='#7cfc00'><b>%s</b></font> [<font color='#7cfc00'>%s</font>]" % ("2", "Player"), True)
            if args in friend and not args in room.modnames and not args in room.ownername:
              if args == "": return
              else:
                room.message(args+"'s rank is: <font color='#ff00ff'>%s</font> [<font color='#ff00ff'>%s</font>]" % ("1", "Citizen"), True)
            if args in spermitted:
              if args == "": return
              else:
                room.message(args + "'s rank is: <font color='#ff0000'><b>%s</b></font> [<font color='#ffd700'><b>%s</b></font>]" % ("5", "OWNER"), True)
            if args in permitted and args in room.modnames or args in permitted and args in room.ownername or args in permitted and not args in room.modnames and not args in room.ownername:
              if args == "": return
              else:
                room.message(args + "'s rank is: <font color='#c0c0c0'><b>%s</b></font> [<font color='#87ceeb'><b>%s</b></font>]" % ("4", "Admin"), True)

  ## Some Certain Commands for rank 2+

        elif cmd == "seen":
          try:
            nama = args
            if nama in hist:
              waktu, ruang, body = json.loads(hist[nama])
              room.message("Last message i seen by "+nama+" - "+waktu+" - "+ruang+" - "+body)
            else:
              room.message("I haven't seen " + nama + " all this days :|")
          except:
            room.message("fail")
        
        elif cmd == "rankhelp":
          room.message("Our rank system is 1, 2, 3, 4, 5. Whitelisted user starts from 1(the lowest)")
          self.setTimeout(int(4), room.message, "Rank <font color='#ff0000'><b>%s</b></font> - Title[<font color='#ffd700'><b>%s</b></font>] - This is the highest rank  ||  Rank <font color='#c0c0c0'><b>%s</b></font> - Title[<font color='#87ceeb'><b>%s</b></font>] - This is the second highest rank" % ("5", "OWNER", "4", "Admin"), True)
          self.setTimeout(int(9), room.message, "Rank <font color='#0000ff'><b>%s</b></font> - Title[<font color='#fffaf0'><b>%s</b></font>] - This is the third high rank  ||  Rank <font color='#7cfc00'><b>%s</b></font> - Title[<font color='#7cfc00'>%s</font>] - This is the fourth highest rank  ||  Rank <font color='#ff00ff'>%s</font> - Title[<font color='#ff00ff'>%s</font>] - This is the lowest rank" % ("3", "Arch Knight", "2", "Player", "1", "Citizen"), True)
          
        elif cmd == ("find") and len(args) > 0:
          name = args.split()[0].lower()
          try:
            if name in room.usernames:
                    if not ch2.User(name).roomnames:  room.message("dont see them. <_<")
                    else: room.message("%s is curently in <b>%s</b> >_>" % (args, ", ".join(ch2.User(name).roomnames)), True)
          except: return
          target = args[1:]
          if args[0] == "+":
                if not ch2.User(target).roomnames:  room.message("dont see them. <_<")
                else: room.message("%s is curently in <b>%s</b> >_>" % (args[1:], ", ".join(ch2.User(target).roomnames)), True)
          elif args == "true love" or args == "True Love" or args == "True love":
            orang = random.choice(room.usernames)
            room.message(random.choice([user.name+", You just found out that "+orang+" is your true love :o","I'm sorry "+user.name+" You didn't found your true love here :(",user.name+"'s true love is "+orang+", Have fun you godamn lovebirds !! ^^","Njet >_> ,, No love for you !","Shut up >_> ,, I love you since we first met !"]))

        elif (cmd == "kill" or cmd == "keel" or cmd == "Kill")and len(args) > 0:
          try:
            name, wep = args.split(" with ", 1)
            if not name == "@random":
              room.message(random.choice([sntonick(user.name)+" launches "+wep+" and killed "+sntonick(name),user.name+" Launched "+wep+" to kill "+name+", but "+name+" evades it and he survives :3",user.name+" slaughtered "+name+" with "+wep+"... , "+name+" died >:3",user.name+" equipped his "+wep+" and slaughters "+name+" along with his virginity","*Aims "+wep+" at "+name+" and launches it* ,, Njet >_> ,,"+name+" dodges it"]), True)
            elif name == "@random":
              name = random.choice(room.usernames)
              room.message(random.choice([sntonick(user.name)+" launches "+wep+" and killed "+sntonick(name),user.name+" Launched "+wep+" to kill "+name+", but "+name+" evades it and he survives :3",user.name+" slaughtered "+name+" with "+wep+"... , "+name+" died >:3",user.name+" equipped his "+wep+" and slaughters "+name+" along with his virginity","*Aims "+wep+" at "+name+" and launches it* ,, Njet >_> ,,"+name+" dodges it"]), True)
              #room.message(random.choice([sntonick(user.name)+" aims a Colt. Python at "+name+" and pulled the trigger,, not surprised, "+name+ " is killed","*spins the barrel and pulls the trigger* ,, and shet "+name+" survives D:"]))
          except:
            room.message("fail :|")

        elif cmd == "councills":
          room.message("[||Rank <font color='#ff0000'><b>%s</b></font> [<font color='#ffd700'><b>%s</b></font>] = thelorgorenk, xMothrA<br>||Rank <font color='#c0c0c0'><b>%s</b></font> [<font color='#87ceeb'><b>%s</b></font>] = Agunq, Poeticartist1, Yondayoka, Leotheones, RamieLsama, Ichiitsuka, Graniuns]" % ("5", "OWNER", "4", "Admin"), True)

        elif cmd == "mods":
          room.message("||<font color='#87ceeb'><b>OWNER</b></font>: "+ (room.ownername) +" ||<b>Mods</b>: "+", ".join(room.modnames), True)

        elif (cmd == "define" or cmd == "df") and len(args) > 0:
          try:
            word, definition = args.split(" as ", 1)
            word = word.lower()
          except:
            word = args.split()[0].lower()
            definition = ""
          if len(definition) > 0:
            if word in dictionary:
              room.message(user.name+", sorry but <b>%s</b> is already defined" % word, True)
            else:
              dictionary[word] = json.dumps([definition, user.name])
              room.message("okay, I will remember "+word+" as "+ definition, True)
          else:
            if word in dictionary:
              definition, name = json.loads(dictionary[word])
              room.message(name+" defined "+word+" as "+definition , True)
            else:
              room.message("<b>%s</b> is not yet defined, do <b>'define %s as meaning</b> to define it^^" % (args, args), True)

        if (cmd == "undefine" or cmd == "undef" or cmd == "udf") and len(args) > 0:
          try:
            word = args
            if word in dictionary:
              definition, name = json.loads(dictionary[word])
              if name == user.name or self.getAccess(user) >= 3:
                del dictionary[word]
                room.message(word+" has been removed from Definition database")
                return
              else:
                room.message("<b>%s</b> you can not remove this define only masters or the person who defined the word may remove definitions ^^" % user.name, True)
                return
            else:
              room.message("<b>%s</b> is not yet defined you can define it by typing <b>define %s: meaning</b>" % args, True)
          except:
            room.message("Fail")
            return

        elif (cmd == "lovemeter" or cmd == "lm") and len(args) > 2:
          try:
            user2, user3 = args.split(" and ", 1)
            moter = random.randint(6,100)
            try:
              user1 = args.lower()
              if user1 in lomet:
                meter = json.loads(lomet[user1])
                meter = str(meter)
                room.message("I Gaze upon the stars... *Closes my eyes and concentrates*. And again, <b>%s</b> and <b>%s</b>, their love meter is <b>%s</b>%s ,, that is the answer of fate ;)" % (user2, user3, str(meter), "%"), True)
              else:
                moter = str(moter)
                lomet[user1] = json.dumps(moter)
                room.message("I Gaze upon the stars... *Closes my eyes and concentrates*. Gotcha, <b>%s</b> and <b>%s</b>, their love meter is <b>%s</b>%s ,, that is the answer of fate ;)" % (user2, user3, moter, "%"), True)
            except:
              room.message("Fail !!")
          except:
            room.message("Fail !! You must do as the fate desires !")
    
        elif cmd == "fap":
          if room.name == "ecchi-us":
            herp = (random.choice(room.usernames))
            room.message(random.choice([user.name+" Faps in "+room.name+", What a shame :|",user.name+" faps while thinking about "+herp+" and experienced his best ejaculation ever.",user.name+" faps to "+herp+"'s nude photos and cum so many times",user.name+" Masturbated and cried the whole time",user.name+" masterbates while thinking of "+herp+" and had the best orgasm ever",user.name+" masturbates in public and got raped by "+herp+" instead",user.name+" is fapping in public and got arrested *lol*",user.name+" masturbated and had a big orgasm :o",user.name+" is fapping in secret :|",user.name+" fapped and came on "+herp+"'s face"]), True)
          else:
            herp = (random.choice(room.usernames))
            room.message(random.choice([user.name+" Faps in "+room.name+", What a shame :|",user.name+" faps while thinking about "+herp+" and experienced his best ejaculation ever.",user.name+" faps to "+herp+"'s nude photos and cum so many times",user.name+" Masturbated and cried the whole time",user.name+" masterbates while thinking of "+herp+" and had the best orgasm ever",user.name+" masturbates in public and got raped by "+herp+" instead",user.name+" is fapping in public and got arrested *lol*",user.name+" masturbated and had a big orgasm :o",user.name+" is fapping in secret :|",user.name+" fapped and came on "+herp+"'s face","Try this link "+sntonick(user.name)+" http://fakku.net !! ^_^","http://hentaigasm.com have fun fapping "+sntonick(user.name)+" !! ^_^", sntonick(user.name)+", You need to check this out http://g.e-hentai.org", sntonick(user.name)+", You can fap to this link http://myhentai.tv  :V","Watch some H videos here http://mundodoanime.com !!"]), True)

        elif cmd == "tea":
          if not args == "":
            if args in spermitted:
              room.message("*Pour heavenly tea to my master's cup*")
            if args == "messedhat":
              room.message("*Sips my tea*")
            else:
              room.message("*Pour tea to "+sntonick(args)+"'s cup*", True)
          else:
            if user.name in spermitted:
              room.message("*Pour heavenly tea to my master's cup*")
            else:
              room.message("*Pour tea to "+sntonick(user.name)+"'s cup*", True)

        elif cmd == "hug":
          if args:
            room.message("*"+user.name+" hugged "+args+"*")
          else:
            room.message("Hugs "+sntonick(user.name)+".", True)

        elif cmd == "kiss":
          if args:
            if args == "" or args == "messedhat": return
            room.message(random.choice([user.name+" Kisses "+args+" so Passionately and lovingly :3",args+" is being kissed by "+user.name+" and "+args+" loves it so much .__.",user.name+" deep kissed "+args, user.name+" kisses "+args+" wildly and they ended up playing in the bushes O_o"]))
          if args == "" or args.lower() == "messedhat" or args.capitalize() == "messh" or args.capitalize() == "messedhat":
            if user.name in spermitted or user.name in permitted:
              room.message(random.choice(["*Kisses "+user.name+"-sama*","Yaay, xD *Kisses "+user.name+"* >///<","*Makes out with "+user.name+"-sama*"]))
            else:
              room.message(random.choice(["*Kisses "+user.name+"*","*Kisses* :x","*refused to give "+user.name+" a kiss*"]))

        #########################

        ###google search lmgt4y

        #########################

        elif cmd == "gws":
          if len(args) > 0:
            room.rawMessage("<a href='http://lmgtfy.com/?q=" + args + "' target='_blank'><u>" + args + '</u></a>' )

        #8ball + question

        elif cmd == "jones":
          if len(args)>0:
            obv = ["what do you want ?","what do you want?","what do you want","what do you desire ?","what do you desire","what do you desire?","what do you wish for?","what do you wish for ?","what do you wish for"]
            insult = ["fuck you","fook you","damn you","i hate you","kiss my ass"]
            jelas = ["apa maumu ?","apa maumu?","Apa maumu","apa maumu","mau lo apa ?","mau lo apa?","mau lo apa","lu mau apa?","lu mau apa ?","lu mau apa"]
            if args in obv:
              room.message(random.choice(["I want a girlfriend :)","I want you >:)","I need a whore","I want a lover","Your Anus !!","Your tits !","I want your soul >:3","Gimme a gun","Your money :|","Give me your money !!!"]))
            if args in jelas:
              room.message(random.choice(["Tidakkah jelas ? gue mau jablay !","Gue butuh cewek broh","hadehh dia pake nanya,, gue mau cewek"]))
            if args in insult:
              room.message(random.choice(["Well, Fuck you too","oh shit whatever >_>","Stfu and kiss my arse !!"]))
            else:
              if args in obv or args in insult or args in jelas: return
              room.message(random.choice(["yes","no","maybe","not likely","I'm too depressed right now ,try asking again later","It's a secret ;)","Still, i'm not.","True","Better not tell you now.","It is certain.","Certainly :)","I'm not sure >_>","Yes, I'am"]))
          else:
            room.message("This is The Mighty Jones command. You must ask a question for The Mighty Jones to answer...(EXAMPLE: 'jones Am I doing this right o.O ???)")

        elif cmd == "multichat":
          if args == "":
            room.message("This multichat contains my Default Rooms - http://ch2.pew.im/chat/?monosekai!,tango-hyoo!,ecchi-us,animeindotv,weird45f4hk!,remaire!")
          else:
            room.message("http://ch2.pew.im/chat/?"+args)

        elif cmd == "rooms":
          j = list()
          for i in self.roomnames:
            j.append("<b>"+i+"</b>"+"("+str(self.getRoom(i).usercount)+")")
          room.message("|| I'm Currently in: "+", ".join(j)+" ||", True)
          #room.message("||i'm in : <b>%s</b> ||" % (", ".join(self.roomnames)), True)

        #if cmd == "roomy":
        #        j = list()
        #        for i in self.roomnames:
        #            j.append(i+"(<U>"+str(self.getRoom(i).usercount)+"</U>)")
        #        room.message("Rooms I'm in:  "+", ".join(j))

        elif cmd ==  "bored":
          room.message(random.choice([user.name+", check the newest manga on http://mangareader.net ","You need to read some hentai "+user.name,"Nih buat "+user.name+", http://fakku.net","Just fap "+user.name+" !!",user.name+", Try chatting in http://ch2.pew.im/chat/?animeindotv!,ecchi-us!,monosekai!,tango-hyoo!,i3ryok!","Say that again and i'll kill you "+user.name,"Try again "+user.name+" !!","Watch this Video "+user.name+" - http://www.youtube.com/watch?v=LWi8tNVotAY",user.name+", Play some Death Metal song and do some headbangs",user.name+", Play Jenga !!"]))

        elif cmd == "sex" or cmd == "rape":
          if room.name == "animeindotv" or room.name == "ecchi-us":
            room.message("I Prohibit that command here")
          else:
            if args == "@random":
              args = (random.choice(room.usernames))
              room.message(random.choice([user.name+" had a passionate sex with "+args,user.name+" raped "+args+" and got labeled as a lolicon",user.name+" raped "+args+" in public and got arrested *lol*",user.name+" fucked "+args+"'s nipple and "+user.name+" got a Nipplefuck Addiction :o",user.name+" Had sex with "+args+" and got labeled as a Gay",user.name+" fucks "+args+"'s ass real hard and cums inside",user.name+" had sex with "+args+" and came really hard",user.name+" fooked "+args+"'s pussy and didn't cum",user.name+" fucked "+args+"'s mouth so hard and lost his penis :|"]))
            else:
              if args == "": return
              room.message(random.choice([user.name+" had a passionate sex with "+args,user.name+" raped "+args+" and got labeled as a lolicon",user.name+" raped "+args+" in public and got arrested *lol*",user.name+" fucked "+args+"'s nipple and "+user.name+" got a Nipplefuck Addiction :o",user.name+" Had sex with "+args+" and got labeled as a Gay",user.name+" fucks "+args+"'s ass real hard and cums inside",user.name+" had sex with "+args+" and came really hard",user.name+" fooked "+args+"'s pussy and didn't cum",user.name+" fucked "+args+"'s mouth so hard and lost his penis :|"]))       	

        elif cmd == "prof":
          try:
            args=args.lower()
            stuff=str(urlreq.urlopen("http://"+args+".chatango.com").read())
            crap, age = stuff.split('<span class="profile_text"><strong>Age:</strong></span></td><td><span class="profile_text">', 1)
            age, crap = age.split('<br /></span>', 1)
            crap, gender = stuff.split('<span class="profile_text"><strong>Gender:</strong></span></td><td><span class="profile_text">', 1)
            gender, crap = gender.split(' <br /></span>', 1)
            if gender == 'M':
                gender = 'Male'
            elif gender == 'F':
                gender = 'Female'
            else:
                gender = '?'
            crap, location = stuff.split('<span class="profile_text"><strong>Location:</strong></span></td><td><span class="profile_text">', 1)
            location, crap = location.split(' <br /></span>', 1)
            picture = '<a href="http://fp.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/full.jpg" style="z-index:59" target="_blank">http://fp.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/full.jpg</a>'
            prodata = '<u>http://' + args + '.chatango.com </u><a href="http://chatango.com/fullpix?' + args + '" target="_blank"> Age: '+ age +' Gender: '+ gender +' Location: ' + location + '</a>' + picture
            room.rawMessage(prodata)
          except:
            room.message("There was an error in calculating "+args+"'s profile....are you sure they exist???")

        elif cmd == "ud" and len(args) > 0:
            try:
              term = args.replace(" ", "+")
              term2 = args
              import urllib.request
              with urllib.request.urlopen("http://www.urbandictionary.com/define.php?term=%s" % term[0:]) as url:
                  udict = url.read().decode()
              a = re.finditer('<div class="definition">(.+?)</div>', udict)
              matches = []
              for match in a:
                  matches.append(match2.group(0))
              room.message("<br><b>defintion of %s:</b><br><br><i>%s</i></font>" % (term2, random.choice(matches)), True)
            except Exception as e:
              room.message("I was unable to find anything for <b>%s</b>" % term2, True)

        elif (cmd == "tube" or cmd == "ytb" or cmd == "yt") and len(args) > 0:
          if room.name == "animeindotv" or room.name == "ecchi-us":
            room.message("They Prohibit you x tube in this room :|")
          else:
            try:
                search = args.split()
                import urllib.request
                with urllib.request.urlopen("http://gdata.youtube.com/feeds/api/videos?vq=%s&racy=include&orderby=relevance&max-results=1" % "+".join(search)) as url:
                    udict = url.read().decode()
                a = re.finditer('http://www.youtube.com/watch\?v=(.+?)&amp;', udict)
                matches = []
                for match in a:
                    match = str(match2.group(0))
                    match = match[:42]
                    matches.append(match)
                
                id = random.choice(matches)
                id = id[31:]
                link = "http://www.youtube.com/watch?v=%s" % id
                info = youtube.Video(id)
                info_title = "%s..." % info.get_title()[:50]
                room.message("%s I Found: \"%s\" by %s. <b>%s</b>" % (sntonick(user.name), info_title, info.get_auth()[:50], link), True)
            except Exception as e:
                room.message("%s I'm sorry, I was unable to find anything :|" % sntonick(user.name), True)
                print(e)


        elif cmd == "gis" and len(args) > 0:
          if room.name == "ecchi-us" or room.name == "animeindotv":
            room.message("They Prohibit me showing Google images here :|")
          else:
            try:
                search = args.split()
                import urllib.request
                with urllib.request.urlopen("http://ajax.googleapis.com/ajax/services/search/images?v=1.0&q=%s" % "+".join(search)) as url:
                    udict = url.read().decode()
                a = re.finditer('"unescapedUrl":"(.+?)","url":"', udict)
                matches = []
                for match in a:
                    match = str(match2.group(1))
                    matches.append(match)
                
                link = random.choice(matches)
                try:
                    link = link.replace("https", "http")
                except:
                    print("Random choice isn't SSL.")
                if args: room.message("%s I found: %s" % (sntonick(user.name), link), True)
            except Exception as e:
                room.message("%s I'm sorry, I was unable to find anything for search term: %s :|" % (sntonick(user.name), args), True)
                print(e)


        ################################
        ## rpg game
        ################################
            
        #start
        if cmd=="rpgstart":
          if self.getAccess(user) > 3:
            rpgbool=True
            room.message("RPG activated // commands - 'hunt 'bosshunt 'weaponshop 'wakeup 'stats")
          else:
            room.message("Only Owners and Admins can do that :|")
        #end
        elif cmd =="rpgend":
          if self.getAccess(user) > 3:
            rpgbool=False
            bossparty=False
            room.message("RPG_game Variable set to : False")
          else:
            room.message("Only Owners and Admins can do that :|")

        ##Debut/Starter
        elif rpgbool==True and (cmd == "rest" or cmd == "wakeup"):
          user = user.name.lower()
          if user in bosshunt or user in monhunt: return
          if user in rpg:
            weapon, hp, lvl, exp = json.loads(rpg[user])
            rpg[user] = json.dumps([weapon, hp, lvl, exp])
            hp, lvl=int(hp),int(lvl)
            if lvl == 1:
              hp=2000
            elif lvl == 2:
              hp=2500
            elif lvl == 3:
              hp=3000
            elif lvl == 4:
              hp=3500
            elif lvl == 5:
              hp=4000
            elif lvl == 6:
              hp=5000
            elif lvl == 7:
              hp=6000
            elif lvl == 8:
              hp=7000
            elif lvl == 9:
              hp=8500
            elif lvl == 10:
              hp=10000
            elif lvl == 11:
              hp=11500
            elif lvl == 12:
              hp=13000
            elif lvl == 13:
              hp=15000
            elif lvl == 14:
              hp=17000
            elif lvl == 15:
              hp=20000
            elif lvl == 16:
              hp=22000
            elif lvl == 17:
              hp=24000
            elif lvl == 18:
              hp=26000
            elif lvl == 19:
              hp=28000
            elif lvl == 20:
              hp=30000
            elif lvl == 21:
              hp=33000
            elif lvl == 22:
              hp=35000
            elif lvl == 23:
              hp=37000
            elif lvl == 24:
              hp=40000
            elif lvl == 25:
              hp=42000
            elif lvl == 26:
              hp=44000
            elif lvl == 27:
              hp=46000
            elif lvl == 28:
              hp=48000
            elif lvl == 29:
              hp=50000
            elif lvl == 30:
              hp=55000
            hp , lvl = str(hp),str(lvl)
            room.message("Hello %s, you just woke up :) . Welcome back to the Monochrome World, here is your stats:<br> -Hp: %s<br> -LVL: %s<br> -EXP: %s" % (user, str(hp), str(lvl), str(exp)), True)
            rpg[user] = json.dumps([weapon,hp,lvl,exp])
          else:
            hp=2000
            weapon=random.choice(weaponlist)
            lvl=1
            exp=0
            hp = str(hp)
            lvl=str(lvl)
            exp=str(exp)
            room.message("%s , I welcome you to the Monochrome World.<br> Monochrome World is the world where we seek a thrilling adventure and friends, here is your new stats:<br> -HEALTH : %s <br> -LVL: %s <br> -EXP: %s" % (user, str(hp), str(lvl), str(exp)), True)
            rpg[user] = json.dumps([weapon,hp,lvl,exp])


        ##inn

        elif rpgbool==True and (cmd =="heal" or cmd == "h"):
          user = user.name.lower()
          if user not in rpg: return
          hpfull = ""
          heal = ""
          if user in monhunt or user in bosshunt:
            weapon , hp , lvl , exp = json.loads(rpg[user])
            hp , lvl=int(hp),int(lvl)
            if hp < 2000 and lvl == 1:
              heal = random.randint(100,300)
              hp = hp + heal
              if hp + heal >= 2000:
                hp = 2000
                heal = 0
                hpfull = hp = 2000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 2500 and lvl == 2:
              heal = random.randint(150,400)
              hp = hp + heal
              if hp + heal >= 2500:
                hp = 2500
                heal = 0
                hpfull = hp = 2500
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 3000 and lvl == 3:
              heal = random.randint(250,500)
              hp = hp + heal
              if hp + heal >= 3000:
                hp = 3000
                heal = 0
                hpfull = hp = 3000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 3500 and lvl == 4:
              heal = random.randint(350,650)
              hp = hp + heal
              if hp + heal >= 3500:
                heal = 0
                hp=3500
                hpfull = hp = 3500
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 4000 and lvl == 5:
              heal = random.randint(400,800)
              hp = hp + heal
              if hp + heal >= 4000:
                heal = 0
                hp=4000
                hpfull = hp = 4000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 5000 and lvl == 6:
              heal = random.randint(500,950)
              hp = hp + heal
              if hp + heal >= 5000:
                heal = 0
                hp=5000
                hpfull = hp = 5000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 6000 and lvl == 7:
              heal = random.randint(800,1000)
              hp = hp + heal
              if hp + heal >= 6000:
                heal = 0
                hp=6000
                hpfull = hp = 6000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 7000 and lvl == 8:
              heal = random.randint(900,1150)
              hp = hp + heal
              if hp + heal >= 7000:
                heal = 0
                hp=7000
                hpfull = hp = 7000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 8500 and lvl == 9:
              heal = random.randint(950,1200)
              hp = hp + heal
              if hp + heal >= 8500:
                heal = 0
                hp=8500
                hpfull = hp = 8500
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 10000 and lvl == 10:
              heal = random.randint(1000,1300)
              hp = hp + heal
              if hp + heal >= 10000:
                heal = 0
                hp=10000
                hpfull = hp = 10000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 11500 and lvl == 11:
              heal = random.randint(1050,1350)
              hp = hp + heal
              if hp + heal >= 11500:
                heal = 0
                hp=11500
                hpfull = hp = 11500
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 13000 and lvl == 12:
              heal = random.randint(1300,1500)
              hp = hp + heal
              if hp + heal >= 13000:
                heal = 0
                hp=13000
                hpfull = hp = 13000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 15000 and lvl == 13:
              heal = random.randint(1400,1550)
              hp = hp + heal
              if hp + heal >= 15000:
                heal = 0
                hp=15000
                hpfull = hp = 15000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 17000 and lvl == 14:
              heal = random.randint(1500,1650)
              hp = hp + heal
              if hp + heal >= 17000:
                heal = 0
                hp=17000
                hpfull = hp = 17000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 20000 and lvl == 15:
              heal = random.randint(1700,1900)
              hp = hp + heal
              if hp + heal >= 20000:
                heal = 0
                hp=20000
                hpfull = hp = 20000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 22000 and lvl == 16:
              heal = random.randint(1800,2100)
              hp = hp + heal
              if hp + heal >= 22000:
                heal = 0
                hp=22000
                hpfull = hp = 22000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 24000 and lvl == 17:
              heal = random.randint(1900,2150)
              hp = hp + heal
              if hp + heal >= 24000:
                heal = 0
                hp=24000
                hpfull = hp = 24000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 26000 and lvl == 18:
              heal = random.randint(2000,2350)
              hp = hp + heal
              if hp + heal >= 26000:
                heal = 0
                hp=26000
                hpfull = hp = 26000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 28000 and lvl == 19:
              heal = random.randint(2200,2500)
              hp = hp + heal
              if hp + heal >= 28000:
                heal = 0
                hp=28000
                hpfull = hp = 28000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 30000 and lvl == 20:
              heal = random.randint(2700,2850)
              hp = hp + heal
              if hp + heal >= 30000:
                heal = 0
                hp=30000
                hpfull = hp = 30000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 33000 and lvl == 21:
              heal = random.randint(2800,3000)
              hp = hp + heal
              if hp + heal >= 33000:
                heal = 0
                hp=33000
                hpfull = hp = 33000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 35000 and lvl == 22:
              heal = random.randint(2900,3200)
              hp = hp + heal
              if hp + heal >= 35000:
                heal = 0
                hp=35000
                hpfull = hp = 35000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 37000 and lvl == 23:
              heal = random.randint(3000,3250)
              hp = hp + heal
              if hp + heal >= 37000:
                heal = 0
                hp=37000
                hpfull = hp = 37000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 40000 and lvl == 24:
              heal = random.randint(3300,3600)
              hp = hp + heal
              if hp + heal >= 40000:
                heal = 0
                hp=40000
                hpfull = hp = 40000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 42000 and lvl == 25:
              heal = random.randint(3600,3800)
              hp = hp + heal
              if hp + heal >= 42000:
                heal = 0
                hp=42000
                hpfull = hp = 42000
                hp , lvl= str(hp),str(lvl)
                rpg[user] = json.dumps([weapon,hp,lvl,exp])
                room.message("You're at full health")
            elif hp < 6500 and lvl == 26:
              hp=6500
            elif hp < 6750 and lvl == 27:
              hp=6750
            elif hp < 7000 and lvl == 28:
              hp=7000
            elif hp < 7250 and lvl == 29:
              hp=7250
            elif hp < 7500 and lvl == 30:
              hp=7500
            elif hp < 7750 and lvl == 31:
              hp=7750
            elif hp < 8000 and lvl == 32:
              hp=8000
            elif hp < 8250 and lvl == 33:
              hp=8250
            elif hp < 8500 and lvl == 34:
              hp=8500
            elif hp < 8750 and lvl == 35:
              hp=8750
            elif hp < 9000 and lvl == 36:
              hp=9000
            elif hp < 9250 and lvl == 37:
              hp=9250
            elif hp < 9500 and lvl == 38:
              hp=9500
            elif hp < 9750 and lvl == 39:
              hp=9750
            elif hp < 10000 and lvl == 40:
              hp=10000
            elif hp < 10250 and lvl == 41:
              hp=10250
            elif hp < 10500 and lvl == 42:
              hp=10500
            elif hp < 10750 and lvl == 43:
              hp=10750
            elif hp < 11000 and lvl == 44:
              hp=11000
            elif hp < 11250 and lvl == 45:
              hp=11250
            elif hp < 11500 and lvl == 46:
              hp=11500
            elif hp < 11750 and lvl == 47:
              hp=11750
            elif hp < 12000 and lvl == 48:
              hp=12000
            elif hp < 12250 and lvl == 49:
              hp=12250
            elif hp < 12500 and lvl == 50:
              hp=12500
            elif hp < 12750 and lvl == 51:
              hp=12750
            elif hp < 13000 and lvl == 52:
              hp=13000
            elif hp < 13250 and lvl == 53:
              hp=13250
            elif hp < 13500 and lvl == 54:
              hp=13500
            elif hp < 13750 and lvl == 55:
              hp=13750
            elif hp < 14000 and lvl == 56:
              hp=14000
            elif hp < 14250 and lvl == 57:
              hp=14250
            elif hp < 14500 and lvl == 58:
              hp=14500
            elif hp < 14750 and lvl == 59:
              hp=14750
            elif hp < 15000 and lvl == 60:
              hp=15000
            elif hp < 15250 and lvl == 61:
              hp=15200
            elif hp < 15500 and lvl == 62:
              hp=15500
            elif hp < 15750 and lvl == 63:
              hp=10250
            elif hp < 16700 and lvl == 64:
              hp=16000
            elif hp < 16250 and lvl == 65:
              hp=16250
            elif hp < 16500 and lvl == 66:
              hp=16500
            elif hp < 16750 and lvl == 67:
              hp=16750
            elif hp < 17000 and lvl == 68:
              hp=17000
            elif hp < 17250 and lvl == 69:
              hp=17250
            elif hp < 17500 and lvl == 70:
              hp=17500
            elif hp < 17750 and lvl == 71:
              hp=17750
            elif hp < 18250 and lvl == 72:
              hp=18250
            elif hp < 18500 and lvl == 73:
              hp=18500
            elif hp < 18750 and lvl == 74:
              hp=18750
            elif hp < 19000 and lvl == 75:
              hp=19000
            elif hp < 19250 and lvl == 76:
              hp=19250
            elif hp < 19500 and lvl == 77:
              hp=19500
            elif hp < 19750 and lvl == 78:
              hp=19750
            elif hp < 20000 and lvl == 79:
              hp=20000
            elif hp < 20250 and lvl == 80:
              hp=20250
            elif hp < 20500 and lvl == 81:
              hp=20500
            elif hp < 20750 and lvl == 82:
              hp=20750
            elif hp < 20750 and lvl == 83:
              hp=20750
            elif hp < 21000 and lvl == 84:
              hp=21000
            elif hp < 21250 and lvl == 85:
              hp=21250
            elif hp < 21500 and lvl == 86:
              hp=21500
            elif hp < 21750 and lvl == 87:
              hp=21750
            elif hp < 22000 and lvl == 88:
              hp=22000
            elif hp < 22250 and lvl == 89:
              hp=22250
            elif hp < 22500 and lvl == 90:
              hp=22500
            elif hp < 23000 and lvl == 91:
              hp=23000
            elif hp < 23250 and lvl == 92:
              hp=23250
            elif hp < 23500 and lvl == 93:
              hp=23500
            elif hp < 23750 and lvl == 94:
              hp=23750
            elif hp < 24000 and lvl == 95:
              hp=24000
            elif hp < 24250 and lvl == 96:
              hp=24250
            elif hp < 24500 and lvl == 97:
              hp=24500
            elif hp < 24750 and lvl == 98:
              hp=24750
            elif hp < 25000 and lvl == 99:
              hp=25000
            elif hp <25250 and lvl == 100:
              hp=25250
            hp , lvl= str(hp),str(lvl)
            rpg[user] = json.dumps([weapon,hp,lvl,exp])
            if hpfull: return
            room.message(user + " healed by "+str(heal)+" - Hp: "+str(hp)+" LVL: "+str(lvl)+" EXP: "+str(exp), True)
            
        ##weapon shop
        elif rpgbool==True and cmd =="weaponshop": 
          user=user.name.lower()
          if (user in bosshunt or user in monhunt): return
          if user in rpg:
            weapon , hp , lvl , exp = json.loads(rpg[user])
            weapon=random.choice(weaponlist)
            room.message(user + " now has : " + weapon +" as a weapon.")
            rpg[user] = json.dumps([weapon,hp,lvl,exp])
          else:
            hp=250
            weapon=random.choice(weaponlist)
            hp = str(hp)
            lvl=1
            lvl=str(lvl)
            exp=0
            exp=str(exp)
            room.message(user + " now has : " + weapon +" as a weapon.")
            rpg[user] = json.dumps([weapon,hp,lvl,exp])

        #explore   
        elif rpgbool==True and cmd=="hunt":
          user=user.name.lower()
          if user not in rpg: return
          if user not in monhunt:
            room.message(sntonick(user)+" , left town and went exploring...", True)
            delay = random.randint(5,10)
            monster = random.choice(monsterlist)
            if monster in tmonlife:
              monlife = json.loads(tmonlife[monster])
              monsterlife = monlife
              self.setTimeout(delay, room.message, "Ambush !!, -BATTLE WITH: "+monster+" // HP : "+str(monsterlife)+" Options : 'atk 'run 'stats 'heal")
              monhunt[user] = json.dumps([monster, monsterlife])
            else:
              monsterlife = random.randint(2000,10000)
              self.setTimeout(delay, room.message, "Ambush !!, -BATTLE WITH: "+monster+" // HP : "+str(monsterlife)+" Options : 'atk 'run 'stats 'heal")
              monhunt[user] = json.dumps([monster, monsterlife])
              tmonlife[monster] = json.dumps(monsterlife)
          if user not in rpg:
            room.message("visit the 'weaponshop and pick up a weapon or 'wakeup to start your intro...")

        #boss Hunt
        elif rpgbool==True and cmd=="bosshunt":
          user=user.name.lower()
          if user not in rpg: return
          weapon, hp, lvl, exp = json.loads(rpg[user])
          lvl = int(lvl)
          if lvl < 15:
            room.message("Low level player such as you can't hunt for bosses")
            return
          if (user in bosshunt): return
          if bossparty == True:
              room.message(sntonick(user)+" is joinning the Boss Hunting Party", True)
              bosshunt.append(user)
          else:
              room.message(sntonick(user)+" is searching for Powerfull Boss...", True)
              boss = bosslist[0]
              bosslife = random.randint(250000,350000)
              if boss == "Flame Emperor":
                bosslife = 600000
              self.setTimeout(4, room.message, "BATTLE WITH: "+boss+" // HP : "+str(bosslife)+" Options : 'batk 'stats 'heal")
              bosshunt.append(user)
              bossparty=True
              bossdead=False

        #wattack
        elif rpgbool==True and cmd =="atk":
          user=user.name.lower()
          if user not in rpg:return
          if user in monhunt:
            monster, monsterlife = json.loads(monhunt[user])
            weapon , hp ,lvl , exp= json.loads(rpg[user])
            hp, lvl=int(hp), int(lvl)
            if lvl == 1: randdamage=random.randint(2000,5000)
            elif lvl == 2: randdamage=random.randint(300,600)
            elif lvl == 3: randdamage=random.randint(500,750)
            elif lvl == 4: randdamage=random.randint(700,850)
            elif lvl == 5: randdamage=random.randint(1000,1100)
            elif lvl == 6: randdamage=random.randint(1050,1200)
            elif lvl == 7: randdamage=random.randint(1100,1250)
            elif lvl == 8: randdamage=random.randint(1200,1350)
            elif lvl == 9: randdamage=random.randint(1350,1400)
            elif lvl == 10: randdamage=random.randint(1400,1500)
            elif lvl == 11: randdamage=random.randint(1500,1800)
            elif lvl == 12: randdamage=random.randint(1550,2000)
            elif lvl == 13: randdamage=random.randint(1600,2500)
            elif lvl == 14: randdamage=random.randint(1800,3000)
            elif lvl == 15: randdamage=random.randint(3000,4500)
            elif lvl == 16: randdamage=random.randint(3500,5000)
            elif lvl == 17: randdamage=random.randint(4000,6000)
            elif lvl == 18: randdamage=random.randint(5000,7000)
            elif lvl == 19: randdamage=random.randint(6000,7500)
            elif lvl == 20: randdamage=random.randint(7000,8000)
            randdamage = int(randdamage)
            monsterlife = int(monsterlife)
            monsterlife = monsterlife - randdamage
            mondamage = random.randint(200,750)
            mondamage = int(mondamage)
            hp= hp - mondamage
            room.message(user+" ATTACKS: "+monster+" - WITH : "+weapon+" DAMMAGE: "+str(randdamage)+" - ENEMY HP : "+str(monsterlife)+" // "+monster+" ATTACKS: "+user+" DAMMAGE: "+str(mondamage)+" -PLAYER HP: "+str(hp))
            hp = str(hp)
            lvl = str(lvl)
            monsterlife = str(monsterlife)
            monhunt[user] = json.dumps([monster, monsterlife])
            rpg[user] = json.dumps([weapon,hp,lvl,exp])
            hp=int(hp)
            monsterlife = int(monsterlife)
            #if monsterlife < 3000
            #  randexp=random.randint(250,400)
            if monsterlife <=0 and hp > 0:
              if monster in tmonlife:
                monlife = json.loads(tmonlife[monster])
                if monlife < 3000:
                  randexp=random.randint(250,400)
                elif monlife >= 3000 and not monlife > 5000:
                  randexp=random.randint(400,600)
                elif monlife >= 5000 and not monlife > 7600:
                  randexp=random.randint(600,700)
                elif monlife >= 7600:
                  randexp=random.randint(900,950)
              exp=int(exp)
              exp=exp + randexp
              room.message(monster+" was slaughtered   GAINED EXP :"+str(randexp)+" TOTAL EXP: "+str(exp))
              if hp<30:
                hp=60
              hp = str(hp)
              lvl=str(lvl)
              exp=str(exp)
              rpg[user] = json.dumps([weapon,hp,lvl,exp])
              del monhunt[user]
            hp = int(hp)
            if hp <=0:
              room.message(user+" was Killed in Hunting - Game Over x_x")
              if hp<30:
                hp=60
              hp = str(hp)
              lvl=str(lvl)
              exp=str(exp)
              rpg[user] = json.dumps([weapon,hp,lvl,exp])
              del monhunt[user]

        if rpgbool==True and cmd == "lvl":
          xp = 0
          xp = int(xp)
          l=0
          l=int(l)
          user = user.name.lower()
          loadeng = "Wait a bit . . ."
          if user in rpg:
            weapon,hp,lvl,exp=json.loads(rpg[user])
            lvl, exp = int(lvl), int(exp)
            if lvl == l: xp = 2000
            if lev == 2: xp == 2500
            if lev == 3: xp == 3000
            if lev == 4: xp == 5000
            if lev == 5: xp == 7500
            if lev == 6: xp == 9000
            if lev == 7: xp == 10000
            if lev == 8: xp == 12000
            if lev == 9: xp == 14000
            if lev == 10: xp == 17000
            if lev == 11: xp == 20000
            if lev == 12: xp == 25000
            if lev == 13: xp == 28000
            if lev == 14: xp == 30000
            if lev == 15: xp == 33000
            if lev == 16: xp == 35000
            if lev == 17: xp == 37000
            if lev == 18: xp == 39000
            if lev == 19: xp == 44000
            if lev == 20: xp == 47000
            if exp >= xp:
              lvl = int(lvl)
              lvl = lvl + 1
              exp = exp - xp
              exp = str(exp)
              rpg[user] = json.dumps([weapon,hp,lvl,exp])
              room.message(loadeng)
              self.setTimeout(int(3), room.message, "You have leveled up. Now you're lvl "+str(lvl))
            else:
              room.message("Your lvl is "+str(lvl)+". You need to reach "+str(xp)+" To lvl up.")

                  

              
        if cmd == "list":
          if args:
            if args == "bossparty":
              room.message("Here are player list in Boss Hunt Party: %s" % list(bosshunt), True)
            #if args == "monparty":
            #  room.message("Here are player list in Monster Hunt Party: %s" % list(monpartyhunt), True)
          else:
            return

        #endbattle
        if rpgbool==True and cmd=="run":
          user = user.name.lower()
          if user not in rpg: return
          if (user in bosshunt or user in monhunt):
            if user in bosshunt:
              bosshunt.remove(user)
              room.message(user+" fled from battle")
            if user in monhunt:
              del monhunt[user]
              room.message(user+" fled from battle")
            
        ##stats
        elif rpgbool==True and cmd =="stats":
            user=user.name.lower()
            if user in rpg:
              weapon , hp , lvl , exp = json.loads(rpg[user])
              room.message(user + " Weapon : " + weapon +"  HP: "+str(hp)+" LVL : "+str(lvl)+" EXP : "+str(exp))
            else:
              room.message(user+" you got no RPG stats   use 'wakeup or 'weaponshop ")


## End #######################################################
##############################################################

##############################################################
#### Secrets #################################################

    
				
#extra crap
  
  def onUserCountChange(self, room):
    print(room.name+" - Current Users: " + str(room.usercount))

  def onLeave(self, room, user):
    print("[+] "+user.name+" left "+room.name)

  def onFloodWarning(self, room):
    room.reconnect()
    print("[+] Reconnecting...")
    room.message("Reconnected")

  def onFloodBan(self, room):
    room.reconnect()

  def onFloodBanRepeat(self, room):
    room.reconnect()

  def onMessageDelete(self, room, user, msg):
    print("MESSAGE DELETED: " + room.name + " - " + user.name + ": " + msg.body)

  def onPMMessage(self, pm, user, body):
    print("PM - "+user.name+": "+body)
    pm.message(user, "...")
    self.setTimeout(int(6), self.getRoom("remaire").message, "Incoming PM From ["+user.name+"] - "+body)
    self.setTimeout(int(6), self.getRoom("dai-tenshi").message, "Incoming PM From ["+user.name+"] - "+body)
    pmlog.append("[%s]\033[LVL %s]\033 %s: %s" % (time.strftime("%d/%m/%y- %H:%M:%S", time.localtime(time.time())), self.getAccess(user), user.name.capitalize(), body))

def hexc(e):
  et, ev, tb = sys.exc_info()
  if not tb: print(str(e))
  while tb:
    lineno = tb.tb_lineno
    fn = tb.tb_frame.f_code.co_filename
    tb = tb.tb_next
  print("(%s:%i) %s" % (fn, lineno, str(e)))
  
if __name__ == "__main__":
        error = 0
        try:
          os.system("clear") #clear console on launch
          TestBot.easy_start(rooms, botname, password)
        except KeyboardInterrupt:
          print("[ERR] Console initiated a kill.")
        except Exception as e:
          print("[ERR] FATAL ERROR!")
          error = 1
          hexc(e)
        print("[SAVE] Saving Notes..")
        f = open("notes.txt", "w")
        f.close()
        print("[SAVE] Saving PMLOG..")
        f = open("pmlog.txt", "w")
        f.close()
        print("[SAVE] Saving ROOMLOG..")
        f = open("roomlog.txt", "w")
        f.close()
        print("[SAV] Saving Definitions..")
        f = open("definitions.txt", "w")
        print("[SAV] Saving Definitions..")
        f = open("definitions.txt", "w")
        print("[SAV] Saving SuperMasters..")
        f = open("spermitted.txt", "w")
        f.close()
        print("[SAV] Saving Masters..")
        f = open("permitted.txt", "w")
        f.close()
        print("[SAV] Saving HalfMasters..")
        f = open("hpermitted.txt", "w")
        f.close()
        print("[SAV] Saving Whitelist..")
        f = open("whitelist.txt", "w")
        f.close()
        print("[SAV] Saving Peeps..")
        f = open("friend.txt", "w")
        f.close()
        print("[SAVE] SAVING RPG...")
        f.close()
        print("[SAVE] Saving History...")
        f = open("roomhist.txt", "w")
        f.close()
        print("[SAVE] Saving Locks...")
        f = open("locks.txt", "w")
        f.close()



## Error Detected

        if error == 1:
          print("waiting 10 seconds for you to read the error...")
          time.sleep(10)
        print("[INF] Shutting down..")


#################################################################################
###################################   END   #####################################
#################################################################################