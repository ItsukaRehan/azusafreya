import urllib.request
import time


def ping():
    data = urllib.request.urlopen("http://testing-helenb0t.rhcloud.com/").read()
    return data

while True:
    ping()
    print("ping")
    time.sleep(600)
