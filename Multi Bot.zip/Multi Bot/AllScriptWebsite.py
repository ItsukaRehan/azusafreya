import random
import subprocess
import sys
import os
import cgi
import traceback
import time
import datetime
import binascii
import getWhois
import base64
import json
import threading
import feedparser
import imp
from time import localtime, strftime
from xml.etree import cElementTree as ET
if sys.version_info[0] < 3:
  class urllib:
    parse = __import__("urllib")
    request = __import__("urllib2")
  input = raw_input
  import codecs
  import Queue as queue
  class http:
    client = __import__("httplib")
else:
  import http.client
  import queue
  import urllib.request as urlreq
  import urllib.parse
  import urllib
import random
from urllib.request import unquote
if sys.version_info[0] > 2:
  import urllib.request as urlreq
else:
  import urllib2 as urlreq
from time import localtime, strftime
from urllib.request import Request, urlopen
from xml.etree import cElementTree as ET
if sys.version_info[0] > 2:
  import urllib.request as urlreq
else:
  import urllib2 as urlreq
from urllib.parse import quote
from urllib.parse import unquote
import urllib.request as urllib2

###################
### GokuNime #################################################################################################
###################
def GokuNime():
    max_retrieve = 4
    feed = feedparser.parse("https://gokunime.net/feed/") # Buat naruh webnya pastikan Url webnya ini feed rss
    feed_title = feed['feed']['title']
    feed_entries = feed.entries
    love = list()
    you_me = 1
    for entry in feed.entries:
        article_title = entry.title
        article_link = entry.link
        article_published_at = entry.published
        article_published_at_parsed = entry.published_parsed
        love.append('<f x09FF0000="1">{}. <f x099999FF="1">{} - <f x09CC66CC="1">{} <f x09FF0000="1">'.format(you_me, article_title, entry.link))
        if len(love) >= max_retrieve:
            break
        you_me += 1
    return 'New Post on <b>Gokunime.net:</b> \r '+'\r'.join(love)
###################
### Anime-Style #################################################################################################
###################
def KoreNime():
    max_retrieve = 4
    feed = feedparser.parse("https://korenime.org/feed/") # Buat naruh webnya pastikan Url webnya ini feed rss
    feed_title = feed['feed']['title']
    feed_entries = feed.entries
    love = list()
    you_me = 1
    for entry in feed.entries:
        article_title = entry.title
        article_link = entry.link
        article_published_at = entry.published
        article_published_at_parsed = entry.published_parsed
        love.append('<f x09FF0000="1">{}. <f x099999FF="1">{} - <f x09CC66CC="1">{} <f x09FF0000="1">'.format(you_me, article_title, entry.link))
        if len(love) >= max_retrieve:
            break
        you_me += 1
    return 'New Post on <b>Korenime.org:</b> \r '+'\r'.join(love)
###################
### MoeNime #################################################################################################
###################
def MoeNime():
    max_retrieve = 4
    feed = feedparser.parse("https://moenime.web.id/feed/") # Buat naruh webnya pastikan Url webnya ini feed rss
    feed_title = feed['feed']['title']
    feed_entries = feed.entries
    love = list()
    you_me = 1
    for entry in feed.entries:
        article_title = entry.title
        article_link = entry.link
        article_published_at = entry.published
        article_published_at_parsed = entry.published_parsed
        love.append('<f x09FF0000="1">{}. <f x099999FF="1">{} - <f x09CC66CC="1">{} <f x09FF0000="1">'.format(you_me, article_title, entry.link))
        if len(love) >= max_retrieve:
            break
        you_me += 1
    return 'New Post on <b>Moenime.web.id:</b> \r '+'\r'.join(love)
###################
### AnoBoyUs #################################################################################################
###################
def anoboyus():
    max_retrieve = 4
    feed = feedparser.parse("https://anogami.com/feed/") # Buat naruh webnya pastikan Url webnya ini feed rss
    feed_title = feed['feed']['title']
    feed_entries = feed.entries
    love = list()
    you_me = 1
    for entry in feed.entries:
        article_title = entry.title
        article_link = entry.link
        article_published_at = entry.published
        article_published_at_parsed = entry.published_parsed
        love.append('<f x09FF0000="1">{}. <f x099999FF="1">{} - <f x09CC66CC="1">{} <f x09FF0000="1">'.format(you_me, article_title, entry.link))
        if len(love) >= max_retrieve:
            break
        you_me += 1
    return 'New Post on <b>Anogami.com:</b> \r '+'\r'.join(love)
