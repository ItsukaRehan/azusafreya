import urllib
import ch
import time
import re
import sys
import json
from xml.etree import cElementTree as ET
if sys.version_info[0] > 2:
    import urllib.request as urlreq
else:
    import urllib2 as urlreq

import json
import random

global bahasa, key
key = "ripkzr123" #### KEY #######
bahasa = "azusafreya"

def set(x):
    global bahasa
    bahasa = x
    
def SimSimi(kalimat):
    g = "wkwkwkwkwkwk itu artinya hahahahahaha"
    kata = kalimat.replace(" ","+")
    try:
        data = urllib.request.urlopen("http://sandbox.api.simsimi.com/request.p?key=%s&lc=%s&ft=1.0&text=%s" % (key, bahasa, kata)).read().decode('utf-8')
        jsondata = json.loads(data)
        respon = jsondata["response"]
        if "I HAVE NO RESPONSE" in respon:
            respon = g
    except Exception as e:
        respon = g
    return respon
