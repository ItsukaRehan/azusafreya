from threading import Thread
import sys
import re
import json
import feedparser
from urllib.parse import quote
import urllib.request  as urllib2 
from urllib.request import unquote
import time
if sys.version_info[0] > 2:
  import urllib.request as urlreq
else:
  import urllib2 as urlreq
from time import localtime, strftime

from xml.etree import cElementTree as ET
if sys.version_info[0] > 2:
  import urllib.request as urlreq
else:
  import urllib2 as urlreq

if sys.version_info[0] < 3:
    class urllib:
        parse = __import__("urllib")
        request = __import__("urllib2")
else:
    import urllib.request
    import urllib.parse



def nyan():
    feed = feedparser.parse("http://nyansubs.tech/feed/")
    feed_title = feed['feed']['title']
    data = feed.entries
    return data



class AutoUpdate:
    
    def setChatango(self,  chatango):
        self.chatango = chatango
        
    def __init__(self):
        self.chatango = None
        self.old_post = {"nysubs": None
                         }
        self.new_post = {"nysubs": None
                         }
        self.background_task_cancelled = False
        thread_update = Thread(target=self.background_task)
        thread_update.daemon = True
        thread_update.start()
        #self.background_task_cancelled = True
        
    def background_task(self):
        while not self.background_task_cancelled:
            self.nyansubs()
            time.sleep(10)



    def nyansubs(self):
      try:
        self.new_post["nysubs"] = nyan()
        rooms = ["queenslounge"]
        if self.old_post["nysubs"] != None:
            post = []
            for data in self.new_post["nysubs"]:
                if data not in self.old_post["nysubs"]:
                    post.append(data)
            if len(post) > 0: 
                newset = []
                num = 1
                for  love, you in post:
                    newset.append("%s. %s - %s" % (num, you, love))
                    num += 1 
                for room in rooms:
                    if self.chatango:
                        self.chatango.getRoom(room).message("New Post on <b><u>nyansubs.tech</u></b> :<br/>"+"<br/>".join(newset[0:5]), True)
        self.old_post["nysubs"] = self.new_post["nysubs"]
      except:
        pass
