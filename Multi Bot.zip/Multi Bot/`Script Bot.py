#################################################################################################################
import ch
import sys
import re
import json
import feedparser
import AllScriptWebsite
#import AllScriptNewPostWebsite
import random
import time
import datetime
import os
import urllib
from xml.etree import cElementTree as ET
if sys.version_info[0] > 2:
  import urllib.request as urlreq
else:
  import urllib2 as urlreq

botname = 'azusafreya' ##isi idnya'
password = 'ripkzr123' ##isi paswordnya

################
## nick names ##
################

def sntonick(username):
    user = username.lower()
    if user in nicks:
        nick = json.loads(nicks[user])
        return nick
    else:
        return user

################################################################
#### Returns the number of seconds since the program started. ##
################################################################

def getUptime():
    # do return startTime if you just want the process start time
    return time.time() - startTime

def reboot():
    output = ("rebooting server . . .")
    os.popen("sudo -S reboot")
    return output

#######################
#### SYSTEM UPTIME ####
#######################

def uptime():
 
     total_seconds = float(getUptime())
 
     # Helper vars:
     MINUTE  = 60
     HOUR    = MINUTE * 60
     DAY     = HOUR * 24
 
     # Get the days, hours, etc:
     days    = int( total_seconds / DAY )
     hours   = int( ( total_seconds % DAY ) / HOUR )
     minutes = int( ( total_seconds % HOUR ) / MINUTE )
     seconds = int( total_seconds % MINUTE )
 
     # Build up the pretty string (like this: "N days, N hours, N minutes, N seconds")
     string = ""
     if days > 0:
         string += str(days) + " " + (days == 1 and "day" or "days" ) + ", "
     if len(string) > 0 or hours > 0:
         string += str(hours) + " " + (hours == 1 and "hour" or "hours" ) + ", "
     if len(string) > 0 or minutes > 0:
         string += str(minutes) + " " + (minutes == 1 and "minute" or "minutes" ) + ", "
     string += str(seconds) + " " + (seconds == 1 and "second" or "seconds" )
 
     return string;

########################
#### SYSTEM Rainbow ####
########################

def rainbow(word):
    length = len(word)
      #set rgb values
    r = 255 #rgb value set to red by default
    g = 0
    b = 0
    sub = int(1200/length)
    counter = 0
    string = ""
    for x in range(0, length):
        letter = word[counter]
        s = '<f x12%02X%02X%02X="times new roman">%s' % (r, g, b, letter)
        string = string+s
        counter+=1
        if (r == 255) and (g >= 0) and (b == 0):#if all red
            g = g+sub
            if g > 255: g = 255
        if (r > 0) and (g == 255) and (b == 0): #if some red and all green
            r = r-sub                           #reduce red to fade from yellow to green
            if r<0: r = 0                       #if red gets lower than 0, set it back to 0
        if (r == 0) and (g == 255) and (b >= 0):
            b = b+sub
            if b>255:
                b = 255
                trans = True
        if (r == 0) and (g > 0) and (b == 255):
            g = g-sub
            if g<0: g = 0
        if (r >= 0) and (g == 0) and (b == 255):
            r = r+sub
            if r>255: r = 255
    return string

def rainbowtebal(word):
    length = len(word)
      #set rgb values
    r = 255 #rgb value set to red by default
    g = 0
    b = 0
    sub = int(765/length)
    counter = 0
    string = ""
    for x in range(0, length):
        letter = word[counter]
        s = '<f x10%02X%02X%02X="arial"><b>%s</b>' % (r, g, b, letter)
        string = string+s
        counter+=1
        if (r == 255) and (g >= 0) and (b == 0):#if all red
            g = g+sub
            if g > 255: g = 255
        if (r > 0) and (g == 255) and (b == 0): #if some red and all green
            r = r-sub                           #reduce red to fade from yellow to green
            if r<0: r = 0                       #if red gets lower than 0, set it back to 0
        if (r == 0) and (g == 255) and (b >= 0):
            b = b+sub
            if b>255:
                b = 255
                trans = True
        if (r == 0) and (g > 0) and (b == 255):
            g = g-sub
            if g<0: g = 0
        if (r >= 0) and (g == 0) and (b == 255):
            r = r+sub
            if r>255: r = 255
    return string

################################################################
#### Returns the number of seconds since the program started. ##
################################################################

def getUptime():
  """
  Returns the number of seconds since the programs started.
  """
    # do return startTime if you just want the process start time
  return time.time() - startTime

def reboot():
    output = ("rebooting server . . .")
    os.popen("sudo -S reboot")
    return output

#######################
#### SYSTEM UPTIME ####
#######################

def uptime():

  try:
    f = open( "/proc/uptime")
    contents = f.read().split()
    f.close()
  except:
    return "Cannot open uptime file"

  total_seconds = float(contents[0])

  # Helper vars:
  MINUTE = 60
  HOUR = MINUTE * 60
  DAY = HOUR * 24

  # Get the days, hours, etc:
  days = int( total_seconds / DAY )
  hours = int( ( total_seconds % DAY ) / HOUR )
  minutes = int( ( total_seconds % HOUR ) / MINUTE )
  seconds = int( total_seconds % MINUTE )

  # Build up the pretty string (like this: "N days. N hours, N minutes, N seconds")
  string = ""
  if days > 0:
    string += str(days) + " " + (days == 1 and "day" or "days" ) + ", "
  if len(string) > 0 or hours > 0:
    string += str(hours) + " " + (hours == 1 and "hour" or "hours" ) + ", "
  if len(string) > 0 or minutes > 0:
    string += str(minutes) + " " + (minutes == 1 and "minute" or "minutes" ) + ", "
  string += str(seconds) + " " + (seconds == 1 and "second" or "seconds" )

  return string;

  def onMessage(self, room, user, message):
   print('IP: '+message.ip+'  Nama:'+user.name+': '+message.body+' PUID: '+message.puid+'')
   if user.name in blacklist: return
   if self.getAccess(user) < 2 and room.name in locks: return
   if user.name in autodel: room.clearUser(ch.User(user.name))
   
def gisu(args):
    search = args.split()
    url = urllib.request.urlopen("https://www.googleapis.com/customsearch/v1?q=%s&part=snippet&key=AIzaSyD237VSvwgQQB91jSwjCfkDCyZa4PGlYVI&cx=002748266269231051551:hxnju5unac8&searchType=image&num=10" % "+".join(search))
    udict = url.read().decode('utf-8')
    data = json.loads(udict)
    nest = []
    for d in data["items"]:
      nest.append(d)
    pick=random.choice(nest)
    imagelink = pick["link"]
    k = (imagelink)
    print(k)
    return k
    
def gis(cari):
  argss = cari
  args = argss.split()
  headers = {}
  headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
  req = urllib.request.Request("https://search.aol.com/aol/image?q=" + "+".join(args), headers = headers)
  resp = urllib.request.urlopen(req).read().decode("utf-8").replace('\/','/')
  anjay = re.findall('"iurl":"(.*?)"', resp)
  setter = list()
  la = ",".join(anjay)
  a = la
  q = 1
  setter.append(la)
  return "Search result for <b>"+cari+"</b>:<br/><br/>"+"<br/>".join(setter[1:3])

def yts(args):
  try:
    search = args.split()
    url = urllib.request.urlopen("https://www.googleapis.com/youtube/v3/search?q=%s&part=snippet&key=AIzaSyD237VSvwgQQB91jSwjCfkDCyZa4PGlYVI" % "+".join(search))
    udict = url.read().decode('utf-8')
    data = json.loads(udict)
    nest = []
    for d in data["items"]:
      nest.append(d)
    pick=random.choice(nest)
    link = "http://www.youtube.com/watch?v=" + pick["id"]["videoId"]
    title = pick["snippet"]["title"]
    uploader = pick["snippet"]["channelTitle"]
    descript = pick["snippet"]['description']
    count    = d["snippet"]["publishedAt"]
    k = "Result: %s <br/><br/><br/><br/><br/><br/><br/><br/><font color='#ffcc00'><b>%s</b></font><br/><font color='#ff0000'><b>Uploader</b></font>:<b> %s</b><br/><font color='#ff0000'><b>Uploaded on</b></font>: %s<br/><font color='#ff0000'><b>Descriptions</b></font>:<i> %s ...</i><br/> " % (link, title, uploader, count, descript[:200])
    print(k)
    return k
  except Exception as e:
    return "Nu am gasit nimic pentru "+args

def tube(args):
  """
  #In case you don't know how to use this function
  #type this in the python console:
  >>> tube("pokemon dash")
  #and this function would return this thing:
  {'title': 'TAS (DS) PokÃ©mon Dash - Regular Grand Prix', 'descriptions': '1st round Grand Prix but few mistake a first time. Next Hard Grand Prix will know way and few change different PokÃ©mon are more faster and same course Cup.', 'uploader': 'EddieERL', 'link': 'http://www.youtube.com/watch?v=QdvnBmBQiGQ', 'videoid': 'QdvnBmBQiGQ', 'viewcount': '2014-11-04T15:43:15.000Z'}
  """
  search = args.split()
  url = urlreq.urlopen("https://www.googleapis.com/youtube/v3/search?part=snippet&key=AIzaSyD237VSvwgQQB91jSwjCfkDCyZa4PGlYVIq=%s" % "+".join(search))
  udict = url.read().decode('utf-8')
  data = json.loads(udict)
  rest = []
  for f in data["items"]:
    rest.append(f)
  
  d = random.choice(rest)
  link = "http://www.youtube.com/watch?v=" + d["id"]["videoId"]
  videoid = d["id"]["videoId"]
  title = d["snippet"]["title"]
  uploader = d["snippet"]["channelTitle"]
  descript = d["snippet"]['description']
  count    = d["snippet"]["publishedAt"]
  return "Result: %s <br/><br/><br/><br/><br/><br/><br/><br/><font color='#ffcc00'><b>%s</b></font><br/><font color='#ff0000'><b>Uploader</b></font>:<b> %s</b><br/><font color='#ff0000'><b>Uploaded on</b></font>: %s<br/><font color='#ff0000'><b>Descriptions</b></font>:<i> %s ...</i><br/> " % (link, title, uploader, count, descript[:200])
def sntonick(username):
    user = username.lower()
    if user in nicks:
        nick = json.loads(nicks[user])
        return nick
    else:
        return user

##search af data##
def gs(cari):
  args = cari.split()
  headers = {}
  headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
  req = urllib.request.Request("https://www.google.co.id/search?q=" + "+".join(args), headers = headers)
  resp = urllib.request.urlopen(req).read().decode("utf-8").replace('\n','').replace('\r','').replace('\t','').replace('http://','gs:').replace('https://','gs:')
  anjay = re.findall('<h3 class="r">(.*?)</h3>', resp)
  setter = list()
  la = "".join(anjay)
  a = re.findall('<a href="gs:(.*?)" onmousedown="(.*?)">(.*?)</a>', la)
  q = 1
  for link, fak, title in a:
      setter.append('(<b>%s</b>). <b>%s</b>: http://%s' % (q, title.capitalize(), link))
      q += 1
  return "Search result for <b>"+cari+"</b>:<br/><br/>"+"<br/>".join(setter[0:5])
def newCi():
 headers = {}
 headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
 req = urllib.request.Request("http://cinemaindo.online/", headers = headers)
 resp = urllib.request.urlopen(req).read().decode("utf-8").replace('\n','').replace('\r','').replace('\t','')
 wa = re.findall("<a href='(.*?)'>"+'(.*?)<img width="(.*?)" height="(.*?)" src="(.*?)" class="attachment-full size-full wp-post-image" alt="(.*?)"',resp)
 newset = []
 q = 1
 for link, c, w, h, s, a in wa:
  newset.append('(<b>%s</b>). <b>%s</b>: %s' % (q, a, link))
  q += 1
 return "<br/>".join(newset[0:10])

def newLk():
  a = urlreq.Request ("http://layarkaca21.tv/", headers={'User-Agent' : "Magic Browser"})
  b = urlreq.urlopen(a)
  bc = b.read().decode("utf-8")
  c = re.findall('<div class="thumbnail"><a href="(.*?)" title="(.*?)" rel="bookmark">', bc)
  zw = list()
  q = 1
  for link, title in c:
      tete = title.replace("Nonton","")
      zw.append("(<b>%s</b>). <b>%s</b>: %s" % (q, tete.replace("Film Subtitle Indonesia Streaming Movie Download",""), link))
      q = q+1
  return "<br/>".join(zw[0:10])

def serLk(args):
  a = urlreq.Request ("http://layarkaca21.tv/search/"+"+".join(args.split()), headers={'User-Agent' : "Magic Browser"})
  b = urlreq.urlopen(a)
  bc = b.read().decode("utf-8")
  c = re.findall('<h2 itemprop="name"><a href="(.*?)" title="(.*?)" rel="bookmark" itemprop="url">(.*?)</a>', bc)
  zw = list()
  q = 1
  for link, title, d in c:
      tete = title.replace("Nonton","")
      zw.append("(<b>%s</b>). <b>%s</b>: %s" % (q, tete.replace("Film Subtitle Indonesia Streaming Movie Download",""), link))
      q = q+1
  return "<br/>".join(zw[0:10])


def getBGTime(x):
                    total_seconds = float(x - time.time())
                    MIN     = 60
                    HOUR    = MIN * 60
                    DAY     = HOUR * 24
                    YEAR    = DAY * 365.25
                    years   = int( total_seconds / YEAR )      
                    days    = int( (total_seconds % YEAR ) / DAY  )
                    hrs     = int( ( total_seconds % DAY ) / HOUR )
                    min = int( ( total_seconds  % HOUR ) / MIN )
                    secs = int( total_seconds % MIN )
                    string = ""
                    if years > 0: string += "<font color='#00ffff'>" + str(years) + "</font> " + (years == 1 and "year" or "years" ) + ", "
                    if len(string) > 0 or days > 0: string += "<font color='#00ffff'>" + str(days) + "</font> " + (days == 1 and "day" or "days" ) + ", "
                    if len(string) > 0 or hrs > 0: string += "<font color='#00ffff'>" + str(hrs) + "</font> " + (hrs == 1 and "hour" or "hours" ) + ", "
                    if len(string) > 0 or min > 0: string += "<font color='#00ffff'>" + str(min) + "</font> " + (min == 1 and "minute" or "minutes" ) + " and "
                    string += "<font color='#00ffff'>" +  str(secs) + "</font> " + (secs == 1 and "second" or "seconds" )
                    return string;
 
def getSTime(x):
                    total_seconds = float(time.time() - x)
                    MIN     = 60
                    HOUR    = MIN * 60
                    DAY     = HOUR * 24        
                    days    = int( total_seconds / DAY )
                    hrs     = int( ( total_seconds % DAY ) / HOUR )
                    min = int( ( total_seconds  % HOUR ) / MIN )
                    secs = int( total_seconds % MIN )
                    string = ""
                    if days > 0: string += "<font color='#00ffff'>" + str(days) + "</font> " + (days == 1 and "day" or "days" ) + ", "
                    if len(string) > 0 or hrs > 0: string += "<font color='#00ffff'>" + str(hrs) + "</font> " + (hrs == 1 and "hour" or "hours" ) + ", "
                    if len(string) > 0 or min > 0: string += "<font color='#00ffff'>" + str(min) + "</font> " + (min == 1 and "minute" or "minutes" ) + " and "
                    string += "<font color='#00ffff'>" +  str(secs) + "</font> " + (secs == 1 and "second" or "seconds", True)
                    return string;

def bgtime(x):
        try:
                x = user if len(x) == 0 else x
                html = urlreq.urlopen("http://st.chatango.com/profileimg/%s/%s/%s/mod1.xml" % (x.lower()[0], x.lower()[1], x.lower())).read().decode()
                inter = re.compile(r'<d>(.*?)</d>', re.IGNORECASE).search(html).group(1)
                if int(inter) < time.time():
                        lbgtime = getSTime(int(inter))
                        return "that users bg ran out %s ago" % lbgtime
                else: return "bgtime for <b>%s</b>: %s" % (x.lower(), getBGTime(int(inter)))
        except: return 'that user never had a background'
def bgtime2(x):
        try:
                x = user if len(x) == 0 else x
                html = urlreq.urlopen("http://st.chatango.com/profileimg/%s/%s/%s/mod1.xml" % (x.lower()[0], x.lower()[1], x.lower())).read().decode()
                inter = re.compile(r'<d>(.*?)</d>', re.IGNORECASE).search(html).group(1)
                if int(inter) < time.time():
                        lbgtime = getSTime(int(inter))
                        return "that users bg ran out %s ago" % lbgtime
                else: return "bgtime for <b>%s</b>: %s" % (x.lower(), getBGTime(int(inter)))
        except:return "that user never had a background"

##############
### MY WEB ###
##############
def Slnime_new():
    max_retrieve = 4
    feed = feedparser.parse("https://slnime.blogspot.co.id/feeds/posts/default?alt=rss")
    feed_title = feed['feed']['title']
    feed_entries = feed.entries
    love = list()
    you_me = 1
    for entry in feed.entries:
        article_title = entry.title
        article_link = entry.link
        article_published_at = entry.published # Unicode string
        article_published_at_parsed = entry.published_parsed # Time object
        love.append('<f x09FF0000="1">{}. <f x099999FF="1">{} - <f x09CC66CC="1">{} <f x09FF0000="1">'.format(you_me, article_title, entry.link))
        if len(love) >= max_retrieve:
            break
        you_me += 1
    return '<br/><br/><b>[</b> New Post di <b>Streaming Lagi-Nime ]</b> \r '+'\r'.join(love)

def Slnime_new1():
    max_retrieve = 1
    feed = feedparser.parse("https://slnime.blogspot.co.id/feeds/posts/default?alt=rss")
    feed_title = feed['feed']['title']
    feed_entries = feed.entries
    love = list()
    you_me = 1
    for entry in feed.entries:
        article_title = entry.title
        article_link = entry.link
        article_published_at = entry.published # Unicode string
        article_published_at_parsed = entry.published_parsed # Time object
        love.append('<f x09FF0000="1">{}. <f x099999FF="1">{} - <f x09CC66CC="1">{} <f x09FF0000="1">'.format(you_me, article_title, entry.link))
        if len(love) >= max_retrieve:
            break
        you_me += 1
    return '<b>[</b> New Post di <b>Streaming Lagi-Nime ]</b> \r '+'\r'.join(love)

##############
## Pars Def ##
##############

def pars(args):
          args=args.lower()
          userlist = roomUsers()
          for name in userlist:
            if args in name:return name
def roompars(args):
          args = args.lower()
          for name in self.roomnames:
            if args in name:return name
def roomUsers():
          usrs = []
          gay = []
          prop = 0
          prop = prop + len(room._userlist) - 1
          for i in room._userlist:
            i = str(i)
            usrs.append(i)
          while prop >= 0:
            j = usrs[prop].replace("<User: ", "")
            i = j.replace(">", "")
            gay.append(i)
            prop = prop - 1
          return gay
        
def getParticipant(arg):
          rname = self.getRoom(arg)
          usrs = []
          gay = []
          finale = []
          prop = 0
          prop = prop + len(rname._userlist) - 1
          for i in rname._userlist:
            i = str(i)
            usrs.append(i)
          while prop >= 0:
            j = usrs[prop].replace("<User: ", "")
            i = j.replace(">", "")
            gay.append(i)
            prop = prop - 1
          for j in gay:
            if j not in finale:
              finale.append(j)
          return finale
 
class TestBot(ch.RoomManager):
  def onInit(self):
    self.setNameColor("666666")
    self.setFontColor("333333")
    self.setFontFace("Comic")
    self.setFontSize(11)
    self.enableBg()
    self.enableRecording()

##########
# script #
##########
print ("[Script]  By : Ryan Adi Pratama       |MultiBot|")
print ("[Webs]    in : slnime.blogspot.com")
print ("[Webs.C]  in : sl-nime.chatango.com")
print ("[Webs.SC] in : smatag.chatango.com")            ##############
print ("[Update]  in : Minggu,20/05/2018")              # tgl update #
time.sleep(1)                                           ##############  
print ("")
print ("                            | SCANNING DATA |")
print ("")
time.sleep(3)
time.sleep(2)
time.sleep(1)
############
## Owners ##
############
owners = []
try:
    file = open("owners.txt", "r")
    for name in file.readlines():
        if len(name.strip()) > 0:
            owners.append(name.strip())
    print("[INFO]Daftar Rank [5] Owners    |Clear...| : %s" % (", ".join(owners)))
    file.close()
except:
    print("[ERROR]Owners tidak dapat dimuat")
    print("2 second to read the error")
    time.sleep(2)
    time.sleep(1)
    exit()
time.sleep(1)

###########
## Admin ##
###########

admin = []
try:
    file = open("admin.txt", "r")
    for name in file.readlines():
        if len(name.strip()) > 0:
            admin.append(name.strip())
    print("[INFO]Daftar Rank [4] Admin     |Clear...| : %s" % (", ".join(admin)))
    file.close()
except:
    print("[ERROR]Daftar Admin tidak dapat dimuat")
    print("2 second to read the error")
    time.sleep(2)
    exit()
time.sleep(1)

##############
## Co-Admin ##
##############

coadmin = []
try:
    file = open("coadmin.txt", "r")
    for name in file.readlines():
        if len(name.strip()) > 0:
            coadmin.append(name.strip())
    print("[INFO]Daftar Rank [3] Co-Admin  |Clear...| : %s" % (", ".join(coadmin)))
    file.close()
except:
    print("[ERROR]Daftar Co-Admin tidak dapat dimuat : %s" % (", ".join(coadmin)))
    print("2 second to read the error")
    time.sleep(2)
    time.sleep(1)
    print(" %s" % line)
    exit()
time.sleep(1)

###############
## Moderator ##
###############

moderator = []
try:
    file = open("moderator.txt", "r")
    for name in file.readlines():
        if len(name.strip()) > 0:
            moderator.append(name.strip())
    print("[INFO]Daftar Rank [2] Moderator |Clear...|")
    file.close()
except:
    print("[ERROR]Daftar Moderator tidak dapat dimuat : %s" % (", ".join(moderator)))
    print("3 second to read the error")
    time.sleep(3)
    time.sleep(2)
    time.sleep(1)
    print(" %s" % line)
time.sleep(1)

###############
## Whitelist ##
###############

whitelist = []
try:
    file = open("whitelist.txt", "r")
    for name in file.readlines():
        if len(name.strip()) > 0:
            whitelist.append(name.strip())
    print("[INFO]Daftar Rank [1] WhiteList |Clear...|")
    file.close()
except:
    print("[ERROR]WhiteList tidak dapat dimuat")
    print("3 second to read the error")
    time.sleep(3)
    time.sleep(2)
    time.sleep(1)
    print(" %s" % line)
time.sleep(1)

    ##########
    # HiddenList #
    ##########

hiddenlist = []
try:
    file = open("hiddenlist.txt", "r") # read-onlyimport
    for name in file.readlines():
        if len(name.strip()) > 0:
            hiddenlist.append(name.strip())
    print("[INFO]Daftar Rank [1] HiddenList|Clear...|")
    file.close()
except:
    print("[ERROR]Daftar HiddenList tidak dapat dimuat")
    print("3 second to read the error")
    time.sleep(3)
    time.sleep(2)
    time.sleep(1)
    print(" %s" % line)
time.sleep(1)

#############
## Netizen ##
#############

netizen = []
try:
    file = open("netizen.txt", "r")
    for name in file.readlines():
        if len(name.strip()) > 0:
            netizen.append(name.strip())
    print("[INFO]Daftar Rank [0] Netizen   |Clear...|")
    file.close()
except:
    print("[ERROR]Daftar Netizen tidak dapat dimuat")
    print("3 second to read the error")
    time.sleep(3)
    time.sleep(2)
    time.sleep(1)
    print(" %s" % line)
time.sleep(1)

################
### AutoDell ###
################

autodel = []
f = open("autodel.txt", "r")
print("[INFO]Daftar AutoDelete List    |Clear...|")
time.sleep(0.2)
for name in f.readlines():
        if len(name.strip()) > 0: autodel.append(name.strip())
f.close()
time.sleep(1)

###############
## BlackList ##
###############

blacklist = ()
try:
    file = open("blacklist.txt","r")
    for name in file.readlines():
        if len(name.strip()) > 0:
            blacklist.append(name.strip())
    print("[INFO]Daftar BlackList          |Clear...|")
    file.close()
except:
    print("[INFO]Daftar BlackList          |ERROR..!|")
    print("3 second to read the error")
    time.sleep(3)
    time.sleep(2)
    time.sleep(1)
    print(" %s" % line)
    exit()
time.sleep(1)

###########
## Nicks ##
###########

nicks = dict()
try:
    f=open ("nicks.txt","r")
    for line in f.readlines():
        if len(line.strip())>0:
            user , nick = json.loads(line.strip())
            nicks[user] = json.dumps(nick)
    print("[INFO]Daftar Panggilan          |Clear...|")
    f.close()
except:
    print("[INFO]Daftar Panggilan          |ERROR..!|")
    print("2 second to read the error")
    time.sleep(2)
    time.sleep(1)
    print(" %s" % line)
    exit()
time.sleep(1)

############
## See IP ##
############
ip_whois = dict()
try:
  f = open("ip_whois.txt", "r")
  ip_whois = eval(f.read())
  f.close()
except:pass
unid_ver = dict()
try:
  f = open("unid_ver.txt", "r")
  ip_whois = eval(f.read())
  f.close()
except:pass
print("[INFO]Daftar IP Address User    |Clear...|")
time.sleep(1)

#############
## User IP ##
#############
userip = dict()
try:
  f = open("userip.txt", "r")
  userip = eval(f.read())
  f.close()
except:pass
print("[INFO]Daftar Catatan IP Address |Clear...|")
time.sleep(1)

################
## Check User ##
################

sid_whois = dict()
try:
  f = open("sid_whois.txt", "r")
  sid_whois = eval(f.read())
  f.close()
except:pass
print("[INFO]Daftar Kesamaan IP Address|Clear...|")
time.sleep(1)

#################
## DEFINITIONS ##
#################

dictionary = dict() 
try:
    f = open("definitions.txt", "r")
    for line in f.readlines():
      if len(line.strip())>0:
          word, definition, name = json.loads(line.strip())
          dictionary[word] = json.dumps([definition, name])
    print("[INFO]Daftar Catatan            |Clear...|")
    f.close()
except:
    print("[INFO]Daftar Catatan            |ERROR..!|")
    print("2 second to read the error")
    time.sleep(2)
    time.sleep(1)
    print(" %s" % line)
    exit()
time.sleep(1)

###########
## Rooms ##
###########

rooms = []
try:
    file = open("rooms.txt", "r") # read-only
    for name in file.readlines():
        if len(name.strip())>0:
            rooms.append(name.strip())
    print("[INFO]Daftar Website            |Clear...|")
    f.close()
except:
    print("[INFO]Daftar Website            |ERROR..!|")
    print("2 second to read the error")
    print(" %s" % line)
    time.sleep(2)
    time.sleep(1)
    exit()
time.sleep(1)

    #######
    # END #
    #######
#SN TRY
sn = dict()
try:
  f = open('note.txt','r')
  sn = eval(f.read())
  f.close()
except:pass
print("[INFO]Daftar Note               |Clear...|")
time.sleep(1)
###################
# Starting Script #
###################
print("[INFO]Progam dimulai dalam 5 detik...")
time.sleep(3)
time.sleep(2)
time.sleep(1)
print("")
print("                          |...Starting Progam...|")
print("")
time.sleep(2)
time.sleep(1)
##################
## Dance moves! ##
##################
#kinda useless

blacklist = ["abcd"]
blackrooms = [""]

dancemoves = ["(>^.^)>",  "(v^.^)v",]
song = [] 
bete = ["kunci",]
pagi = ["ohayou oni-chan",]

# SN Notifs
notif = []
f = open("notif.txt", "r")
for name in f.readlines():
  if len(name.strip())>0: notif.append(name.strip())
f.close

blacklist = []
f = open("blacklist.txt", "r")
for name in f.readlines():
  if len(name.strip())>0: blacklist.append(name.strip())
f.close()

def tube(args):
  """
  #In case you don't know how to use this function
  #type this in the python console:
  >>> tube("pokemon dash")
  #and this function would return this thing:
  {'title': 'TAS (DS) PokÃ©mon Dash - Regular Grand Prix', 'descriptions': '1st round Grand Prix but few mistake a first time. Next Hard Grand Prix will know way and few change different PokÃ©mon are more faster and same course Cup.', 'uploader': 'EddieERL', 'link': 'http://www.youtube.com/watch?v=QdvnBmBQiGQ', 'videoid': 'QdvnBmBQiGQ', 'viewcount': '2014-11-04T15:43:15.000Z'}
  """
  search = args.split()
  url = urlreq.urlopen("https://www.googleapis.com/youtube/v3/search?q=%s&part=snippet&key=AIzaSyBSnh-sIjd97_FmQVzlyGbcaYXuSt_oh84" % "+".join(search))
  udict = url.read().decode('utf-8')
  data = json.loads(udict)
  rest = []
  for f in data["items"]:
    rest.append(f)
  
  d = random.choice(rest)
  link = "http://www.youtube.com/watch?v=" + d["id"]["videoId"]
  videoid = d["id"]["videoId"]
  title = d["snippet"]["title"]
  uploader = d["snippet"]["channelTitle"]
  descript = d["snippet"]['description']
  count    = d["snippet"]["publishedAt"]
  return "Result: %s <br/><br/><br/><br/><br/><br/><br/><br/><font color='#ffcc00'><b>%s</b></font><br/><font color='#ff0000'><b>Uploader</b></font>:<b> %s</b><br/><font color='#ff0000'><b>Uploaded on</b></font>: %s<br/><font color='#ff0000'><b>Descriptions</b></font>:<i> %s ...</i><br/> " % (link, title, uploader, count, descript[:200])

def gs(cari):
  args = cari.split()
  headers = {}
  headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
  req = urllib.request.Request("https://www.google.co.id/search?q=" + "+".join(args), headers = headers)
  resp = urllib.request.urlopen(req).read().decode("utf-8").replace('\n','').replace('\r','').replace('\t','').replace('http://','gs:').replace('https://','gs:')
  anjay = re.findall('<h3 class="r">(.*?)</h3>', resp)
  setter = list()
  la = "".join(anjay)
  a = re.findall('<a href="gs:(.*?)" onmousedown="(.*?)">(.*?)</a>', la)
  q = 1
  for link, fak, title in a:
      setter.append('(<b>%s</b>). <b>%s</b>: http://%s' % (q, title.capitalize(), link))
      q += 1
  return "Search result for <b>"+cari+"</b>:<br/><br/>"+"<br/>".join(setter[0:5])

def saveRank():
    f = open("owners.txt","w")
    f.write("\n".join(owners))
    f.close()
    f = open("admin.txt","w")
    f.write("\n".join(admin))
    f.close()
    f = open("coadmin.txt","w")
    f.write("\n".join(admin))
    f.close()
    f = open("moderator.txt","w")
    f.write("\n".join(moderator))
    f.close()
    f = open("whitelist.txt","w")
    f.write("\n".join(whitelist))
    f.close()
    f = open("hiddenlist.txt","w")
    f.write("\n".join(hiddenlist))
    f.close()
    f = open("netizen.txt","w")
    f.write("\n".join(netizen))
    f.close()


###########################    
## Setting Pretty Colors ##
###########################
    
class TestBot(ch.RoomManager):
  
  def onInit(self):
    self.setNameColor("BF00FF")
    self.setFontColor("FF00FF")
    self.setFontFace("1")
    self.setFontSize(12)
    self.enableBg()
    self.enableRecording()
			      

#####################
## Connecting Crap ##
#####################
   
  def onConnect(self, room):
    print("Connected "+str(room.name))
  
  def onReconnect(self, room):
    print("Reconnected"+str(room.name))
  
  def onDisconnect(self, room):
    print("Disconnected"+str(room.name))

####################################################################
### Get user access from the file, and retun lvl of access number###
####################################################################

  def getAccess(self, user):
    if user.name in owners: return 5 # Owners
    elif user.name in admin: return 4 # Admins
    elif user.name in coadmin: return 3 # Co-Admins
    elif user.name in moderator: return 2 # Arch Knight
    elif user.name in whitelist: return 1 # WhiteList
    elif user.name in hiddenlist: return 1 # HiddenList
    elif user.name in netizen: return 1 # Netizen
    else: return 0

#############################################################################   
############# Ignore this, you dont need to worry about this ################
#Well, you can actually take a little time to look at it and learn something#
#############################################################################
    
  def onMessage(self, room, user, message):
   try:
    msgdata = message.body.split(" ",1)
    if len(msgdata) > 1:
      cmd, args = msgdata[0], msgdata[1]
    else:
      cmd, args = msgdata[0],""
      cmd=cmd.lower() 
    global lockdown
    global newnum
    print("[Chat] "+user.name+" - "+message.body)
    if user.name not in netizen and user.name not in hiddenlist and user.name not in whitelist and user.name not in moderator and user.name not in coadmin and user.name not in admin  and user.name not in owners:
      netizen.append(user.name)
      f = open("netizen.txt","w")
      f.write("\n".join(netizen))
      f.close
    if user.name in notif:
        room.message(user.name+", Kamu mempunyai ("+str(len(sn[user.name]))+") pesan yang belum dibaca. ketik .rn untuk membacanya")
        notif.remove(user.name)
    if user == self.user: return

                 ##############
                 # PERKENALAN #
                 ##############
    if "Prefixnya apa" in message.body or "prefixnya apa" in message.body or "Azusa prefixnya" in message.body or "azusa prefixnya" in message.body or "Azu prefixnya" in message.body or "azu prefixnya" in message.body or "Prefixnya azu" in message.body or "prefixnya azu" in message.body or "Prefixnya azusa" in message.body or "prefixnya azusa" in message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      if botname == ("azusafreya"):
         room.reconnect()
         print("[INFO] Re-Change Account AzusaFreya")
         room.message              ("Prefix saya ( . ) titik "+"@"+sntonick(user.name))
      if botname == 'mezishi718':
         room.logout()
         room.login("azusafreya", "ripkzr123")
         print("[INFO] Change Account AzusaFreya")
         room.message              ("Prefix saya ( . ) titik "+"@"+sntonick(user.name))

    if "Azusa siapa y" in message.body or "azusa siapa y" in message.body or "Azusa siapa ya" in message.body or "azusa siapa ya" in message.body or "Azu siapa y" in message.body or "azu siapa y" in message.body or "Azu siapa ya" in message.body or "azu siapa ya" in message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      if botname == ("azusafreya"):
         room.reconnect()
         print("[INFO] Re-Change Account AzusaFreya")
         room.message              ("Salam Kenal "+"@"+sntonick(user.name)+". Nama saya Azusa Freya, panggil aja saya Freya (^_^'') ",)
      if botname == 'mezishi718':
         room.logout()
         room.login("azusafreya", "ripkzr123")
         print("[INFO] Change Account AzusaFreya")
         room.message              ("Salam Kenal "+"@"+sntonick(user.name)+". Nama saya Azusa Freya, panggil aja saya Freya (^_^'') ",)

    if "Ryanadipratama718 siapa kamu" in message.body or "ryanadipratama718 siapa kamu" in message.body or "Ryanadipratama siapa kamu" in message.body or "ryanadipratama siapa kamu" in message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      if botname == ("azusafreya"):
         room.reconnect()
         print("[INFO] Re-Change Account AzusaFreya")
         room.message              ("Oh itu kakak Freya "+sntonick(user.name)+". Freya mah adik perempuannya (^_^'') ",)
      if botname == 'mezishi718':
         room.logout()
         room.login("azusafreya", "ripkzr123")
         print("[INFO] Change Account AzusaFreya")
         room.message              ("Oh itu kakak Freya "+sntonick(user.name)+". Freya mah adik perempuannya (^_^'') ",)

    if "Mezishi718 siapa kamu" in message.body or "mezishi718 siapa kamu" in message.body or "Mezishi siapa kamu" in message.body or "mezishi siapa kamu" in message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      if botname == ("azusafreya"):
         room.reconnect()
         print("[INFO] Re-Change Account AzusaFreya")
         room.message              ("Oh itu my boyfriend "+sntonick(user.name)+". Kenapa emangnya ? (^_^'')? ",)
      if botname == 'mezishi718':
         room.logout()
         room.login("azusafreya", "ripkzr123")
         print("[INFO] Change Account AzusaFreya")
         room.message              ("Oh itu my boyfriend "+sntonick(user.name)+". Kenapa emangnya ? (^_^'')? ",)

         #################
         ### Versi Bot ###
         #################
    if "V.Freya" in message.body or "v.f" in message.body:
     room.message("bot version |Freya| : V.18.01.17")
    if "V.Mezishi" in message.body or "v.m" in message.body:
     room.message("bot version |Mezishi| : V.18.01.17")
    if "V.Couple" in message.body or "v.c" in message.body:
     room.message("bot version |Couple| : V.18.01.21")
                 #############
                 # PANGGILAN #
                 #############
    if "Kalian berdua" == message.body or "kalian berdua" == message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
        room.message (random.choice(["iya ada apa "+sntonick(user.name)+ " ? "]),True)
#############
### Freya ###
#############
  # LV:00 #
  #########
    if "Azu" == message.body or "azu" == message.body or "Azusa" == message.body or "azusa" == message.body or "Freya" == message.body or "freya" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist: 
      if botname == ("azusafreya"):
         room.reconnect()
         print("[INFO] Re-Change Account AzusaFreya")
         room.message (random.choice(["iya ada apa "+"@"+sntonick(user.name)+ " ? "]),True)
      if botname == 'mezishi718':
         room.logout()
         room.login("azusafreya", "ripkzr123")
         print("[INFO] Change Account AzusaFreya")
         room.message (random.choice(["iya ada apa "+"@"+sntonick(user.name)+ " ? "]),True)

    if "Azusa Freya" == message.body or "Azusa freya" == message.body or "azusa freya" == message.body or "Azusafreya" == message.body or "azusafreya" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist: 
      if botname == ("azusafreya"):
         room.reconnect()
         print("[INFO] Re-Change Account AzusaFreya")
         room.message (random.choice(["Apa sih manggil-manggil "+"@"+sntonick(user.name)+ " ? "]),True)
      if botname == 'mezishi718':
         room.logout()
         room.login("azusafreya", "ripkzr123")
         print("[INFO] Change Account AzusaFreya")
         room.message (random.choice(["Apa sih manggil-manggil "+"@"+sntonick(user.name)+ " ? "]),True)
  ##########
  # LV:01+ #
  ##########
    if "Azu" == message.body or "azu" == message.body or "Azusa" == message.body or "azusa" == message.body or "Freya" == message.body or "freya" == message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist: 
      if botname == ("azusafreya"):
         room.reconnect()
         print("[INFO] Re-Change Account AzusaFreya")
         room.message (random.choice(["iya ada apa "+sntonick(user.name)+ " ? "]),True)
      if botname == 'mezishi718':
         room.logout()
         room.login("azusafreya", "ripkzr123")
         print("[INFO] Change Account AzusaFreya")
         room.message (random.choice(["iya ada apa "+sntonick(user.name)+ " ? "]),True)

    if "Azusa Freya" == message.body or "Azusa freya" == message.body or "azusa freya" == message.body or "Azusafreya" == message.body or "azusafreya" == message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist: 
      if botname == ("azusafreya"):
         room.reconnect()
         print("[INFO] Re-Change Account AzusaFreya")
         room.message (random.choice(["Apa'an sih manggil-manggil "+sntonick(user.name)+ " ? "]),True)
      if botname == 'mezishi718':
         room.logout()
         room.login("azusafreya", "ripkzr123")
         print("[INFO] Change Account AzusaFreya")
         room.message (random.choice(["Apa'an sih manggil-manggil "+sntonick(user.name)+ " ? "]),True)
###############
### Mezishi ###
###############
    if "Mez" == message.body or "mez" == message.body or "Mezishi" == message.body or "mezishi" == message.body:
     if self.getAccess(user) == 1 and not self.getAccess(user) >= 1 and not user.name in blacklist: 
      if botname == ("mezishi718"):
         room.message (random.choice(["iya ada apa "+sntonick(user.name)+ " ? "]),True)
      if botname == 'azusafreya':
         room.logout()
         room.login("mezishi718", "ripkzr123")
         print("[INFO] Change Account Mezishi718")
         room.message (random.choice(["iya ada apa "+sntonick(user.name)+ " ? "]),True)

    if "Mezishi718" == message.body or "mezishi718" == message.body:
     if self.getAccess(user) == 1 and not self.getAccess(user) >= 1 and not user.name in blacklist: 
      if botname == ("mezishi718"):
         room.message (random.choice(["panggil mezishi aja "+sntonick(user.name)+ ", 718 cuma kode doang.. "]),True)
      if botname == 'azusafreya':
         room.logout()
         room.login("mezishi718", "ripkzr123")
         print("[INFO] Change Account Mezishi718")
         room.message (random.choice(["panggil mezishi aja "+sntonick(user.name)+ ", 718 cuma kode doang.. "]),True)

    if "Mez" == message.body or "mez" == message.body or "Mezishi" == message.body or "mezishi" == message.body:
     if self.getAccess(user) >= 4 and not self.getAccess(user) <= 3 and not user.name in blacklist: 
      if botname == ("mezishi718"):
         room.message (random.choice(["ada apa "+sntonick(user.name)+ " ? "]),True)
      if botname == 'azusafreya':
         room.logout()
         room.login("mezishi718", "ripkzr123")
         print("[INFO] Change Account Mezishi718")
         room.message (random.choice(["ada apa "+sntonick(user.name)+ " ? "]),True)

    if "Mezishi718" == message.body or "mezishi718" == message.body:
     if self.getAccess(user) >= 4 and not self.getAccess(user) <= 3 and not user.name in blacklist: 
      if botname == ("mezishi718"):
         room.message (random.choice([+sntonick(user.name)+ ", jangan rese -_- "]),True)
      if botname == 'azusafreya':
         room.logout()
         room.login("mezishi718", "ripkzr123")
         print("[INFO] Change Account Mezishi718")
         room.message (random.choice([+sntonick(user.name)+ ", jangan rese -_- "]),True)

    if "Mez" == message.body or "mez" == message.body or "Mezishi" == message.body or "mezishi" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) <= 2 and not user.name in blacklist: 
      if botname == ("mezishi718"):
         room.message (random.choice(["ea ada apa "+sntonick(user.name)+ " ?" ]),True)
      if botname == 'azusafreya':
         room.logout()
         room.login("mezishi718", "ripkzr123")
         print("[INFO] Change Account AzusaFreya")
         room.message (random.choice(["ea ada apa "+sntonick(user.name)+ " ?" ]),True)

    if "Mezishi718" == message.body or "mezishi718" == message.body:
     if self.getAccess(user) == 0 and not user.name in blacklist: 
      if botname == ("mezishi718"):
         room.message (random.choice([+sntonick(user.name)+ ", jangan rese -_- "]),True)
      if botname == 'azusafreya':
         room.logout()
         room.login("mezishi718", "ripkzr123")
         print("[INFO] Change Account Mezishi718")
         room.message (random.choice([+sntonick(user.name)+ ", jangan rese -_- "]),True)

                 #########
                 # SALAM #
                 #########
#Selamat Pagi
    if "Selamat Pagi" == message.body or "Selamat pagi" == message.body or "Selamat pagi" == message.body or "selamat pagi" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist:
        room.message                     ("Selamat Pagi juga, apa ada yang bisa Azu bantu...?"+ " ^_^.? "+"@"+sntonick(user.name),True)
    if "Selamat Pagi" == message.body or "Selamat pagi" == message.body or "Selamat pagi" == message.body or "selamat pagi"   == message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist: 
        room.message                     ("Selamat Pagi juga, apa ada yang bisa Azu bantu...?"+ " ^_^.? "+sntonick(user.name),True)
#Selamat Siang
    if "Selamat Siang" == message.body or "Selamat siang" == message.body or "Selamat siang" == message.body or "selamat siang" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist:
        room.message                     ("Selamat Siang juga, apa ada yang bisa Azu bantu...?"+ " ^_^.? "+"@"+sntonick(user.name),True)
    if "Selamat Siang" == message.body or "Selamat siang" == message.body or "Selamat siang" == message.body or "selamat siang" == message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist: 
        room.message                     ("Selamat Siang juga, apa ada yang bisa Azu bantu...?"+ " ^_^.? "+sntonick(user.name),True)
#Selamat Sore
    if "Selamat Sore" == message.body or "Selamat sore" == message.body or "Selamat sore" == message.body or "selamat sore" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist:
        room.message                     ("Selamat Sore juga, apa ada yang bisa Azu bantu...?"+ " ^_^.? "+"@"+sntonick(user.name),True)
    if "Selamat Sore" == message.body or "selamat sore" == message.body or "Selamat sore" == message.body or "selamat sore" == message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist: 
        room.message                     ("Selamat Sore juga, apa ada yang bisa Azu bantu...?"+ " ^_^.? "+sntonick(user.name),True)
#Selamat Malam
    if "Selamat Malam" == message.body or "Selamat malam" == message.body or "Selamat malam" == message.body or "selamat malam" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist:
        room.message                     ("Selamat Malam juga, apa ada yang bisa Azu bantu...?"+ " ^_^.? "+"@"+sntonick(user.name),True)
    if "Selamat Malam" == message.body or "Selamat malam" == message.body or "Selamat malam" == message.body or "selamat malam" == message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist: 
        room.message                     ("Selamat Malam juga, apa ada yang bisa Azu bantu...?"+ " ^_^.? "+sntonick(user.name),True)

                 ################
                 # SALAM RINGAN #
                 ################
#Pagi
    if "Pagi" == message.body or "pagi" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message("Selamat Pagi juga "+"@"+sntonick(user.name),True)
      time.sleep(3)
      time.sleep(2)
      time.sleep(1)
      room.message("Semangat melakukan aktivitas kamu ya...! ^_^ "+"@"+sntonick(user.name),True)
    if "Pagi" == message.body or "pagi" == message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message("Selamat Pagi juga "+sntonick(user.name),True)
      time.sleep(3)
      time.sleep(2)
      time.sleep(1)
      room.message("Semangat melakukan aktivitas kamu ya...! ^_^ "+sntonick(user.name),True)
#Siang
    if "Siang" == message.body or "siang" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message("Selamat Siang juga "+"@"+sntonick(user.name),True)
      time.sleep(3)
      time.sleep(2)
      time.sleep(1)
      room.message("Freya lagi ngantuk nih (--_--'';) "+"@"+sntonick(user.name),True)
      print("[INFO] Script couple ON")
      room.logout()
      room.login("mezishi718", "ripkzr123")
      time.sleep(2)
      time.sleep(1)
      room.message("Sini Freya, tidur di pangkuanku aja gapapa")
      room.reconnect()
      print("[INFO] Script couple OFF")


    if "Siang" == message.body or "siang" == message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message("Selamat Siang juga "+sntonick(user.name),True)
      time.sleep(3)
      time.sleep(2)
      time.sleep(1)
      room.message("Freya lagi ngantuk nih (--_--'';) "+sntonick(user.name),True)
      print("[INFO] Script couple ON")
      room.logout()
      room.login("mezishi718", "ripkzr123")
      time.sleep(2)
      time.sleep(1)
      room.message("Sini Freya, tidur di pangkuanku aja gapapa")
      room.reconnect()
      print("[INFO] Script couple OFF")

#Sore
    if "Sore" == message.body or "sore" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message("Selamat Sore juga "+"@"+sntonick(user.name),True)
      time.sleep(3)
      time.sleep(2)
      time.sleep(1)
      room.message("Jangan lupa mandi dulu ya...! (>,<) "+"@"+sntonick(user.name),True)

    if "Sore" == message.body or "sore" == message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message("Selamat Sore juga "+sntonick(user.name),True)
      time.sleep(3)
      time.sleep(2)
      time.sleep(1)
      room.message("Jangan lupa mandi dulu ya...! (>,<) "+sntonick(user.name),True)
#MALAM
    if "Malam" == message.body or "malam" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message("Selamat malam juga "+"@"+sntonick(user.name),True)
      time.sleep(3)
      time.sleep(2)
      time.sleep(1)
      room.message("Freya ngantuk nih mau tidur. ~.~ "+sntonick(user.name),True)

    if "Malam" == message.body or "malam" == message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message("Selamat malam juga "+sntonick(user.name),True)
      time.sleep(3)
      time.sleep(2)
      time.sleep(1)
      room.message("Freya ngantuk nih mau tidur. ~.~ "+sntonick(user.name),True)

                 ############
                 # END CHAT #
                 ############

    if "Afk" == message.body or "afk" == message.body or "Afk dulu" == message.body or "afk dulu" == message.body or "Afk bentar" == message.body or "afk bentar" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message (random.choice(["Jangan lama-lama ya "+"@"+sntonick(user.name)+" :) ",]),True)
    if "Afk" == message.body or "afk" == message.body or "Afk dulu" == message.body or "afk dulu" == message.body or "Afk bentar" == message.body or "afk bentar" == message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist: 
      room.message (random.choice(["Jangan lama-lama ya "+sntonick(user.name)+" :) "]),True)

    if "Bye" == message.body or "bye" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message (random.choice(["Bye ^_^'')/ "+"@"+sntonick(user.name)]),True)
    if "Bye" == message.body or "bye" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist:
      room.message (random.choice(["Bye ^_^'')/ "+sntonick(user.name)]),True)

    if "Off" == message.body or "off" == message.body or "Off dulu" == message.body or "off dulu" == message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message              ("Nanti mampir disini lagi ya...! (^_^'';) "+"@"+sntonick(user.name),True)
    if "Off" == message.body or "off" == message.body or "Off dulu" == message.body or "off dulu" == message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist: 
      room.message              ("Nanti mampir disini lagi ya...! (^_^'';) "+sntonick(user.name),True)

                 ##########
                 # UCAPAN #
                 ##########

    if "Terima kasih Freya" in message.body or "Terima kasih freya" in message.body or"terima kasih freya" in message.body or "Terima kasih Azu" in message.body or "Terima kasih azu" in message.body or"terima kasih azu" in message.body:
     if self.getAccess(user) == 0 and not self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message              ("Iya sama sama...! (^_^'';) "+"@"+sntonick(user.name),True)

                 #############
                 # KELEBIHAN #
                 #############

    if "Laper" in message.body or "lapar" and "laper" in message.body:
     if self.getAccess(user) >= 0 and not user.name in blacklist: 
      room.message (random.choice(["Kalo laper makanlah -_-'",]),True)
    if "Boring" in message.body or "boring" in message.body:
     if self.getAccess(user) >= 0 and not user.name in blacklist: 
      room.message (random.choice(["Lagi boring nih? mau Freya temenin ?"+sntonick(user.name),]),True)
    if "Capek" == message.body    or "capek" == message.body or "Cape" == message.body or "cape" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist:
        room.message (random.choice(["Istirahat aja dulu "+"@"+sntonick(user.name)+" :) ",]),True)
    if "Ngantuk" == message.body  or "ngantuk" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist:
        room.message (random.choice(["tidur dulu aja "+"@"+sntonick(user.name)+" :) ",]),True)
    if "Bosen" == message.body    or "bosen" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist:
        room.message (random.choice(["kalo bosen mending cari hiburan aja deh "+"@"+sntonick(user.name)+" :) ",]),True)

#Artikel Harvesmoon a Wonderfull Life
    if "Artikel Harvest Moon a Wonderfull Life" == message.body or "artikel harvest moon a wonderfull life" == message.body or "Artikel Harvest Moon aWL" == message.body or "artikel harvest moon awl" == message.body:
     if self.getAccess(user) >= 0 and not user.name in blacklist:
      room.message ("Artikel Harvest Moon a Wonderfull Life bisa anda akses dengan cara: .df daftar isi hawl")
    if "Siapa developer harvest moon a wonderfull life" == message.body or "siapa developer harvest moon a wonderfull life" == message.body or "Siapa developer Harvest Moon" == message.body or "siapa developer harvest moon" == message.body:
     if self.getAccess(user) >= 0 and not user.name in blacklist:
      room.message ("Developer Harvest Moon adalah Natsume")
    if "Apa itu harvest moon a wonderfull life" == message.body or "apa itu harvest moon a wonderfull life" == message.body or "Apa itu harvest moon a wonderfull life ?" == message.body or "apa itu harvest moon a wonderfull life ?" == message.body:
     if self.getAccess(user) >= 0 and not user.name in blacklist:
      room.message ("Harvest Moon a Wonderfull Life adalah seri game keluaran Natsume yang telah mengalami perombakan dari seri-seri sebelumnya. berikut ini adalah hal-hal yang baru di Harvest Moon a Wonderfull Life: Karakter, Hewan ternak, Hewan peliharaan, Situs penggalian, Memancing, Permainan, Mengelolah benih tanaman, Mesin pembuat pupuk, Mesin pemerah susu, Mesin pembuat keju dan mentega, Tanaman buah.")
    if "Apa itu harvest moon" == message.body or "apa itu harvest moon" == message.body or "Apa itu harvest moon ?" == message.body or "apa itu harvest moon ?" == message.body:
     if self.getAccess(user) >= 0 and not user.name in blacklist:
      room.message ("Harvest Moon merupakan game RPG yang dibuat untuk menguji kemampuan seseorang dalam mengurus dan menangani berbagai hal. Termasuk kemampuan untuk mengatur dan mengurus pekerjaan rutin sampai dengan kemampuan untuk bersosialisasi.")

                 ############
                 # CANDA'AN #
                 ############

    if "Tuh farel" in message.body or "tuh farel" in message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist: 
      room.message        ("Biarin aja si jelek itu sendiri "+sntonick (user.name)+" (--_--'';) ",True)
    if "Siapa jomblo" in message.body or "siapa jomblo" in message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message        ("Hari gini masih aja jomblo :v",)
    if "Saya jomblo" in message.body or "saya jomblo" in message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message        ("Biarin aja salah sendiri jomblo, bukan urusan Freya juga (--_--'';)",)
    if "Saya gk jomblo" in message.body or "saya gak jomblo" in message.body or "Saya gk jomblo" in message.body or "saya gk jomblo" in message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message        ("Hanya Jones Munafik yg bilang gitu. (--_--'';) ",)
    if "Dasar anak alay" in message.body or "dasar anak alay" in message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message        ("Lagian situ sendiri juga Alay"+ " (--_--'';) ",)
    if "Faedah ya?" in message.body or "faedah ya" in message.body:
     if self.getAccess(user) >= 1 and not user.name in blacklist:
      room.message        ("Bilang-bilang soal Faedah emang situ sendiri tau itu Teori darimana kok bisa di bilang gk ada Faedahnya "+ " (--_--'';) ",)

                 #############
                 # CMDS KE M #
                 #############

    if "Cara setrank bot" == message.body or "cara setrank bot" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("!df cara membuat bot",)
    if "Cara menyimpan catatan" == message.body or "cara menyimpan catatan" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("!df df",)
    if "Cara menghapus catatan" == message.body or "cara menghapus catatan" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("!df udf",)
    if "Cara menggunakan bot" == message.body or "cara menggunakan bot" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("!df cara menggunakan bot",)

                 ############
                 # SINOPSIS #
                 ############
#Sinopsis Gamers
    if "Sinopsis Gamers" in message.body or "Sinopsis gamers" in message.body or "sinopsis gamers" in message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Sinopsis Gamers : Kisah ini adalah sebuah kisah yang melibatkan beberapa orang dalam satu hobi. Keita adalah karakter utama kean yang sangat menyukai game. Uehara Tasuku adalah orang yang mengikuti jalan gamer secara rahasia dan percaya bahwa hidupnya sangat sempurna. Karen Tendou, ketua dari klub video game dan  Chiaki Hoshinomori yang selalu beradu mulut dengan Keita. Ini adalah sebuah cerita yang diisi dengan adegan komedi dan kesalahpahaman. Komedi romantis yang kacau akan segera dimulai!",)
#Sinopsis Hajimete no Gal
    if "Sinopsis Hajimete no Gal" in message.body or "Sinopsis hajimete no gal" in message.body or "sinopsis hajimete no gal" in message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Sinopsis Hajimete no Gal : Musim semi adalah musimnya cinta. Dalam musim tersebut, Junichi merasa kalau menemukan cinta ternyata lebih sulit dari perkiraannya. Untuk melepaskan diri dari status jomblonya, teman Junichi memaksanya untuk menembak seorang gal di kelasnya, Yame Yukana. Tapi, semuanya tidak berjalan sesuai rencana.",)
#Sinopsis Fate/apocrypha
    if "Sinopsis Fate/apocrypha" in message.body or "Sinopsis fate/apocrypha" in message.body or "sinopsis fate/apocrypha" in message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Sinopsis Fate/apocrypha : Di atas kota Trifas, dua faksi besar yang bersiteru untuk mendapatkan harta mulia terbesar, Cawan Suci. Faksi pertama adalah Faksi Hitam dari keluarga Yggdmillennia yang berperan untuk melindungi Cawan Suci. Faksi kedua adalah Faksi Merah dari asosiasi sihir yang berusaha untuk merebut Cawan Suci. Kedua faksi tersebut dapat memanggil masing-masing tujuh Servant untuk membantu mereka dalam sebuah perang berskala besar.  Untuk mengawasi perang suci dalam skala sebesar ini, Cawan Suci sendiri menunjuk Servant milikknya sendiri, sang penguasa suci, untuk mengawasi jalannya peperangan tersebut.",)
#Sinopsis Tsurezure Children
    if "Sinopsis Tsurezure Children" in message.body or "Sinopsis tsurezure children" in message.body or "sinopsis tsurezure children" in message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Sinopsis Tsurezure Children : Sebuah seri yang menceritakan tentang kisah percintaan anak muda. Seri ini menyangkut berbagai macam cerita dari seorang anak muda yang tak begitu percaya diri sampai tak bisa percaya kalau gadis yang ia sukai ingin berpacaran dengannya, sampai gadis setengah psikopat yang mencampurkan darahnya sendiri ke dalam cokelat yang ia buat agar laki-laki idamannya bisa suka padanya.",)
#Sinopsis Koi to Uso
    if "Sinopsis Koi to Uso" in message.body or "Sinopsis koi to uso" in message.body or "sinopsis koi to uso" in message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Sinopsis Koi to Uso : Kebohongan dan cinta adalah sesuatu yang terlarang. Di masa depan, saat remaja di Jepang telah berusia 16 tahun, mereka akan mendapatkan pasangan hidup dari pemerintah. Mereka tak perlu susah-susah mencari belahan jiwa dan mereka percaya bahwa pemerintah akan memilihkan pasangan yang terbaik untuk mereka. Yukari Nejima, siswa biasa yang menjadi tokoh utama dalam cerita ini, adalah seseorang yang memiliki perasaan cinta membara yang terpendam. Ini adalah cerita mengenai seorang pemuda yang berjuang untuk mempertahankan cintanya dalam dunia yang melarang cinta.",)
#Sinopsis Keppeki Danshi
    if "Sinopsis Keppeki Danshi" in message.body or "Sinopsis keppeki danshi" in message.body or "sinopsis keppeki danshi" in message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Sinopsis Keppeki Danshi! : Aoyama-kun Pemain sepak bola muda yang jenius bernama Aoyama adalah seorang pemain perwakilan Jepang. Dia menerapkan permainan “serba bersih”, di mana dia tidak pernah melakukan tackle ataupun sundulan. Jika dia mendapat giliran untuk melempar bola, dia selalu memakai sarung tangan. Permainan seperti apa yang akan dia tunjukkan?",)
#Sinopsis Knight's & Magic
    if "Sinopsis Knight's & Magic" in message.body or "Sinopsis knight's & magic" in message.body or "sinopsis knight's & magic" in message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Sinopsis Knight's & Magic : Seorang otaku penggila mecha mengalami siklus reinkarnasi dan berakhir di dunia lain. Dia dikenal sebagai Ernesti Echevarria atau Eru di dalam dunia itu. Di sana terdapat senjata raksasa berbentuk manusia yang dikenal sebagai Silhouette Knight. Eru bersama dengan teman-temannya,  Archid Olter dan Adeltrud Olter, mengejar sebuah mimpi untuk menjadi seorang Knight Runner dan mengendarai robot itu.",)
#Sinopsis Kakegurui
    if "Sinopsis Kakegurui" == message.body or "Sinopsis kakegurui" in message.body or "sinopsis kakegurui" in message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Sinopsis Kakegurui : Akademi Hyakkaou adalah sebuah akademi yang memiliki kurikulum tak biasa. Akademi ini berisi anak-anak dari keluarga yang kaya raya. Di dalam akademi ini, kemampuan siswa dalam bidang akademi dan bidang olah raga tidak menentukan apapun. Yang akan menjadi tolak ukur utama di dalam akademi ini adalah kemampuan untuk membaca pikiran lawan, yaitu seni dalam melakukan sebuah kesepakatan, atau bisa disebut sebagai seni berjudi. Pemenangnya akan menjadi raja dan yang kalah akan menjadi pesuruh. Tapi, sejak Yumeko Jabami datang ke akademi tersebut, esensi dari permainan judi mulai terlihat.",)

                 ##############
                 # PERTANYAAN #
                 ##############
#Observasi
    if "P. Observasi" == message.body or "p. observasi" == message.body or "Pengertian observasi" == message.body or "pengertian observasi" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Observasi adalah kegiatan pengamatan pendahuluan tentang daerah persebaran cebakan suatu jenis barang tambang, sekaligus menyelidiki dan memeriksa kebenarannya secara teoretis yang berkaitan dengan kondisi geologis dilapangan.",)
#Eksplorasi
    if "P. Eksplorasi" == message.body or "p. eksplorasi" == message.body or "Pengertian eksplorasi" == message.body or "pengertian eksplorasi" == message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Eksplorasi adalah kegiatan persiapan dan penyelidikan untuk mengetahui keadaan barang tambang dan kemungkinan pengolahannya secara ekonomis.",)
#Eksploitasi
    if "P. Eksploitasi" == message.body or "p. eksploitasi" == message.body or "Pengertian eksploitasi" == message.body or "pengertian eksploitasi" == message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Eksploitasi adalah usaha penambangan dengan maksud menghasilkan bahan galian dan memanfaatkannya.",)
#Individu
    if "P. Individu" == message.body or "p. individu" == message.body or "Pengertian individu" == message.body or "pengertian individu" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Individu adalah suatu unit makhluk hidup yang umumnya berdiri sendiri dan menemukan makanannya sendiri.",)
#Populasi
    if "P. Polulasi" == message.body or "p. populasi" == message.body or "Pengertian populasi" == message.body or "pengertian populasi" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Populasi adalah kumpulan individu dari spesies yang sama yang hidup dan berkembang biak disatu wilayah tertentu.",)
#Komunitas
    if "P. Komunitas" == message.body or "p. komunitas" == message.body or "Pengertian komunitas" == message.body or "pengertian komunitas" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Komunitas adalah kumpulan populasi yang meliputi bermacam macam spesies dan terdapat ketergantungan antar populasi.",)
#Ekosistem
    if "P. Ekosistem" == message.body or "p. ekosistem" == message.body or "Pengertian ekosistem" == message.body or "pengertian ekosistem" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Ekosistem adalah suatu sistem yang meliputi tumbuh tumbuhan hewan serta lingkungan fisik sebagai tempat hidupnya.",)
  #Ciri-ciri Bioma Tundra
    if "C. Bioma tundra" == message.body or "c. bioma tundra" == message.body or "Ciri-ciri bioma tundra" == message.body or "ciri-ciri bioma tundra" == message.body or "Ciri ciri bioma tundra" == message.body or "ciri ciri bioma tundra" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("1. Semua wilayahnya hampir tertutup salju. 2. Mempunyai musim dingin yang panjang dan gelap. 3. Usia tumbuh vegetasi yang dapat sangat pendek, berkisar 30-120 hari. 4. Jenis vegetasi yang dapat hidup di Bioma Tundra misalnya lumut kerak, rumput teki, tumbuhan terna.",)
  #Ciri-ciri Bioma Taiga
    if "C. Bioma taiga" == message.body or "c. bioma taiga" == message.body or "Ciri-ciri bioma taiga" == message.body or "ciri-ciri bioma taiga" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("1. Mempunyai musim dingin yang cukup panjang,dan mempunyai musim kemarau yang singkat. 2. Selama musim dingin air tanah berubah menjadi es dan mencapai 2 meter dibawah permukaan tanah. 3. Jenis tumbuhan yang hidup sangat sedikit, biasanya terdiri dari 2/3 jenis tumbuhan. 4. Pohon-pohon diBioma Taiga mempunyai daun yang berbentuk seperti jarum dan mempunyai zat lilin dibagian luarnya sehingga tahan terhadap kekeringan.",)
  #Ciri-ciri Bioma Gurun
    if "C. Bioma gurun" == message.body or "c. bioma gurun" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("1. Curah hujan sangat rendah kurang dari 250 mm/tahun. 2. Kecepatan penguapan air lebih cepat dari presipitasi. 3. Kelembapan udara sangat rendah. 4. Perbedaan suhu siang dengan malam hari sangat tinggi. 5. Tanah yang tandus karena tidak mampu menyimpan air.",)
  #Ciri-ciri Bioma Padang Rumput
    if "C. Bioma padang rumput" == message.body or "c. bioma padang rumput" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("1. Curah hujan tidak teratur antara 250-500 mm/tahun. 2. Tanah pada umumnya tidak mampu menyimpan air yang disebabkan oleh rendahnya tingkat porositas tanah. 3. Beberapa jenis rumput mempunyai ketinggian hingga 3,5 meter. 4. Memiliki pohon yang khas yaitu Akasia. 5. Wilayah persebaran Bioma Padang Rumput meliputi Afrika, Amerika Selatan, Amerika Serikat bagian Barat, Argentina, dan Australia.",)
  #Ciri-ciri Bioma Sabana
    if "C. Bioma sabana" == message.body or "c. bioma sabana" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("1. Suhu panas sepanjang tahun. 2. Hujan terjadi secara musiman.",)
  #Ciri-ciri Bioma Hujan Tropis
    if "C. Bioma hutan hujan tropis" == message.body or "c. bioma hutan hujan tropis" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("1. Curah hujan tinggi, merata sepanjang tahun. 2. Matahari bersinar sepanjang tahun. 3. Dari bulan kesatu kebulan lainnya perubahan suhu relatif kecil/rendah. 4. Dibawah kanopi atau tudung pohon, gelap sepanjang hari sehingga tidak ada perubahan suhu antara siang hari dan malam hari.",)
  #Ciri-ciri Bioma Hutan Gugur
    if "C. Bioma hutan gugur" == message.body or "c. bioma hutan gugur" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("1. Curah hujan merata antara 750-1000 mm/tahun. 2. Mempunyai 4 musim yaitu musim panas, gugur, dingin, dan semi. 3. Mempunyai musim panas yg hangat dan musim dingin yg tidak terlalu dingin. 4. Pohon-pohon memiliki ciri berdaun lebar, hijau pada musim dingin, rontok pada musim panas, dan memiliki tajuk yg rapat. 5. Jarak antara pohon satu dan pohon lainnya tidak terlalu rapat. 6. Jumlah atau jenis tumbuhan yang ada relatif sedikit.",)
#Fauna Asiatis
    if "P. Fauna asiatis" == message.body or "p. fauna asiatis" == message.body or "Pengertian fauna asiatis" == message.body or "pengertian fauna asiatis" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Fauna Asiatis meliputi daerah belahan barat Indonesia yaitu Sumatra, Jawa, Kalimantan, dan Bali. Terdapat banyak hewan mamalia yang besar seperti gajah, harimau, banteng, badak. Fauna kawasan Indonesia barat sering disebut Fauna Dangkalan Sunda",)
#Fauna Australis
    if "P. Fauna australis" == message.body or "p. fauna australis" == message.body or "Pengertian fauna australis" == message.body or "pengertian fauna australis" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Fauna australis adalah wilayah fauna dangkalan sahul yang meliputi bagian timur kepulauan indonesia yaitu papua dan kepulauan aru. jenis hewannya seperti jenis hewan berkantong kangguru dan aneka burung seperti cendrawasih, kakak tua",)
#Fauna Peralihan
    if "P. Fauna peralihan" == message.body or "p. fauna peralihan" == message.body or "Pengertian fauna peralihan" == message.body or "pengertian fauna peralihan" == message.body:
     if self.getAccess(user) >= 1 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Fauna peralihan meliputi sulawesi, maluku, dan Nusa tenggara. Jenis faunanya mirip fauna asiatis dan australis yaitu anoa, babi rusa di sulawesi, dan komodo di pulau komodo.",)
#Minyak Bumi
    if "P. Minyak bumi" == message.body or "p. minyak bumi" == message.body or "Pengertian minyak bumi" == message.body or "pengertian minyak bumi" == message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Minyak bumi adalah cairan kental, berwarna cokelat gelap, atau kehijauan yang mudah terbakar, yang berada di lapisan atas dari beberapa area di kerak bumi.",)
  #Proses Pembentukan Minyak Bumi
    if "Prs. Minyak bumi" == message.body or "prs. minyak bumi" == message.body or "Proses pembentukan minyak bumi" == message.body or "proses pembentukan minyak bumi" == message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("1. Proses pengendapan batuan induk pembentuk minyak (Source Rock). 2. Proses pemantangan batuan induk (Maturity). 3. Proses perpindahan minyak dari batuan induk ke batuan sarang (Reservoir). 4. Proses pemerangkapan (Trapping).",)
  #Keunggulan Minyak Bumi
    if "Kng. Minyak bumi" == message.body or "kng. minyak bumi" == message.body or "Keunggulan minyak bumi" == message.body or "keunggulan minyak bumi" == message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("1. Minyak bumi mempunyai nilai kalor yang tinggi. 2. Minyak bumi menghasilkan berbagai macam bahan bakar. 3. Minyak bumi dapat menghasilkan berbagai minyak pelumas. 4. Minyak bumi dapat bersifat sebagai bahan baku yaitu bahan petrokimia, misalnya bahan tekstil dan bahan plastik. 5. Sifat cair minyak bumi lebih praktis mudah dibawa, mudah dialirkan, dan mudah disimpan dalam berbagai bentuk.",)
#Batu Bara
    if "P. Batu bara" == message.body or "p. batu bara" == message.body or "Pengertian batu bara" == message.body or "pengertian batu bara" == message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Batu bara adalah batuan yang berasal dari tumbuhan yang mati dan tertimbun endapan lumpur, pasir, dan lempung selama berjuta-juta tahun lamanya.",)
  #Proses Pembentukan Batu Bara
    if "Prs. Batu bara" == message.body or "prs. batu bara" == message.body or "Proses pembentukan batu bara" == message.body or "proses pembentukan batu bara" == message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("1. Batu bara berbentuk pada zaman karbon berasal dari sisa tumbuhan paku-pakuan raksasa dan tumbuhan lain yang terkumpul dirawa ataupun sepanjang sungai yang kemudian tertimbun sendimen. 2. Oleh karena sisa tumbuhan yang tertimbun tsb tidak mendapatkan udara, sisa tumbuhan melapuk sehingga menjadi bahan lunak gembur yang disebut gambut. 3. Sewaktu gambut mengendap lebih dalam ke tanah, suhu dan tekanan yang semakin tinggi mulai mendorong keluar molekul nitrogen, oksigen, dan hidrogen hingga akhirnya tertinggal masa yang keras (batu bara).",)
  #Teknik Penambangan Batu Bara
    if "Tp. Batu bara" == message.body or "tp. batu bara" == message.body or "Teknik penambangan batu bara" == message.body or "teknik penambangan batu bara" == message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("1. Penambangan terbuka. 2. Penambangan dalam. 3. Penambangan jauh. 4. Penambangan diatas permukaan",)
  #Teknik Penambangan Terbuka
    if "Tp. Penambangan terbuka" == message.body or "p. penambangan terbuka" == message.body or "Pengertian penambangan terbuka" == message.body or "pengertian penambangan terbuka" == message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Penambangan terbuka merupakan kegiatan menambang batu bara tanpa melakukan penggalian berat karena letak batu bara dekat dengan permukaan bumi.",)
  #Teknik Penambangan Dalam
    if "Tp. Penambangan Dalam" == message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("Penambangan dalam merupakan kegiatan menambang batu bara")
  #Teknik Penambangan Jauh
    if "Tp. Penambangan Jauh" == message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("")
  #Teknik Penambangan Diatas Permukaan
    if "Tp. Penambangan Diatas Permukaan" == message.body:
     if self.getAccess(user) >= 0 or room.getLevel(user) > 0 and not user.name in blacklist: 
      room.message ("")

#########################
######## Chat di ########
### Smatag, SL-Nime   ###
###   Dan Rikoaizi    ###
#########################
    elif "ramalan" == message.body:
      if room.name == "sl-nime" or room.name == "rikoaizi" or room.name == "smatag":
        jawab = ["hari ini anda beruntung","hari ini anda sial","hari ini anda akan bertemu jodoh anda :D","hari ini anda akan ketemu mantan anda","jones ya? minta kok di ramal"]
        room.message(random.choice(jawab)+" @"+user.name,True)
    elif "fight" == message.body:
      if room.name == "sl-nime" or room.name == "rikoaizi" or room.name == "smatag":
        jawab = ["http://data2.whicdn.com/images/156069110/large.gif"]
        room.message(random.choice(jawab)+" @"+user.name,True)
    elif "sepi" == message.body:
        time.sleep(2)
        time.sleep(1)
        jawab = ["mungkin lagi pada afk", "iya, kayak kuburan aja nih room"]
        room.message(random.choice(jawab)+" @"+user.name)
    elif "anjing" == message.body:
        time.sleep(2)
        time.sleep(1)
        jawab = ["Wahh Parah Ngajak Ribut Ni Anak !","..?"]
        room.message(random.choice(jawab))

    elif "rekomendasi anime romance" in message.body:
        time.sleep(2)
        time.sleep(1)
        jawab = ["Kaichou wa Maid sama","Koi to Uso","Tsurezure Children","Ookami Shoujo to Kuro Ouji","Plastic Memories"]
        room.message(random.choice(jawab)+" @"+user.name,True)
    elif "rekomendasi anime adventure" in message.body:
        time.sleep(2)
        time.sleep(1)
        jawab = ["Battle Through the Heavens","Spice and Wolf","Zero Kara Hajimeru no Sho","Hai to Gensou no Grimgar","Tales series ''Tales of Zestiria the X, Tales of Vesperia The First Strike, Tales of the Abyss, Tales of Symphonia Tethealla hen, Tales of Symphonia Sylvarant hen, Tales of Phantasia the Animation"]
        room.message(random.choice(jawab)+" @"+user.name,True)
    elif "rekomendasi anime Action" in message.body:
        time.sleep(2)
        time.sleep(1)
        jawab = ["Taboo Tatto","Guilty Crown","Jormungand"]
        room.message(random.choice(jawab)+" @"+user.name,True)
    elif "rekomendasi anime comedy" in message.body:
        time.sleep(2)
        time.sleep(1)
        jawab = ["Gekkan Shoujo Nozaki-kun","Inu to Hasami wa Tsukaiyou","Aho Girl","D-Frag","Gamers"]
        room.message(random.choice(jawab)+" @"+user.name,True)
      
    elif "azu lagi ngapain" in message.body or "azu lagi ngapain ?" in message.body or "kamu lagi apa ?" in message.body or "kamu lagi apa ?" in message.body or "azu lagi apa" in message.body:
        time.sleep(2)
        time.sleep(1)
        jawab = ["lagi mikirin kamu","lagi tidur-tiduran nih","lagi nonton dorama nih","ngapain sih tanya-tanya","lagi ngawasin multiroom nih"]
        room.message(random.choice(jawab)+" @"+user.name,True)
    elif "azu ngewe yuk :v" in message.body:
        time.sleep(2)
        time.sleep(1)
        jawab = ["Ayo lah. memek ku dh basah nih.","hmm gimanya. takut aku.","Hanyunk. gk sbr aku mau di masukin","sini chinchin mu. ku jilat"]
        room.message(random.choice(jawab)+" @"+user.name,True)
    elif "azu umurnya berapa?" in message.body or "umur azu berapa?" in message.body or "azu umurnya berapa" in message.body:
        time.sleep(2)
        time.sleep(1)
        jawab = ["Umur azu, baru 13 tahun :)"]
        room.message(random.choice(jawab)+" @"+user.name,True)
    elif "azu udah punya anak?" in message.body or "azu ada anak" in message.body or "anak azu berapa" in message.body:
        time.sleep(2)
        time.sleep(1)
        jawab = ["Azu belum bisa punya anak >_<"]
        room.message(random.choice(jawab)+" @"+user.name,True)
    elif "azu keluar yuk" in message.body or "azu keluar yok" in message.body or "azu jalan yuk" in message.body or "azu jalan yok" in message.body:
        time.sleep(2)
        time.sleep(1)
        jawab = ["maaf azu lagi sibuk njaga website, lain kali aja ya... (^_^'')","mau ngajakin azu kemana emangnya?","hmm... bentar aku pikir-pikir dulu","ayok... tapi bantuin ngepost dulu ya, soalnya lagi banyak yang mau dipost nih.","maaf, azu udah ada janji sama orang lain"]
        room.message(random.choice(jawab)+" @"+user.name,True)

###################################################################
#                ### STREAMING LAGI-NIME ###                    ###
###################################################################
    if "script website sl-nime" == message.body:                ###
     if self.getAccess(user) >= 2:                              ### 
      room.message(".sl (Update), .slnew (List Post SL)",True)  ###
###################################################################
#                ### Script Partner ###                         ###
#############################################################################################
    if "script website kurogaze" == message.body or ".script kurogaze" == message.body:   ###                    ###
     if self.getAccess(user) >= 2:                                              #############
      room.message(".kurogaze (Update), .kurogazenew (List Post Kurogaze)",True)###
#################################################################################################
    if "script website animestyle" == message.body or ".script animestyle" == message.body:   ###                    ###
     if self.getAccess(user) >= 2:                                              #################
      room.message(".asnt (Update), .asntnew (List Post AnimeStyle)",True)      ###
###################################################################################
##########
# Prefix #
##########
    if message.body == "": return  
    if message.body[0] in ["."]:   
      data = message.body[1:].split(" ", 1)
      if len(data) > 1:
        cmd, args = data[0], data[1]
      else:
        cmd, args = data[0], ""

  ## Server uptime (uptime)
      if cmd == "uptime":
          room.message("sys uptime: %s" % uptime())
  ## Server uptime (uptime)
      if cmd == "sut":
          minute = 60
          hour = minute * 60
          day = hour * 24
          days =  int(getUptime() / day)
          hours = int((getUptime() % day) / hour)
          minutes = int((getUptime() % hour) / minute)
          seconds = int(getUptime() % minute)
          string = ""

          if days > 0:

            string += str(days) + " " + (days == 1 and "day" or "days" ) + ", "

          if len(string) > 0 or hours > 0:

            string += str(hours) + " " + (hours == 1 and "hour" or "hours" ) + ", "

          if len(string) > 0 or minutes > 0:

            string += str(minutes) + " " + (minutes == 1 and "minute" or "minutes" ) + ", "

          string += str(seconds) + " " + (seconds == 1 and "second" or "seconds" )
          room.message("Bot Program session has been running for: %s" % string, True)
 
                                             ###########################    
                                             ##check access and ignore##
                                             ###########################

      if self.getAccess(user) == 0: return 
      def pars(args):
        args=args.lower()
        for name in room.usernames:
          if args in name:return name    
      def roompars(args):
        args = args.lower()
        for name in self.roomnames:
          if args in name:return name
      def roomUsers():
          usrs = []
          gay = []
          prop = 0
          prop = prop + len(room._userlist) - 1
          for i in room._userlist:
            i = str(i)
            usrs.append(i)
          while prop >= 0:
            j = usrs[prop].replace("<User: ", "")
            i = j.replace(">", "")
            gay.append(i)
            prop = prop - 1
          return gay
      
      def getParticipant(arg):
          rname = self.getRoom(arg)
          usrs = []
          gay = []
          finale = []
          prop = 0
          prop = prop + len(rname._userlist) - 1
          for i in rname._userlist:
            i = str(i)
            usrs.append(i)
          while prop >= 0:
            j = usrs[prop].replace("<User: ", "")
            i = j.replace(">", "")
            gay.append(i)
            prop = prop - 1
          for j in gay:
            if j not in finale:
              finale.append(j)
          return finale

      def saveAll():
       f = open('note.txt','w')
       f.write(str(sn))
       f.close()
       f = open('moderator.txt','w')
       f.write(str(moderator))
       f.close()
       f = open("notif.txt", "w")
       f.write("\n".join(notif))
       f.close()
       f = open("definitions.txt", "w")
       for word in dictionary:
         definition, name = json.loads(dictionary[word])
         f.write(json.dumps([word, definition, name])+"\n")
       f.close()
       f = open("locks.txt", "w")
       f.write("\n".join(locks))
       f.close()
       f = open("owners.txt", "w")
       f.write("\n".join(owners))
       f.close()
       f = open("rooms.txt", "w")
       f.write("\n".join(self.roomnames))
       f.close()

     #########################
     ### Reboot for Rank 5 ###
     #########################
      if cmd == "Reboot" or cmd == "reboot" and self.getAccess(user) == 5:    ##############
            if user.name in owners:                                           # For Owners #
             room.message("Saving databases, "+sntonick(user.name),True)      ############## 
             time.sleep(1)
             print("[SAVE] Saving PMLOG..")
            f = open("owners.txt", "w")
            f.write("\n".join(owners))
            f = close()
            f = open("admin.txt", "w")
            f.write("\n".join(admin))
            f = close()
            f = open("coadmin.txt", "w")
            f.write("\n".join(coadmin))
            f = close()
            f = open("moderator.txt", "w")
            f.write("\n".join(moderator))
            f = close()
            f = open("whitelist.txt", "w")
            f.write("\n".join(whitelist))
            f = close()
            f = open("hiddenlist.txt", "w")
            f.write("\n".join(hiddenlist))
            f = close()
            f = open("netizen.txt", "w")
            f.write("\n".join(netizen))
            f = close()
            f = open('note.txt','w')
            f.write(str(sn))        
            f = close()
            f = open("rooms.txt", "w")
            f.write("\n".join(self.roomnames))
            f = close()
            time.sleep(1)
            f = open("definitions.txt", "w")
            for word in dictionary:
              definition, name = json.loads(dictionary[word])
              f.write(json.dumps([word, definition, name])+"\n")
            try:
              print("[CLEAR]...[Saving] Daftar Catatan...")
            except:print("|ERROR|...[Saving] Daftar Catatan..!")
            f = close()
            time.sleep(1)
            f = open("nicks.txt", "w")
            for user in nicks:
              nick = json.loads(nicks[user])
              f.write(json.dumps([user,nick])+"\n")
            try:
              print("[CLEAR]...[Saving] Daftar Panggilan...")
              time.sleep(1)
              print("[INFO]...|System| Starting in 5 second")
            except:print("|ERROR|...[Saving] Daftar Panggilan..!")
            f = close()
            time.sleep(3)
            time.sleep(2)
            time.sleep(1)
            for room in self.rooms:
                room.reconnect()

     #############################
     ### Reboot for Rank 1 - 4 ###
     #############################
      elif cmd == "Reboot" or cmd == "reboot":                              ##################
         if self.getAccess(user) >=1 and not user.name in owners:           # Not for Owners #
           room.message("Reboot All Room",True)                             ##################
           time.sleep(1)
         for room in self.rooms:
           room.reconnect()

     #################
     ### Reconnect ###
     #################
      elif cmd == "Reconnect" or cmd == "reconnect" and self.getAccess(user) >=1:
         if user.name.lower() in owners:
           room.reconnect()
         else:
           room.message("reconnect (nama room) .Example: reconnect jamunimee")

     ############
     ### Wake ###
     ############
      if cmd == "wake" or cmd == "Wake":
        if user.name in owners: return
        room.message("Bot in Wake mode")
        lockdown = False

     #############
     ### Sleep ###
     #############
      if cmd == "sleep" or cmd == "Sleep":
        if user.name in owners: return
        room.message("Bot in Sleep mode")
        lockdown = True

     ################
     ### Shutdown ###
     ################
      if cmd == "shutdown":
        if user.name in owners:
          print("System bot dimatikan dalam 3 detik")
          time.sleep(2)
          time.sleep(1)
          room.message("Terima Kasih udah nemenin Freya ya teman-teman")
          print("System bot telah dimatikan")
          self.setTimeout(3, self.stop, )

     ###################
     ### Version Bot ###
     ###################
      if cmd == "version" and self.getAccess(user) >=1:
        room.message("Script versi sudah diubah ke manual tanpa [.], atau copy: V.Freya , V.Mezishi , V.Couple",True)
                                             ###########        
                                             ## Clear ##
                                             ###########

      if cmd == "clear":
          if room.getLevel(self.user) > 0:
            if self.getAccess(user) >= 2 or room.getLevel(user) == 2:
              room.clearall(),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
              room.clearUser(ch.User(random.choice(room.usernames))),
            else: room.message("Hanya rank 2+ atau pemilik room yang dapat melakukannya.")
          else:
            room.message("Maaf Freya bukan mods disini :|")

                                             #################
                                             ## Delete Chat ##
                                             #################

      elif (cmd == "delete" or cmd == "del"):
          if room.getLevel(self.user) > 0:
            if self.getAccess(user) >= 1 or room.getLevel(user) > 0:
              name = args.split()[0].lower()
              room.clearUser(ch.User(name))
            else:room.message("kamu tidak bisa melakukannya!!")
          else:
            room.message("Maaf Freya bukan mods disini :|")

                                             #########
                                             ## CMD ##
                                             #########

      elif cmd == "cmd" or cmd == "cmds":
       if room.name == "smatag":
        if user.name in owners :
          room.message("<br/>"'<b>'+user.name+'</b> Rank 5 <f x12FF0000="arial">[<f x12FF4500="arial">O<f x12FF8A00="arial">w<f x12FFCF00="arial">n<f x12BAFF00="arial">e<f x1200FF6D="arial">r<f x1230FF00="arial">s<f x1200AAFF="arial">]"'+"<br/>"+" Perintah[ . ] :<br/> gs(Pencarian Google), yt(Pencarian Youtube). nick(Membuat Panggilan), mynick(Panggilan-Ku), seenick(Lihat Panggilan). df(Membuat Catatan), udf(Menghapus Catatan), sd(Lihat Catatan), md(Catatan-Ku). inbox(Pesan), pm(Mengirim Pesan), rn(Membaca Pesan). profile, myip(My IP Address), sip(See IP Address), bgtime(Mengecheck Waktu Background), bgimg(Gambar Background). del(Menghapus Chat), clear(Menghapus Semua Chat). cso(Check Status Online), find(Cari). join, leave, rejoin, mc(MultiChat), mr(MultiRoom). mods(Daftar Staff Room), ismod, addmod(Add Moderator Room). ul(Daftar Users), ping(Tag/Menandai Users), ru(Mengacak User). wake, sleep, reconnect, restart, reboot, shutdown. rb(Pelangi), rb2(Kode Pelangi), say(Bilang), b(Bilang Kesemua). bc(Broadcast), il(Info Lewat), nu(New Update), fax(Pesan keRoom X). rank(Mengecheck Rank Seseorang), myrank(Rank-Ku), ranker(Seluruh Rank), staff. bl(Blacklist), ubl(Un-Blacklist), dl(HiddenList), udl(Un-HiddenList), wl(Whitelist), uwl(Un-Whitelist), setmo(Set-Moderator). umo(Un-Moderator), setcad(Set-Co-Admin), ucad(Un-Co-Admin), setad(Set-Admin), uad(Un-Admin), setow(Set-Owner), uow (Un-Owner). uptime(Server Up Time), sut(Server Up Time), sbg(Set Background Bot), change(Change akun a,m,r). mega list, myweb, mypartner.",True)
        if user.name in admin and not user.name in owners and not user.name in coadmin and not user.name in moderator and not user.name in whitelist and not user.name in hiddenlist:
          room.message("<br/>"'<b>'+user.name+'</b> Rank 4 <f x12FF0000="arial">[<f x12FF4500="arial">A<f x12FF8A00="arial">d<f x12FFCF00="arial">m<f x12BAFF00="arial">i<f x1200FF6D="arial">n<f x1230FF00="arial">]"'+"<br/>"+" Perintah[ . ] :<br/> gs(Pencarian Google), yt(Pencarian Youtube). nick(Membuat Panggilan), mynick(Panggilan-Ku), seenick(Lihat Panggilan). df(Membuat Catatan), udf(Menghapus Catatan), sd(Lihat Catatan), md(Catatan-Ku). inbox(Pesan), pm(Mengirim Pesan), rn(Membaca Pesan). profile, myip(My IP Address), sip(See IP Address), bgtime(Mengecheck Waktu Background), bgimg(Gambar Background). del(Menghapus Chat), clear(Menghapus Semua Chat). cso(Check Status Online), find(Cari). join, leave, rejoin, mc(MultiChat), mr(MultiRoom). mods(Daftar Staff Room), ismod, addmod(Add Moderator Room). ul(Daftar Users), ping(Tag/Menandai Users), ru(Mengacak User). wake, sleep, reconnect, restart, reboot, shutdown. rb(Pelangi), rb2(Kode Pelangi), say(Bilang), b(Bilang Kesemua). bc(Broadcast), il(Info Lewat), nu(New Update), fax(Pesan keRoom X). rank(Mengecheck Rank Seseorang), myrank(Rank-Ku), ranker(Seluruh Rank), staff. bl(Blacklist), ubl(Un-Blacklist), dl(HiddenList), udl(Un-HiddenList), wl(Whitelist), uwl(Un-Whitelist), setmo(Set-Moderator). umo(Un-Moderator), setcad(Set-Co-Admin), ucad(Un-Co-Admin). sbg(Set Background Bot), change(Change akun a,m,r). mega list, myweb, mypartner.",True) 
        if user.name in coadmin and not user.name in owners and not user.name in admin and not user.name in moderator and not user.name in whitelist and not user.name in hiddenlist:
          room.message("<br/>"'<b>'+user.name+'</b> Rank 3 <f x12FF0000="arial">[<f x1255FF00="arial">C<f x1200FF55="arial">o<f x12FF4500="arial">-<f x12FF5500="arial">A<f x12FF8A00="arial">d<f x12FFCF00="arial">m<f x12BAFF00="arial">i<f x1200FF6D="arial">n<f x1230FF00="arial">]"'+"<br/>"+" Perintah[ . ] :<br/> gs(Pencarian Google), yt(Pencarian Youtube). nick(Membuat Panggilan), mynick(Panggilan-Ku), seenick(Lihat Panggilan). df(Membuat Catatan), udf(Menghapus Catatan), sd(Lihat Catatan), md(Catatan-Ku). inbox(Pesan), pm(Mengirim Pesan), rn(Membaca Pesan). profile, myip(My IP Address), sip(See IP Address), bgtime(Mengecheck Waktu Background), bgimg(Gambar Background). del(Menghapus Chat), clear(Menghapus Semua Chat). cso(Check Status Online), find(Cari). join, leave, rejoin, mc(MultiChat), mr(MultiRoom). mods(Daftar Staff Room), ismod, addmod(Add Moderator Room). ul(Daftar Users), ping(Tag/Menandai Users), ru(Mengacak User). wake, sleep, reconnect, restart, reboot, shutdown. rb(Pelangi), rb2(Kode Pelangi), say(Bilang), b(Bilang Kesemua). bc(Broadcast), il(Info Lewat), nu(New Update), fax(Pesan keRoom X). rank(Mengecheck Rank Seseorang), myrank(Rank-Ku), ranker(Seluruh Rank), staff. bl(Blacklist), ubl(Un-Blacklist), dl(HiddenList), udl(Un-HiddenList), wl(Whitelist), uwl(Un-Whitelist), setmo(Set-Moderator). umo(Un-Moderator). sbg(Set Background Bot), change(Change akun a,m,r). mega list, myweb, mypartner.",True) 
        if user.name in moderator and not user.name in owners and not user.name in admin and not user.name in coadmin and not user.name in whitelist and not user.name in hiddenlist:
          room.message("<br/>"'<b>'+user.name+'</b> Rank 2 <f x12FF0000="arial">[<f x12FF4500="arial">M<f x12FF8A00="arial">o<f x12FFCF00="arial">d<f x12BAFF00="arial">e<f x1275FF00="arial">r<f x1230FF00="arial">a<f x1200FF45="arial">t<f x1200FF8A="arial">o<f x1200FFCF="arial">r<f x1200BAFF="arial">] "'+"<br/>"+" Perintah[ . ] :<br/> gs(Pencarian Google), yt(Pencarian Youtube). nick(Membuat Panggilan), mynick(Panggilan-Ku), seenick(Lihat Panggilan). df(Membuat Catatan), udf(Menghapus Catatan), sd(Lihat Catatan), md(Catatan-Ku). inbox(Pesan), pm(Mengirim Pesan), rn(Membaca Pesan). profile, myip(My IP Address), sip(See IP Address), bgtime(Mengecheck Waktu Background), bgimg(Gambar Background). del(Menghapus Chat), clear(Menghapus Semua Chat). cso(Check Status Online), find(Cari). join, leave, rejoin, mc(MultiChat), mr(MultiRoom). mods(Daftar Staff Room), ismod, addmod(Add Moderator Room). ul(Daftar Users), ping(Tag/Menandai Users), ru(Mengacak User). wake, sleep, reconnect, restart, reboot, shutdown. rb(Pelangi), rb2(Kode Pelangi), say(Bilang), b(Bilang Kesemua). bc(Broadcast), il(Info Lewat), nu(New Update), fax(Pesan keRoom X). rank(Mengecheck Rank Seseorang), myrank(Rank-Ku), ranker(Seluruh Rank), staff. bl(Blacklist), ubl(Un-Blacklist), dl(HiddenList), udl(Un-HiddenList), wl(Whitelist), uwl(Un-Whitelist). sbg(Set Background Bot), change(Change akun a,m,r). mega list, myweb, mypartner.",True)
        if user.name in whitelist and not user.name in owners and not user.name in admin and not user.name in coadmin and not user.name in moderator and not user.name in hiddenlist:
          room.message("<br/>"'<b>'+user.name+'</b> Rank 1 <f x12FF0000="arial">[<f x12FF5500="arial">W<f x12FFAA00="arial">h<f x12AAFF00="arial">i<f x1255FF00="arial">t<f x1200FF55="arial">e<f x1200FFAA="arial">L<f x1200AAFF="arial">i<f x120055FF="arial">s<f x1200FFCF="arial">t<f x1200BAFF="arial">]"'+"<br/>"+" Perintah[ . ] :<br/> gs(Pencarian Google), yt(Pencarian Youtube). nick(Membuat Panggilan), mynick(Panggilan-Ku), seenick(Lihat Panggilan). df(Membuat Catatan), udf(Menghapus Catatan), sn(Kirim Pesan lewat bot), sd(Lihat Catatan), md(Catatan-Ku). inbox(Pesan), pm(Mengirim Pesan), rn(Membaca Pesan). profile, myip(My IP Address), sip(See IP Address), bgtime(Mengecheck Waktu Background), bgimg(Gambar Background). del(Menghapus Chat), clear(Menghapus Semua Chat). cso(Check Status Online), find(Cari). join, leave, rejoin, mc(MultiChat), mr(MultiRoom). mods(Daftar Staff Room), ismod, addmod(Add Moderator Room). ul(Daftar Users), ping(Tag/Menandai Users), ru(Mengacak User). wake, sleep, reconnect, restart, reboot, shutdown. rb(Pelangi), rb2(Kode Pelangi), say(Bilang), b(Bilang Kesemua). bc(Broadcast), il(Info Lewat), nu(New Update), fax(Pesan keRoom X). rank(Mengecheck Rank Seseorang), myrank(Rank-Ku), ranker(Seluruh Rank), staff. bl(Blacklist), ubl(Un-Blacklist), dl(HiddenList), udl(Un-HiddenList). sbg(Set Background Bot), change(Change akun a,m,r). mega list, myweb, mypartner.",True)
        if user.name in hiddenlist and not user.name in owners and not user.name in admin and not user.name in coadmin and not user.name in moderator and not user.name in whitelist:
          room.message("<br/>"'<b>'+user.name+'</b> Rank 1 <f x12FF0000="arial">[<f x12FF5500="arial">D<f x12FFAA00="arial">-<f x12AAFF00="arial">L<f x1255FF00="arial">i<f x1200FF55="arial">s<f x1200FFAA="arial">t<f x1200AAFF="arial">]"'+"<br/>"+" Perintah[ . ] :<br/> gs(Pencarian Google), yt(Pencarian Youtube). nick(Membuat Panggilan), mynick(Panggilan-Ku), seenick(Lihat Panggilan). df(Membuat Catatan), udf(Menghapus Catatan), sd(Lihat Catatan), md(Catatan-Ku). inbox(Pesan), pm(Mengirim Pesan), rn(Membaca Pesan). profile, myip(My IP Address), sip(See IP Address), bgtime(Mengecheck Waktu Background), bgimg(Gambar Background). del(Menghapus Chat), clear(Menghapus Semua Chat). cso(Check Status Online), find(Cari). join, leave, rejoin, mc(MultiChat), mr(MultiRoom). mods(Daftar Staff Room), ismod, addmod(Add Moderator Room). ul(Daftar Users), ping(Tag/Menandai Users), ru(Mengacak User). wake, sleep, reconnect, restart, reboot, shutdown. rb(Pelangi), rb2(Kode Pelangi), say(Bilang), b(Bilang Kesemua). bc(Broadcast), il(Info Lewat), nu(New Update), fax(Pesan keRoom X). rank(Mengecheck Rank Seseorang), myrank(Rank-Ku), ranker(Seluruh Rank), staff. bl(Blacklist), ubl(Un-Blacklist), dl(HiddenList), udl(Un-HiddenList), wl(Whitelist), uwl(Un-Whitelist), setmo(Set-Moderator). umo(Un-Moderator), setcad(Set-Co-Admin), ucad(Un-Co-Admin), setad(Set-Admin), uad(Un-Admin), setow(Set-Owner), uow (Un-Owner). uptime(Server Up Time), sut(Server Up Time), sbg(Set Background Bot), change(Change akun a,m,r). mega list, myweb, mypartner.",True)
        if user.name in netizen and not user.name in owners and not user.name in admin and not user.name in coadmin and not user.name in moderator and not user.name in whitelist and not user.name in hiddenlist:
          room.message("<br/>"'<b>'+user.name+'</b> Rank 0 <f x12FF0000="arial">[<f x12FF5500="arial">N<f x12FFAA00="arial">e<f x12AAFF00="arial">t<f x1255FF00="arial">i<f x1200FF55="arial">z<f x1200FFAA="arial">e<f x1200AAFF="arial">n<f x120055FF="arial">]"'+"<br/>"+" Perintah[ . ] :<br/> gs(Pencarian Google), yt(Pencarian Youtube). nick(Membuat Panggilan), mynick(Panggilan-Ku), seenick(Lihat Panggilan). df(Membuat Catatan), udf(Menghapus Catatan), sd(Lihat Catatan), md(Catatan-Ku). inbox(Pesan), pm(Mengirim Pesan), rn(Membaca Pesan). profile, myip(My IP Address), sip(See IP Address), bgtime(Mengecheck Waktu Background), bgimg(Gambar Background). del(Menghapus Chat), clear(Menghapus Semua Chat). cso(Check Status Online), find(Cari). join, leave, rejoin, mc(MultiChat), mr(MultiRoom). mods(Daftar Staff Room), ismod, addmod(Add Moderator Room). ul(Daftar Users), ping(Tag/Menandai Users), ru(Mengacak User). wake, sleep, reconnect, restart. rb(Pelangi), rb2(Kode Pelangi), say(Bilang), b(Bilang Kesemua). bc(Broadcast), il(Info Lewat), nu(New Update), fax(Pesan keRoom X). rank(Mengecheck Rank Seseorang), myrank(Rank-Ku), ranker(Seluruh Rank), staff. bl(Blacklist), ubl(Un-Blacklist), dl(HiddenList), udl(Un-HiddenList). mega list, myweb, mypartner.",True)
       else: room.message("Commando hanya bisa dibuka di http://smatag.chatango.com/")

                                             ############
                                             ## MyRank ##
                                             ############

      if cmd == "myrank":
        if user.name in owners:room.message                             ("<br/>"'<b>'+user.name+'</b> Rank 5 <f x12FF0000="arial">[<f x12FF4500="arial">O<f x12FF8A00="arial">w<f x12FFCF00="arial">n<f x12BAFF00="arial">e<f x1200FF6D="arial">r<f x1230FF00="arial">s<f x1200AAFF="arial">]"'+"<br/>"+" Perintah[ . ] : cmd (commando).",True)
        if user.name in admin: room.message                             ("<br/>"'<b>'+user.name+'</b> Rank 4 <f x12FF0000="arial">[<f x12FF4500="arial">A<f x12FF8A00="arial">d<f x12FFCF00="arial">m<f x12BAFF00="arial">i<f x1200FF6D="arial">n<f x1230FF00="arial">]"'+"<br/>"+" Perintah[ . ] : cmd (commando).",True)
        if user.name in coadmin: room.message                           ("<br/>"'<b>'+user.name+'</b> Rank 3 <f x12FF0000="arial">[<f x1255FF00="arial">C<f x1200FF55="arial">o<f x12FF4500="arial">-<f x12FF5500="arial">A<f x12FF8A00="arial">d<f x12FFCF00="arial">m<f x12BAFF00="arial">i<f x1200FF6D="arial">n<f x1230FF00="arial">]"'+"<br/>"+" Perintah[ . ] : cmd (commando).",True)
        if user.name in moderator: room.message                         ("<br/>"'<b>'+user.name+'</b> Rank 2 <f x12FF0000="arial">[<f x12FF4500="arial">M<f x12FF8A00="arial">o<f x12FFCF00="arial">d<f x12BAFF00="arial">e<f x1275FF00="arial">r<f x1230FF00="arial">a<f x1200FF45="arial">t<f x1200FF8A="arial">o<f x1200FFCF="arial">r<f x1200BAFF="arial">] "'+"<br/>"+" Perintah[ . ] : cmd (commando).",True)
        if user.name in whitelist: room.message                         ("<br/>"'<b>'+user.name+'</b> Rank 1 <f x12FF0000="arial">[<f x12FF5500="arial">W<f x12FFAA00="arial">h<f x12AAFF00="arial">i<f x1255FF00="arial">t<f x1200FF55="arial">e<f x1200FFAA="arial">L<f x1200AAFF="arial">i<f x120055FF="arial">s<f x1200FFCF="arial">t<f x1200BAFF="arial">]"'+"<br/>"+" Perintah[ . ] : cmd (commando).",True)
        if user.name in hiddenlist: room.message                             ("<br/>"'<b>'+user.name+'</b> Rank 1 <f x12FF0000="arial">[<f x12FF5500="arial">D<f x12FFAA00="arial">-<f x12AAFF00="arial">L<f x1255FF00="arial">i<f x1200FF55="arial">s<f x1200FFAA="arial">t<f x1200AAFF="arial">]"'+"<br/>"+" Perintah[ . ] : cmd (commando).",True)
        if user.name in netizen and not user.name in hiddenlist and not user.name in whitelist and not user.name in moderator and not user.name in coadmin and not user.name in admin and not user.name in owners: room.message("<br/>"'<b>'+user.name+'</b> Rank 0 <f x12FF0000="arial">[<f x12FF5500="arial">C<f x12FFAA00="arial">i<f x12AAFF00="arial">t<f x1255FF00="arial">i<f x1200FF55="arial">Z<f x1200FFAA="arial">e<f x1200AAFF="arial">n<f x120055FF="arial">]"'+"<br/>"+" Perintah[ . ] : cmd (commando).",True)
        if user.name not in netizen and not user.name in whitelist and not user.name in moderator and not user.name in coadmin and not user.name in admin and not user.name in owners: room.message                       ("<br/>"'<b>'+user.name+'</b> Rank - <f x12FF0000="arial">[<f x12FF5500="arial">N<f x12FFAA00="arial">o<f x12AAFF00="arial">-<f x1255FF00="arial">R<f x1200FF55="arial">a<f x1200FFAA="arial">n<f x1200AAFF="arial">k<f x120055FF="arial">]"'+"<br/>"+" Perintah[ . ] : cmd (commando).",True)

                                             ############
                                             ## Ranker ##
                                             ############

      if cmd == "ranker":
        room.message("<br/><f x12FF8000='0'><b>List Ranker</b><br/><f x120000FF='0'><b>Owner:</b></f> %s<br/><f x12FF0000='0'><b>Admin:</b></f> %s<br/><f x1254FF00='0'><b>Co-Admin:</b></f> %s<br/><f x12FF00FF='0'><b>Moderator: </b></f> %s<br/><f x1200AAFF='0'><b>WhiteList: </b></f> %s" % (", ".join(owners), ", ".join(admin), ", ".join(coadmin), ", ".join(moderator), ", ".join(whitelist)),True)

                                             ###########        
                                             ## Staff ##
                                             ###########

      if cmd == "staff":
        room.message("<br/><f x120000FF='0'><b>Owner:</b></f> %s<br/><f x12FF0000='0'><b>Admin:</b></f> %s<br/><f x12FF0000='0'><b>Co-Admin:</b></f> %s" % (", ".join(owners), ", ".join(admin), ", ".join (coadmin)),True)

                                             ##########        
                                             ## Rank ##
                                             ##########

      if cmd == "rank":
        
        if args:
          sss = args
          if sss in owners and sss not in admin and sss not in coadmin and sss not in moderator and sss not in whitelist and sss not in hiddenlist:
              room.message('<b>'"Rank "+sss.title()+'</b>" adalah Rank 5 <f x12FF0000="arial">[<f x12FF6D00="arial">O<f x12FFDA00="arial">w<f x1292FF00="arial">n<f x1225FF00="arial">e<f x1200FF6D="arial">r<f x1200FFDA="arial">s<f x1200FF45="arial">] '+'<br/>'+' <f x12FF0000="arial">Perintah[.]<f x123366FF="arial">', True)
          if sss in admin and sss not in owners and sss not in coadmin and sss not in moderator and sss not in whitelist and sss not in hiddenlist:
              room.message('<b>'"Rank "+sss.title()+'</b>" adalah Rank 4 <f x12FF0000="arial">[<f x12FF4500="arial">A<f x12FF8A00="arial">d<f x12FFCF00="arial">m<f x12BAFF00="arial">i<f x1200FF6D="arial">n<f x1230FF00="arial">] '+'<br/>'+' <f x123366FF="arial">Perintah[.]<f x12FF0000="arial">', True)
          if sss in coadmin and sss not in owners and sss not in admin and sss not in moderator and sss not in whitelist and sss not in hiddenlist:
              room.message('<b>'"Rank "+sss.title()+'</b>" adalah Rank 3 <f x12FF0000="arial">[<f x12FF4500="arial">C<f x12FF8A00="arial">o<f x12FFCF00="arial">-<f x12BAFF00="arial">A<f x1200FF6D="arial">d<f x1200FF45="arial">m<f x1200FF8A="arial">i<f x1200FFCF="arial">n<f x1230FF00="arial">] '+'<br/>'+' <f x123366FF="arial">Perintah[.]<f x12FF0000="arial">', True)
          if sss in moderator and sss not in owners and sss not in admin and sss not in coadmin and sss not in whitelist and sss not in hiddenlist:
              room.message('<b>'"Rank "+sss.title()+'</b>" adalah Rank 2 <f x12FF0000="arial">[<f x12FF4500="arial">M<f x12FF8A00="arial">o<f x12FFCF00="arial">d<f x12BAFF00="arial">e<f x1275FF00="arial">r<f x1230FF00="arial">a<f x1200FF45="arial">t<f x1200FF8A="arial">o<f x1200FFCF="arial">r<f x1200BAFF="arial">] '+'<br/>'+' <f x12FF0000="arial">Perintah[.]<f x123366FF="arial">', True)
          if sss in whitelist and sss not in owners and sss not in moderator and sss not in coadmin and sss not in admin and sss not in owners and sss not in hiddenlist:
              room.message('<b>'"Rank "+sss.title()+'</b>" adalah Rank 1 <f x12FF0000="arial">[<f x12FF5500="arial">W<f x12FFAA00="arial">h<f x12AAFF00="arial">i<f x1255FF00="arial">t<f x1200FF55="arial">e<f x1200FFAA="arial">L<f x1200AAFF="arial">i<f x120055FF="arial">s<f x1200FF6D="arial">t<f x1200FFDA="arial">] '+'<br/>'+' <f x123366FF="arial">Perintah[.]<f x12FF0000="arial">', True)
          if sss in hiddenlist and sss not in owners and sss not in moderator and sss not in coadmin and sss not in admin and sss not in owners and sss not in whitelist:
              room.message('<b>'"Rank "+sss.title()+'</b>" adalah Rank 1 <f x12FF0000="arial">[<f x12FF5500="arial">H<f x12FFAA00="arial">i<f x12AAFF00="arial">d<f x1255FF00="arial">d<f x1200FF6D="arial">e<f x1200FFDA="arial">n<f x1200FF45="arial">L<f x1255FF00="arial">i<f x1200FF55="arial">s<f x1200FFAA="arial">t<f x1200AAFF="arial">] '+'<br/>'+' <f x123366FF="arial">Perintah[.]<f x12FF0000="arial">', True)
          if sss in netizen not in owners and sss not in moderator and sss not in coadmin and sss not in admin and sss not in owners and sss not in whitelist and sss not in hiddenlist:
              room.message('<b>'"Rank "+sss.title()+'</b>" adalah Rank 0 <f x12FF0000="arial">[<f x12FF5500="arial">C<f x12FFAA00="arial">i<f x12AAFF00="arial">t<f x1255FF00="arial">i<f x1200FF55="arial">Z<f x1200FFAA="arial">e<f x1200AAFF="arial">n<f x120055FF="arial">] '+'<br/>'+' <f x123366FF="arial">Perintah[.]<f x12FF0000="arial">', True)
          if sss not in owners and sss not in moderator and sss not in coadmin and sss not in admin and sss not in owners and sss not in whitelist and sss not in netizen and sss not in hiddenlist:
              room.message(sss.title()+" Tidak mempunyai rank :) ", True)

                                             ##############
                                             ## Set Rank ##
                                             ##############

      elif cmd == "setow" and self.getAccess(user) >= 4:
        name = args
        if name not in owners and name not in blacklist:
          room.message("Sukses menambahkan kedaftar Owners")
          owners.append(name)
          f = open("owners.txt","w")
          f.write("\n".join(owners))
          f.close
        else:
          room.message("User tersebut sudah ada di daftar Owners")
        if name in admin:
          admin.remove(name)
          f = open("admin.txt", "w")
          f.write("\n".join(admin))
          f.close()
        if name in coadmin:
          coadmin.remove(name)
          f = open("coadmin.txt", "w")
          f.write("\n".join(coadmin))
          f.close()
        if name in moderator:
          moderator.remove(name)
          f = open("moderator.txt", "w")
          f.write("\n".join(moderator))
          f.close()
        if name in whitelist:
          whitelist.remove(name)
          f = open("whitelist.txt", "w")
          f.write("\n".join(whitelist))
          f.close()
        if name in hiddenlist:
          hiddenlist.remove(name)
          f = open("hiddenlist.txt", "w")
          f.write("\n".join(hiddenlist))
          f.close()

      elif cmd == "setad" and self.getAccess(user) >= 4:
        name = args
        if name not in admin and name not in blacklist:
          room.message("Sukses menambahkan kedaftar Admin")
          admin.append(name)
          f = open("admin.txt","w")
          f.write("\n".join(admin))
          f.close
        else:
          room.message("User tersebut sudah ada di daftar Admin")
        if name in coadmin:
          coadmin.remove(name)
          f = open("coadmin.txt", "w")
          f.write("\n".join(coadmin))
          f.close()
        if name in moderator:
          moderator.remove(name)
          f = open("moderator.txt", "w")
          f.write("\n".join(moderator))
          f.close()
        if name in whitelist:
          whitelist.remove(name)
          f = open("whitelist.txt", "w")
          f.write("\n".join(whitelist))
          f.close()
        if name in hiddenlist:
          hiddenlist.remove(name)
          f = open("hiddenlist.txt", "w")
          f.write("\n".join(hiddenlist))
          f.close()

      elif cmd == "setcad" and self.getAccess(user) >= 4:
        name = args
        if name not in coadmin and name not in blacklist:
          room.message("Sukses menambahkan kedaftar Co-Admin")
          coadmin.append(name)
          f = open("coadmin.txt","w")
          f.write("\n".join(coadmin))
          f.close
        else:
          room.message("User tersebut sudah ada di daftar Co-Admin")
        if name in admin:
          admin.remove(name)
          f = open("admin.txt", "w")
          f.write("\n".join(admin))
          f.close()
        if name in moderator:
          moderator.remove(name)
          f = open("moderator.txt", "w")
          f.write("\n".join(moderator))
          f.close()
        if name in whitelist:
          whitelist.remove(name)
          f = open("whitelist.txt", "w")
          f.write("\n".join(whitelist))
          f.close()
        if name in hiddenlist:
          hiddenlist.remove(name)
          f = open("hiddenlist.txt", "w")
          f.write("\n".join(hiddenlist))
          f.close()

      elif cmd == "setmo" and self.getAccess(user) >= 2:
        name = args
        if name not in moderator and name not in blacklist:
          room.message("Sukses menambahkan kedaftar Moderator")
          moderator.append(name)
          f = open("moderator.txt","w")
          f.write("\n".join(moderator))
          f.close
        else:
          room.message("User tersebut sudah ada di daftar Moderator")
        if name in admin:
          admin.remove(name)
          f = open("admin.txt", "w")
          f.write("\n".join(admin))
          f.close()
        if name in coadmin:
          coadmin.remove(name)
          f = open("coadmin.txt", "w")
          f.write("\n".join(coadmin))
          f.close()
        if name in whitelist:
          whitelist.remove(name)
          f = open("whitelist.txt", "w")
          f.write("\n".join(whitelist))
          f.close()
        if name in hiddenlist:
          hiddenlist.remove(name)
          f = open("hiddenlist.txt", "w")
          f.write("\n".join(hiddenlist))
          f.close()
                                             ###############
                                             ## WhiteList ##
                                             ###############

      elif cmd == "wl" and self.getAccess(user) >= 2:
        name = args
        if name not in whitelist and name not in owners and name not in admin and name not in coadmin and name not in moderator and name not in blacklist:
          room.message("Sukses menambahkan kedaftar WhiteList")
          whitelist.append(name)
          f = open("whitelist.txt","w")
          f.write("\n".join(whitelist))
          f.close
        else:
          room.message("User tersebut sudah terdaftar")
        if name in hiddenlist:
          hiddenlist.remove(name)
          f = open("hiddenlist.txt", "w")
          f.write("\n".join(hiddenlist))
          f.close()
          
                                             ################
                                             ## HiddenList ##
                                             ################

      elif cmd == "dl" and self.getAccess(user) >1:
        name = args
        if name not in hiddenlist and name not in whitelist and name not in owners and name not in admin and name not in coadmin and name not in moderator and name not in blacklist:
          room.message("Sukses menambahkan kedaftar HiddenList")
          hiddenlist.append(name)
          f = open("hiddenlist.txt","w")
          f.write("\n".join(hiddenlist))
          f.close
        else:
          room.message("User tersebut sudah ada di daftar HiddenList")

      if "wl me" == message.body or "dl me" == message.body:
       if user.name not in whitelist and self.getAccess(user) == 0:
         hiddenlist.append(user.name)
         room.message(user.name+", Anda sudah bergabung kedalam HiddenList. Anda dapat melihat Rank Anda dengan cara .myrank", True)
         f = open("hiddenlist.txt", "w")
         f.write("\n".join(hiddenlist))
         f.close()
       else:
         room.message("Nama Anda sudah ada di daftar HiddenList")
                     
                                             ###############
                                             ## BlackList ##
                                             ###############

      elif cmd == "bl" and self.getAccess(user) >= 3:
        name = args
        if name not in whitelist and name not in owners and name not in admin and name not in coadmin and name not in moderator and name not in whitelist:
          room.message("User tersebut sudah di BlackList")
          blacklist.append(name)
          f = open("blacklist.txt","w")
          f.write("\n".join(blacklist))
          f.close
        else:
          room.message("User tersebut sudah ada didalam daftar blacklist")
          
                                             #############
                                             ## Un-List ##
                                             #############

      if cmd == "uow" and self.getAccess(user) >= 4:
        try:
          if args in owners:
            owners.remove(args)
            f = open("owners.txt","w")
            f.write("\n".join(owners))
            f.close()
            room.message("Sukses mencopot jabatan Owner")
        except:
          room.message("Gagal mencopot jabatan Owner")

      if cmd == "uad" and self.getAccess(user) >= 4:
        try:
          if args in admin:
            admin.remove(args)
            f = open("admin.txt","w")
            f.write("\n".join(admin))
            f.close()
            room.message("Sukses mencopot jabatan Admin")
        except:
          room.message("Gagal mencopot jabatan Admin")

      if cmd == "ucad" and self.getAccess(user) >= 4:
        try:
          if args in coadmin:
            coadmin.remove(args)
            f = open("coadmin.txt","w")
            f.write("\n".join(coadmin))
            f.close()
            room.message("Sukses mencopot jabatan Co-Admin")
        except:
          room.message("Gagal mencopot jabatan Co-Admin")

      if cmd == "umo" and self.getAccess(user) >= 3:
        try:
          if args in moderator:
            moderator.remove(args)
            f = open("moderator.txt","w")
            f.write("\n".join(moderator))
            f.close()
            room.message("Sukses mencopot jabatan Moderator")
        except:
          room.message("Gagal mencopot jabatan Moderator")

      if cmd == "uwl" and self.getAccess(user) >= 2:
        try:
          if args in whitelist:
            whitelist.remove(args)
            f = open("whitelist.txt","w")
            f.write("\n".join(whitelist))
            f.close()
            room.message("Sukses menghapus dari WhiteList")  
        except:
          room.message("Gagal menghapus dari WhiteList")

      if cmd == "udl" and self.getAccess(user) >= 2:
        try:
          if args in hiddenlist:
            hiddenlist.remove(args)
            f = open("hiddenlist.txt","w")
            f.write("\n".join(hiddenlist))
            f.close()
            room.message("Sukses menghapus dari HiddenList")  
        except:
          room.message("Gagal menghapus dari HiddenList")

                                             ##################
                                             ## Un-BlackList ##
                                             ##################

      if cmd == "ubl" and self.getAccess(user) >= 3:
        try:
          if args in blacklist:
            blacklist.remove(args)
            f = open("blacklist.txt","w")
            f.write("\n".join(blacklist))
            f.close()
            room.message("Sukses Menghapus dari daftar BlackList")
        except:
          room.message("Gagal Menghapus dari daftar BlackList")

                                             #########################
                                             ## Check Status Online ##
                                             #########################


      if cmd == "cso" or cmd=="checkstatusonline":
        try:
          resp = urlreq.urlopen("http://"+args+".chatango.com").read().decode()
          fap = bool('chat with' in resp.lower())
          fapper = ""
          if fap == True:
            fapper += "<b>Online</b>"
          if fap == False:
            fapper += "<b>Offline</b>"
          room.message(args+" is "+fapper+", more info: http://"+args+".chatango.com/i?17",True)
        except:
          room.message(args+" is not exist..")

                                             ##########
                                             ## Find ##
                                             ##########

      if cmd == "find" and len(args) > 0:
        name = args.split()[0].lower()
        if not ch.User(name).roomnames:
          room.message("dia sedang offline, mungkin dia lagi bertapa.")
        else:
          room.message("kamu dapat menemukan  %s Di %s" % (args, ", ".join(ch.User(name).roomnames)),True)
  
                                             ########        
                                             ## GS ##
                                             ########
        
      if cmd == "gs":
            room.message(gs(args), True)

      if cmd == "gis" or cmd == "google_image_search" or cmd == "gimagesearch":
        if args:
          room.message(gis(args),True)
        else:
          room.message("Please type what you want to watch in Google Image..",True)

      if cmd == "yt" or cmd == "youtube":
        if args:
          room.message(yts(args),True)
        else:
          room.message("Please type what you want to watch in Youtube..",True)

                                             #################
                                             ## Auto Delete ##
                                             #################

      if cmd == "autodel" and self.getAccess(user) >= 3:
        try:
          if args not in autodel:
            autodel.append(args)
            f = open("autodelete.txt","w")
            f.write("\n".join(autodel))
            f.close()
            room.message("Sukses menjalankan autodelete")
        except:
          room.message("Gagal menjalankan autodelete")

                                             ######################
                                             ## Auto Delete List ##
                                             ######################

      if cmd == "autodelist" and self.getAccess(user) >= 1:
         a = ", ".join(autodel)
         room.message("They are : "+str(a)+"",True)

      elif cmd == "adl" and self.getAccess(user) >= 1:
        name = args
        if name not in hiddenlist and name not in whitelist and name not in owners and name not in admin and name not in coadmin and name not in moderator:
          room.message("Sukses menambahkan kedaftar Auto-delete")
          autodel.append(name)
          f = open("autodel.txt","w")
          f.write("\n".join(autodel))
          f.close
        else:
          room.message("User tersebut sudah ada didaftar Auto-delete")
             
                                             ##########
                                             ## Eval ##
                                             ##########

      if cmd == "ev" or cmd == "eval" or cmd == "e":
        if self.getAccess(user) >= 3:
          ret = eval(args)
          if ret == None:
            room.message("Done.")
            return
          room.message(str(ret))
          
      if cmd.lower() == "addmod":
        if len(args) > 0:
            if self.name in room.ownername:
                if args in room.modnames:
                    room.message("<font color='#00FF00'>%s</font> sudah ditambahkan kedalam daftar Moderator Room" % args, True)
                   
                if self.getAccess(user) == 4:
                    room.addMod(ch.User(args))
                    room.message("<font color='#00FF00'>%s</font> telah dipromosikan menjadi Moderator Room" % args, True)
                else:
                    room.message("Denied.")
            else:
                room.message("Maaf, ini bukan chat room milik Freya :D")
        else:
            room.message("Siapa yg ingin kamu jadikan Moderator Room ?")

      if cmd == "ping":
         if args == "":
          usrs = []
          gay = []
          finale = []
          prop = 0
          prop = prop + len(room._userlist) - 1
          for i in room._userlist:
            i = str(i)
            usrs.append(i)
          while prop >= 0:
            j = usrs[prop].replace("<User: ", "")
            i = j.replace(">", "")
            gay.append(i)
            prop = prop - 1
          for i in gay:
            if i not in finale:
              finale.append(i)
          if len(finale) > 40:
            room.message("@%s"% (" @".join(finale[:41])), True)
                
          if len(finale) <=40 :
            room.message("@%s"% (" @".join(finale)), True)
                
         if args == "":
           if args not in self.roomnames:
             room.message("I'm not there.")
                  
             return

                                             #############
                                             ## Rainbow ##
                                             #############
#RB1
      if cmd == "rb":
        if args == "":
          rain = rainbow('Rainbow')
          room.message(rain,True)
                      
        else: 
          rain = rainbow(args)
          room.message(rain,True)
#RB2
      if cmd == "rb2":
        if args == "":
          rain = rainbow('Rainbow')
          room.message(rain)
                    
        else: 
          rain = rainbow(args)
          room.message(rain)
          
                                             #################
                                             ## Random User ##
                                             #################

      if cmd == "randomuser" or cmd == "ru":
        room.message(random.choice("@"+room.usernames))
          
                                             ##########################
                                             ###### Check if Mod ######
                                             ## Not really important ##
                                             ##########################

      elif cmd == "ismod":
        user = ch.User(args)
        if room.getLevel(user) > 2:
          room.message("yes")
        else:
          room.message("nope")

                                             ############################
                                             ###### BAN dan Un-BAN ######
                                             ##    Di Room Chatango    ##
                                             ############################
      if cmd == "ban":
          if self.user.name in room.modnames:
              if self.getAccess(user) >= 3:
                if len(args) > 0:
                    if self.getAccess(user) >= 3:
                      if args.lower() == user.name:
                          room.message("Banning yourself...not a wise move.")
                          return

                      if user.name in owners:
                          room.banUser(ch.User(args))
                          room.clearUser(ch.User(args))
                          room.message("<font color='#F7FE2E'>%s</font> has been <font color='#FF0000'>BANNED</font> by Master. You done fucked up." % args, True)                                  
                          return

                      if args in owners or args in admin:
                            room.message("<font color='#FF0000'>%s</font> is unbannable through me. ^^" % args.capitalize(), True)                                    
                            return
                      else:
                          if args in room.usernames:
                            room.clearUser(ch.User(args))
                            room.banUser(ch.User(args))
                            room.message("<font color='#F7FE2E'>%s</font> has been <font color='#FF0000'>BANNED</font> >:D!" % args, True)                                    
                          else:
                              room.message("I can't find the bastard! D:<")                                      
                    else:
                        room.message("<font color='#FF0000'>Denied.</font>", True)
                else:
                    room.message('Ban who?')
          else:
              room.message("I've no power in this realm...")
                       

             
      if cmd == "unban" or cmd == "ub" or cmd == "UnBan" or cmd == "Unban" or cmd == "Scoate Interzicerea" or cmd == "Scoate interzicerea":
          if user.name in owners:
              name = args
              if user.name in owners: return
              room.unban(ch.User(name))
              room.message("<b>%s</b> is unbanned" % (name), True)
              self.pm.message(ch.User(name.lower()), "You have been unbanned from %s by %s. Please behave lik a Punk!!" % (room.name, user.name))

                                             #########
                                             ## Say ##
                                             #########

      if cmd == "say":
        room.message(args,True)
          

      elif cmd == "b" and self.getAccess(user) > 2:
          r = room.name
          l = "http://ch.besaba.com/mty.htm?"+r+"+"
          for room in self.rooms:
            room.message(args, True)

                                             #########        
                                             ## Fax ##
                                             #########

      if cmd == "fax" or cmd == "Fax" and self.getAccess(user) > 3:
        try:
          name, body = args.split(" ", 1)
          l = "http://dashboard.ariea.net/panel/"+room.name
          if name in self.roomnames :
            self.getRoom(name).message('<b>Message</b></font> - %s  in <a href=\"%s" target=\"_blank\"><u>%s</u></a> : <font color="#66FFFF"><i> %s <i></font>' % ((user.name), l, room.name, body),True)
            room.message("Sent")                    
          else:
            room.message("I haven't joined that room")
        except:room.message("|ERROR| Example Fax: .fax sl-nime")
          
                                             ################
                                             ## INFO LEWAT ##
                                             ################

      elif cmd == "il" and self.getAccess(user) > 3:
          r = room.name
          l = "http://ch.besaba.com/mty.htm?"+r+"+"
          for room in self.rooms:
            room.message("[<font color='#6699CC'><b>INFO</b></font>] from - "+sntonick(user.name)+ " : <font color='#33FF33'><i>"+args+"<i></font>", True)

                                             ################
                                             ## New Update ##
                                             ################

      elif cmd == "nu" and self.getAccess(user) > 1:
          r = room.name
          l = "http://ch.besaba.com/mty.htm?"+r+"+"
          for room in self.rooms:
            room.message("[<font color='#6699CC'><b> New Post Streaming Lagi-Nime"+ " </b></font>]<br/> <font color='#33FF33'><i>"+args+"<i></font>", True)


                                             ###############
                                             ## Broadcast ##
                                             ###############

      elif cmd == "bc" and self.getAccess(user) > 2:
          r = room.name
          l = "http://ch.besaba.com/mty.htm?"+r+"+"
          for room in self.rooms:
            room.message("[<font color='#6699CC'><b>Broadcast</b></font>] from - "+sntonick(user.name)+ " : <font color='#33FF33'><i>"+args+"<i></font>", True)
          
                                             ############
                                             ## Define ##
                                             ############

      elif cmd == "define" or cmd == "df" and len(args) > 0:
          try:
            try:
              word, definition = args.split(" as ",1)
              word = word.lower()
            except:
              word = args
              definition = ""
            if len(word.split()) > 4:
              room.message("gagal memuat catatan")
              return
            elif len(definition) > 0:
              if word in dictionary:
                room.message("%s catatan siap" % user.name.capitalize())
              else:
                dictionary[word] = json.dumps([definition, user.name])
                f =open("definitions.txt", "w")
                for word in dictionary:
                  definition, name = json.loads(dictionary[word])
                  f.write(json.dumps([word, definition, name])+"\n")
                f.close
                room.message("Catatan disimpan")
            else:
              if word in dictionary:
                definition, name = json.loads(dictionary[word])
                room.message("<br/>ID : %s<br/>Keyword : %s<br/> <br/>%s" % (name, word, definition),True)
          except:
            room.message("something wrong")
                    
                                             ###################
                                             ## Un-definition ##
                                             ###################

      if cmd == "udf" and len(args) > 0:
          try:
            word = args
            if word in dictionary:
              definition, name = json.loads(dictionary[word])
              if name == user.name or self.getAccess(user) >= 3:
                del dictionary[word]
                f =open("definitions.txt", "w")
                for word in dictionary:
                  definition, name = json.loads(dictionary[word])
                  f.write(json.dumps([word, definition, name])+"\n")
                f.close
                room.message(args+" catatan sudah dihapus")
                return
              else:
                room.message("<b>%s</b> you can not remove this define only masters or the person who defined the word may remove definitions" % user.name, True)
                return
            else:
               room.message("<b>%s</b> is not yet defined you can define it by typing <b>define %s: meaning</b>" % args, True)
          except:
            room.message("Gagal menghapus catatan")
            return


                                             ####################
                                             ## Set Background ##
                                             ####################
        
      if cmd== "sbg":
            if self.getAccess(user) >= 3:
              if len(args) > 0:
                  if args == "on":
                    room.setBgMode(1)
                    room.message("Background On")
                    return
                  if args == "off":
                    room.setBgMode(0)
                    room.message("Background Off")

      if cmd == "change":
        if args == "azusafreya" or args == "azu" or args == "a":
          room.logout()
          room.login("azusafreya", "ripkzr123")
          room.message("Azusa datang... (^_^)")
          print("[INFO] Change Account AzusaFreya")

      if cmd == "change":
        if args == "mezishi718" or args == "mez" or args == "m":
          room.logout()
          room.login("mezishi718", "ripkzr123")
          room.message("I'm coming")
          print("[INFO] Change Account Mezishi718")

      if cmd == "change":
        if args == "ryanadipratama718" or args == "ryan" or args == "r":
          room.logout()
          room.login("ryanadipratama718", "ripkzr123")
          room.message("wut..?!")
          print("[INFO] Change Account Ryanadipratama718")
                                             ############
                                             ## Mydict ##
                                             ############

      elif cmd == "md" or cmd == "mydict":
          arr = []
          for i in dictionary:
            if user.name in dictionary[i]:
              arr.append(i)
          if len(arr) > 0:
            room.message("Kamu memiliki <b>"+str(len(arr))+"</b> catatan di Freya, <br/> yaitu : <i> %s"% (', '.join(sorted(arr))), True)
          else:
            room.message("kamu tidak memiliki catatan di Freya.")
          
                                             ##############
                                             ## See Dict ##
                                             ##############

      elif cmd == "sd" or cmd == "seedict":
          if not args:
            room.message("Catatan siapa yang ingin kamu lihat ?")
            return
          args = args.lower()
          if pars(args) == None:
            args = args.lower()
          if pars(args) != None:
            args = pars(args)
          arr = []
          for i in dictionary:
            if args in dictionary[i]:
              arr.append(i)
          if len(arr) > 0:
            room.message("<b>"+args.title()+"</b> memiliki <b>"+str(len(arr))+"</b> catatan di Freya, <br/> yaitu : <i> %s"% (', '.join(sorted(arr))), True)
          else:
            room.message(args.title()+" tidak mempunyai catatan di Freya.")
          
                                             ##############
                                             ## See Nick ##
                                             ##############

      if cmd == "seenick":
            try:
              if args in nicks:
                room.message("Nick "+args+" : "+sntonick(args)+"", True)
              else:
                room.message(args+" Belum membuat nick di Freya")
            except:
              return      
          
                                             #############
                                             ## Profile ##
                                             #############

      elif cmd=="prof" or cmd == "profile":
        try:
          args=args.lower()
          stuff=str(urlreq.urlopen("http://"+args+".chatango.com").read().decode("utf-8"))
          crap, age = stuff.split('<span class="profile_text"><strong>Age:</strong></span></td><td><span class="profile_text">', 1)
          age, crap = age.split('<br /></span>', 1)
          crap, gender = stuff.split('<span class="profile_text"><strong>Gender:</strong></span></td><td><span class="profile_text">', 1)
          gender, crap = gender.split(' <br /></span>', 1)
          if gender == 'M':
              gender = 'Male'
          elif gender == 'F':
              gender = 'Female'
          else:
              gender = '?'
          crap, location = stuff.split('<span class="profile_text"><strong>Location:</strong></span></td><td><span class="profile_text">', 1)
          location, crap = location.split(' <br /></span>', 1)
          crap,mini=stuff.split("<span class=\"profile_text\"><!-- google_ad_section_start -->",1)
          mini,crap=mini.split("<!-- google_ad_section_end --></span>",1)
          mini=mini.replace("<img","<!")
          picture = '<a href="http://fp.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/full.jpg" style="z-index:59" target="_blank">http://fp.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/full.jpg</a>'
          prodata = '<br/> <a href="http://chatango.com/fullpix?' + args + '" target="_blank">' + picture + '<br/><br/> Age: '+ age + ' <br/> Gender: ' + gender +  ' <br/> Location: ' +  location + '' '<br/> <a href="http://' + args + '.chatango.com" target="_blank"><u>Chat With User</u></a> ' "<br/><br/> "+ mini 
          room.message(prodata,True)
        except:
          room.message(""+args+" doesn't exist o.o ")
          
                                             ##########
                                             ## Mini ##
                                             ##########

      elif cmd=="mini":
        try:
          args=args.lower()
          stuff=str(urlreq.urlopen("http://"+args+".chatango.com").read().decode("utf-8"))
          crap,mini=stuff.split("<span class=\"profile_text\"><!-- google_ad_section_start -->",1)
          mini,crap=mini.split("<!-- google_ad_section_end --></span>",1)
          mini=mini.replace("<img","<!")
          prodata = '<br/>'+mini
          room.message(prodata,True)
        except:
          room.message(""+args+" doesn't exist o.o ")
          
                                             #############
                                             ## BG Time ##
                                             #############

      if cmd == "bgtime" or cmd == "bgt":
           if args:
            if " " in args.lower():
              room.message(args.lower()+" does not exist.", True)
            else:
              if len(args.split(" ", -1)) != 1:
                return
              if len(args) == 1:
                f_args, s_args = args, args
              elif len(args) > 1:
                f_args, s_args = args[0], args[1]
     
              def Bgtime(args):
                try:
                  expired = True
                  url = ("http://st.chatango.com/profileimg/"+f_args+"/"+s_args+"/"+args+"/mod1.xml")
                  f = urlreq.urlopen(url)
                  data = f.read().decode("utf-8")
                  e = ET.XML(data)
                  bg = e.findtext("d")
                  bg = int(urlreq.unquote(bg))
                  if bg - int(time.time()) < 0:
                    total_seconds = int(time.time())-bg
                    aa = str(datetime.datetime.fromtimestamp(bg).strftime("%A, %d %B %Y(%I:%M %p)"))
                  else:
                    total_seconds = bg-int(time.time())
                    aa = str(datetime.datetime.fromtimestamp(bg).strftime("%A, %d %B %Y(%I:%M %p)"))
                    expired = False
     
                  MINUTE = 60
                  HOUR   = MINUTE * 60
                  DAY    = HOUR * 24
                  MONTH = DAY * 30
                  YEAR = MONTH * 12

                  years = int( total_seconds / YEAR )
                  months = int( ( total_seconds % YEAR ) / MONTH )
                  days   = int( ( total_seconds % MONTH ) / DAY )
                  hours   = int( ( total_seconds % DAY ) / HOUR )
                  minutes = int( ( total_seconds % HOUR ) / MINUTE )
                  seconds = int( total_seconds % MINUTE )
                  string = ""
                  if years > 0 or years < 0:
                    string += str(years) + " " + (years == 1 and "year" or "years" ) + ", "
                  if months > 0 or months < 0:
                    string += str(months) + " " + (months == 1 and "month" or "months" ) + ", "
                  if days > 0 or days < 0:
                    string += str(days) + " " + (days == 1 and "day" or "days" ) + ", "
                  if len(string) > 0 or hours > 0:
                    string += str(hours) + " " + (hours == 1 and "hour" or "hours" ) + ", "
                  if len(string) > 0 or minutes > 0:
                    string += str(minutes) + " " + (minutes == 1 and "minute" or "minutes" ) + ", "
                  string += str(seconds) + " " + (seconds == 1 and "second" or "seconds" )
                  love=urlreq.urlopen("http://fp.chatango.com/profileimg/"+args[0]+"/"+args[1]+"/"+args+"/msgbg.xml").read().decode()
                  love=dict([x.replace('"', '').split("=") for x in re.findall('(\w+=".*?")', love)[1:]])
                  p = love["bgc"]
                  c = love["bgalp"]
                  b = love["ialp"]
                  l = love["useimg"]
                  t = love["align"]
                  if "tr" in t:
                      lk = "Top Right"
                  if "tl" in t:
                      lk = "Top Left"
                  if "br" in t:
                      lk = "Bottom Rigth"
                  if "bl" in t:
                      lk = "Bottom Left"
                  if "1" in l:
                       mn = "yes"
                  else:
                        mn = "no"
                  if "yes" in mn:
                       gambar = "http://fp.chatango.com/profileimg/"+args.lower()[:1]+"/"+args.lower()[1:2]+"/"+args.lower()+"/msgbg.jpg"
                  else:
                      gambar = "No Have Image"
                  m = love["tile"]
                  if "1" in m:
                       ea = "yes"
                  else:
                        ea = "no"
                  if expired == True:
                    return ""+gambar+"<br/>Expired : "+string+" ago<br/>Date : "+aa+"ago <br/>Color : #"+p+"<br/>Transparency : BG : "+c+"% IMG : "+b+"%"+"<br/>Use Image : "+mn+"<br/>Tile : "+ea+"<br/>Align : "+lk+""
                  elif expired == False:
                    return ""+gambar+"<br/>Remaining : "+string+"<br/>Date : "+aa+"<br/>Color : #"+p+"<br/>Transparency : BG : "+c+"% IMG : "+b+"%"+"<br/>Use Image : "+mn+"<br/>Tile : "+ea+"<br/>Align : "+lk+""
                except:
                  return "Never had background."
              room.message("<br/><b>FOR : "+args.lower()+"</b><br/>Background image<br/>"+Bgtime(args), True)
           else:
            room.message("<b>Do +bgtime (username)</b>", True)          

                                             ######################
                                             ## Background Image ##
                                             ######################

      if cmd == "bgimg":
        try:
          args=args.lower()
          picture = '<a href="http://st.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/msgbg.jpg" style="z-index:59" target="_blank">http://fp.chatango.com/profileimg/' + args[0] + '/' + args[1] + '/' + args + '/msgbg.jpg</a>'
          prodata = '<br/>'+picture
          room.message("<br/>"+"User ID : "+args+"<br/>Background :"+prodata,True)
        except:
          room.message(""+args+" doesn't exist:'v")
          
                                             ######################
                                             ## Private Massages ##
                                             ######################

      elif cmd=="pm":
        data = args.split(" ", 1)
        if len(data) > 1:
          name , args = data[0], data[1]
          self.pm.message(ch.User(name), "[Private.Message] By - "+user.name+" : "+args+" ")
          room.message("Sent to "+name+"")
          
                                             ##############
                                             ## Sentnote ##
                                             ##############

      elif cmd == "inbox":
          if user.name in sn:
            mesg = len(sn[user.name])
            room.message("["+str(mesg)+"] Kamu mempunyai sebuah pesan. Ketik (.rn) untuk membacanya")
          else:
            sn.update({user.name:[]})
            mesg = len(sn[user.name])
            room.message("["+str(mesg)+"] Kamu mempunyai sebuah pesan. Ketik (.rn) untuk membacanya")
          
                                             ##############
                                             ## Sendnote ##
                                             ##############

      elif cmd == "sn" or cmd == "sendnote":
          args.lower()
          untuk, pesan = args.split(" ", 1)
          if untuk[0] == "+":
                  untuk = untuk[1:]
          else:
                  if pars(untuk) == None:
                    room.message("mungkin "+untuk+" sedang offline.")
                    return
                  untuk = pars(untuk)
          if untuk in sn:
            sn[untuk].append([user.name, pesan, time.time()])
            if untuk not in notif:
              notif.append(untuk)
            else:pass
          else:
            sn.update({untuk:[]})
            sn[untuk].append([user.name, pesan, time.time()])
            if untuk not in notif:
              notif.append(untuk)
            else:pass
          room.message('Mengirim  pesan ke %s'% (untuk)+"'s Sukses" , True)
          
                                             ##############
                                             ## Readnote ##
                                             ##############

      elif cmd =="rn" or cmd =="readnote":
          if user.name not in sn:
            sn.update({user.name:[]})
          user=user.name.lower()
          if len(sn[user]) > 0:
            messg = sn[user][0]
            dari, pesen, timey = messg
            timey = time.time() - int(timey)
            minute = 60
            hour = minute * 60
            day = hour * 24
            days =  int(timey / day)
            hours = int((timey % day) / hour)
            minutes = int((timey % hour) / minute)
            seconds = int(timey % minute)
            string = ""
            if days > 0:
              string += str(days) + " " + (days == 1 and "day" or "days" ) + ", "
            if len(string) > 0 or hours > 0:
              string += str(hours) + " " + (hours == 1 and "hour" or "hours" ) + ", "
            if len(string) > 0 or minutes > 0:
              string += str(minutes) + " " + (minutes == 1 and "minute" or "minutes" ) + ", "
            string += str(seconds) + " " + (seconds == 1 and "second" or "seconds" )
            room.message("Pesan dari "+dari+" - "+pesen+" - "+string+" yang lalu", True)
            try:
              del sn[user][0]
              notif.remove(user)
            except:pass
          else:room.message('%s'%(user)+", kamu tidak mempunyai sebuah pesan" , True)

                                             ##########################
                                             ## Join room + Roomname ##
                                             ##########################

      if cmd == "join" and len(args) > 1:
          if self.getAccess (user) >= 1:
              if args not in self.roomnames:
                room.message("Baik aku join ke "+args+" ...")
                self.joinRoom(args)
              else:
                room.message("aku sudah ada disana ...")
              print("[SAVE] SAVING Rooms...")
              f = open("rooms.txt", "w")
              f.write("\n".join(self.roomnames))
              f.close()
                    
                                             ##################
                                             ## Leave + Room ##
                                             ##################

      elif cmd == "leave"  and self.getAccess(user) >=3:
        if not args:args=room.name
        room.message("Baik Freya akan keluar dari room tersebut, Maaf kalo Freya punya salah... (T-T)")
        self.leaveRoom(args)
        print("[SAVE] SAVING Rooms...")
        f = open("rooms.txt", "w")
        f.write("\n".join(self.roomnames))
        f.close()
          
     ###############
     ### Restart ###
     ###############
      if cmd == "rejoin":
         (lambda x,y: [x.joinRoom(z) for z in y])(self,rooms)
         room.message("Rejoin All Room Sucses")

                                             #########        
                                             ## WEB ##
                                             #########
      if cmd == "web":
        if user.name in netizen:
          room.message("<br/>"'<b>'+user.name+'</b> Commando <f x12FF0000="arial">[<f x12FF5500="arial">W<f x12FFAA00="arial">e<f x12AAFF00="arial">b<f x1255FF00="arial">s<f x1200FF55="arial">i<f x1200FFAA="arial">t<f x1200AAFF="arial">e<f x120055FF="arial">]"'+"<br/>"+" Perintah[ . ] :<br/>ANIME: .webanime, .webanime2 <br/>Manga: .webmanga <br/>Movie: .webmovie",True)
#WEB Anime
      if cmd == "webanime":
        room.message("<f x12F00='1'>Web Anime For Now:<f x12334433='1'><br/>1. Animeku.tv : ak(new update on animeku.tv) , aks(animeku.tv search).<br/>2. Animeindo.id : ainew(new update on animeindo.id), aisr(search).<br/>3. Nontonanime.web.id : nanew(new update on nontonanime.web.id) , nas(nontonanime.web.id search). <br/>4. Animefans.id : afnew(new update on animefans.id) , afsr(animefans.id search), af(direct dl link).<br/>5. Intersub.blogspot.com : ibnew(new update on intersub) , ibsr (itersub search).<br/>6. Narutobleachlover.net : nbnew(new update on narutobleachlover).<br/>7. Kurogoze.top : krnew(new update on kurogaze) , krsr(kurogaze search).<br/>8. Nekonime.com : nknew(new update on nekonime).<br/>9. Animesave.com : asnew(new update on animesave.com) , assr(animesave.com search).<br/>10. Wardhanime.net : wanew(new update on wardhanime) , wasr(wardhanime search).", True)
      if cmd == "webanime2":
        room.message("<b>Web Anime 2 For Now :</b><br/>1. Otanimesama : otnew(new update on otanimesama) , otsr(otanime search).<br/>2. Oploverz.net : opnew(new update on oploverz) , opsr(oploverz search).<br/>3. Fasatsu.com : fsnew(new update on fansatsu) , fssr(search fansatsu movie or anime).<br/>4. Animebaru.net : abnew(new update on animebaru.net) , absr(Animebaru.net search).<br/>5. Meongs.id : msnew(new update on meongs.id) , mssr(meongs.id search).<br/>6. Otakuindo.web.id : oinew(new update), oinew2(new update bagian BD), oisr(search)", True)
#Web Manga
      if cmd == "webmanga":
        room.message("<b>Web Manga For Now :</b><br/>1. Mangapoi.net: mpnew(new update), mpsr(search).<br/>2. Neumanga.tv: nmnew(new update), nmsr(search).<br/>3. Mangakita.net: mknew(new update), mksr(search).<br/>4. Mangaku.web.id: manganew(newupdate).<br/>5. PecintaKomik.com : pknew.", True)
#WEB 17+
      if cmd == "web17+":
          room.message("Cmd for HentaiWeb is:<br/> <b>Khusus.me</b>: khususnew ,khusussr. <br/> <b>Nekopoi</b>: npnew , npsr <br/> <b>Hentaihaven</b>: hhnew.<br/> <b>Dinojav</b>: djnew.",True)
      if cmd == "webbokep":
        room.message("<b>Web Bokep For Now :</b><br/>1. javnew (javabc.net new upodate)", True)
                          #############
########################### WEB Movie #########################################################################################################################################################################################################################################################
#                         #############                                                                                                                                                                                                                                                     ### 
      if cmd == "webmovie":                                                                                                                                                                                                                                                                 ###
        room.message("<f x00CCCC='1'>Web Movie For Now:<f x3366FF='1'><br/>1. Nonton123: n123(new update on nonton123), n123sr(nonton123 Search).<br/>2. Cinemaindo: ci(top 10 movie in cinemaindo), ms(cinemaindo search).<br/>3. Layarkaca21.tv : lknew(new update), lksr(search) ", True)###
###############################################################################################################################################################################################################################################################################################
#                         ##### WEB #####                                                               ###
#                         #### Movie ####                                                               ###
###########################################################################################################
### Nonton123 ###                                                                                       ###
#################                                                                                       ###
      if cmd == "n123":                                                                                 ###
        room.message("<br/><b>Nonton123</b> :<br/>%s" % (newNonton123()), True)                         ###
      if cmd == "n123sr":                                                                               ###
        room.message(serNonton123(args), True)                                                          ###
##################                                                                                      ###
### CinemaIndo ############################################################################################
##################                                                                                      ###
      elif cmd == "cinew":                                                                              ###
             try:                                                                                       ###
              room.message("Newupdate on CinemaIndo.tv: <br/>%s" %(newCi()), True)                      ###
             except: room.message("Fail accessing the web.")                                            ###
      elif cmd == "cisr":                                                                               ###
             try:                                                                                       ###
              room.message("Search result "+args+" on CinemaIndo.tv: <br/>%s" % (serCi(args)), True)    ###
             except: room.message("Not found, I think.")                                                ###
####################                                                                                    ###
### Layar Kaca21 ##########################################################################################
####################                                                                                    ###
      if cmd == "lknew":                                                                                ###
           try:                                                                                         ###
            room.message("<br/><b>Layar Kaca21</b> :<br/>%s" %(newLk()), True)                          ###
           except: room.message("Tidak dapat mengakses Web Layar Kaca21.")                              ###
      if cmd == "lksr":                                                                                 ###
           try:                                                                                         ###
            room.message("Hasil Pencarian "+args+" di Layar Kaca21 : <br/>%s" % (serLk(args)), True)    ###
           except: room.message("File Tidak Ditemukan.")                                                ###
###########################################################################################################

                         ############        
########################### My WEB ##############################
#                        ############                         ###
      if cmd == "myweb":                                      ###
       if self.getAccess(user) >= 2:                          ### 
        room.message("Streaming Lagi-Nime; script website sl")###
      if cmd == "mypartner":                                  ###
       if self.getAccess(user) >= 2:                         ### 
        room.message("MyPartner; script partner",)          ###
######################                                      ###
# BROADCAST NEW POST ##########################################
######################                                      ###
      elif cmd == "sl" and self.getAccess(user) > 3:        ###
          r = room.name                                     ###
          l = "http://ch.besaba.com/mty.htm?"+r+"+"         ###
          for room in self.rooms:                           ###
            room.message("<br/><br/>"+(Slnime_new1()),True) ###
#################                                           ###
# INFO NEW POST ###################################################
#################                                               ###
      if cmd == "slnew":                                        ###
          try:                                                  ###
              room.message(Slnime_new(),True)                   ###
          except:                                               ###
              room.message("Website sedang tidak dapat diakses")###
###################################################################
     # #     # #       # #  PATNER I   # #        # #     # #
      ###   ###        ###################         ###   ###
###################################################################
###                    ###################                      ###
###################### ## ANIME STARTED ##                      ###
# BROADCAST NEW POST ##############################################
######################                                          ###
      elif cmd == "animestarted" and self.getAccess(user) > 1:  ###
          r = room.name                                         ###
          l = "http://ch.besaba.com/mty.htm?"+r+"+"             ###
          for room in self.rooms:                               ############
            room.message("<br/><br/>"+(AllScriptWebsite.anstnew()),True) ###
#################                                               ############
# INFO NEW POST ###################################################
#################                                               ###
      if cmd == "as" or cmd == "asnt":                          ###
          try:                                                  ###
              room.message(AllScriptWebsite.anst(),True)        ###
          except:                                               ###
              room.message("Website sedang tidak dapat diakses")###
###################################################################
     # #     # #       # #  PATNER II  # #        # #     # #
      ###   ###        ###################         ###   ###
###################################################################
###                     #################                       ###
######################   ## Nyan Subs ##                        ###
# BROADCAST NEW POST ##############################################
######################                                          ###
      elif cmd == "nyansubs" and self.getAccess(user) > 1:      ###
          r = room.name                                         ###
          l = "http://ch.besaba.com/mty.htm?"+r+"+"             ###
          for room in self.rooms:                               ################
            room.message("<br/><br/>"+(AllScriptWebsite.nyansubsnew()),True) ###
#################                                               ################
# INFO NEW POST ###################################################
#################                                               ###
      if cmd == "nyans":                                        ###
          try:                                                  ###
              room.message(AllScriptWebsite.nyansubs(),True)    ###
          except:                                               ###
              room.message("Website sedang tidak dapat diakses")###
###################################################################
#################                                               ################
# INFO NEW POST ###################################################
#################                                               ###
      if cmd == "kr" and self.getAccess(user) > 3:                                        ###
          try:                                                  ###
              room.message(AllScriptWebsite.KoreNime(),True)    ###
          except:                                               ###
              room.message("Website sedang tidak dapat diakses")###
###################################################################
#################                                               ################
# INFO NEW POST ###################################################
#################                                               ###
      if cmd == "moe" and self.getAccess(user) > 3:              ###
          try:                                                  ###
              room.message(AllScriptWebsite.MoeNime(),True)    ###
          except:                                               ###
              room.message("Website sedang tidak dapat diakses")###
###################################################################
     # #     # #       # #  PATNER III # #        # #     # #
      ###   ###        ###################         ###   ###
###################################################################
###                     #################                       ###
######################  ### Kuro Gaze ###                       ###
# BROADCAST NEW POST ##############################################
######################                                          ###
      elif cmd == "kurogazenew" and self.getAccess(user) > 2:   ###
          r = room.name                                         ###
          l = "http://ch.besaba.com/mty.htm?"+r+"+"             ###
          for room in self.rooms:                               ################
            room.message("<br/><br/>"+(AllScriptWebsite.kurogazenew()),True) ###
#################                                               ################
# INFO NEW POST ###################################################
#################                                               ###
      if cmd == "kurogaze":                                     ###
          try:                                                  ###
              room.message(AllScriptWebsite.kurogaze(),True)    ###
          except:                                               ###
              room.message("Website sedang tidak dapat diakses")###
###################################################################
     # #     # #       # #  PATNER IV  # #        # #     # #
      ###   ###        ###################         ###   ###
#####################################################################
###                    ###################                        ###
###################### ## PENCURI ANIME ##                        ###
# BROADCAST NEW POST ################################################
######################                                            ###
      elif cmd == "pencurianime" and self.getAccess(user) > 1:    ###
          r = room.name                                           ###
          l = "http://ch.besaba.com/mty.htm?"+r+"+"               ###
          for room in self.rooms:                                 ##################
            room.message("<br/><br/>"+(AllScriptWebsite.pencurianimenew()),True) ###
#################                                                 ##################
# INFO NEW POST #####################################################
#################                                                 ###
      if cmd == "pa":                                             ###
          try:                                                    ###
              room.message(AllScriptWebsite.pencurianime()(),True)###
          except:                                                 ###
              room.message("web downs")                           ###
#####################################################################

##############
##### WEB ####
##### 17+ ####
##############
### Khusus ###
      if cmd == "khususnew":
        room.message(newKhusus(), True)
      if cmd == "khusussr":
        room.message(serKhusus(args), True)
### JAV ###
      if cmd == "javsr":
        room.message(serJava(args), True)
      if cmd == "javnew":
        room.message(newJava(), True)
### Nekopoi ###
      elif cmd == "npnew":
             try:
              room.message("New Update on Nekopoi.moe: <br/>%s" % (newNp()), True)                      
             except: room.message("Fail accessing the web.")
      if cmd == "npsr":
             try:
              room.message("Search Result <b>"+args+"</b> On Nekopoi.moe: <br/>%s" % (serNp(args)), True)                      
             except: room.message("No Result")
### Hentai ###
      if cmd == "hhnew":
        room.message(newHh(), True)
      if cmd == "hsnew":
        room.message(newHs(), True)            
### Dinojav ###
      if cmd == "djnew":
        room.message(newDj(), True)
### Web WIBU ###
      if cmd == "wibunews":
        room.message("<f x00CCCC='1'>Wibunews.com Command:<br/><b>wibunew</b>(newupdate).<br/><b>wibusr</b>(search).", True)
      if cmd == "wibunew":
        room.message(newWibu(), True)                         
      if cmd == "wibusr":
             try:
              room.message("Search Result <b>"+args+"</b> In Wibunews.com: <br/>%s" % (serWibu(args)), True)
             except: room.message("No Result")
### AsiaIndo ###
      if cmd == "asindoinfo":
        room.message(AsindoInfo(args), True)
      if cmd == "asindonew":
        room.message(newAsindo(), True)
      if cmd == "asindosr":
        room.message(serAsindo(args), True)
### RintoBlog ###
      if cmd == "rintoblog":
        room.message("<f x00CCCC='1'>Command:<br/><b>irnew</b>(newupdate).<br/><b>irsr</b>(search).", True)
      if cmd == "irsr":
             try:
              room.message("Search Result <b>"+args+"</b> In RintoBlog: <br/>%s" % (serIr(args)), True)                      
             except: room.message("No Result")
      elif cmd == "irnew":
             try:
              room.message("New Update on RintoBlog: <br/>%s" % (newIr()), True)                      
             except: room.message("Fail accessing the web.")
### JalanTikus ###
      if cmd == "jalantikus":
            room.message("<b>Jalantikus.com:</b><br/>1. jtnew(berita naik daun terbaru).<br/>2. jtnew2(new tip).<br/>3. jtnew3(berita hangat).<br/>4. jtnew4(kgk tw gw :'v).<br/>5. jtnew5(berita gokil).<br/>6. jtnew6(berita gadget).<br/>7. jtnew7(tech new).<br/>8. jtsr(Search)", True)
      if cmd == "jtsr":
             try:
              room.message("Search Result <b>"+args+"</b> In Jalantikus.Com: <br/>%s" % (serJt(args)), True)                      
             except: room.message("No Result")
      elif cmd == "jtnew":
             try:
              room.message("Berita Naik Daun Di Jalantikus.com: <br/>%s" % (newJt()), True)
             except: room.message("Fail accessing the web.")
      elif cmd == "jtnew2":
             try:
              room.message("New Tips Di Jalantikus.com: <br/>%s" % (newJt2()), True)                      
             except: room.message("Fail accessing the web.")
      elif cmd == "jtnew3":
             try:
              room.message("Berita Hangat Di Jalantikus.com: <br/>%s" % (newJt3()), True)
             except: room.message("Fail accessing the web.")
      elif cmd == "jtnew4":
             try:
              room.message("Kamu Pasti Bisa: <br/>%s" % (newJt4()), True)                      
             except: room.message("Fail accessing the web.")
      elif cmd == "jtnew5":
             try:
              room.message("Berita Gokil Di Jalantikus.com: <br/>%s" % (newJt5()), True)                      
             except: room.message("Fail accessing the web.")
      elif cmd == "jtnew6":
             try:
              room.message("Berita Gadget Di Jalantikus.com: <br/>%s" % (newJt6()), True)
             except: room.message("Fail accessing the web.")
      elif cmd == "jtnew7":
             try:
              room.message("Berita Tech Terbaru Di Jalantikus.com: <br/>%s" % (newJt7()), True)
             except: room.message("Fail accessing the web.")

      if cmd == "joinew":
        room.message(newJoi(), True)
      if cmd == "gannew":
        room.message(newGa(), True)
      if cmd == "t1new":
        room.message(newT1(), True)
      if cmd == "ennew":
        room.message(newEn(), True)
                 
      #Direct Download
      if cmd == "d":
          if args:
            room.message("http://aparecera-hoax.rhcloud.com/direct/%s" % (args))
          else:
            room.message("Supports: TS, MP4, Sf, Ace ex type *d <Link Embed Maneh>")
                    
      if cmd == "d2":
          if args:
            room.message("http://aparecera-hoax.rhcloud.com/direct/%s" % (args))
                    
          else:room.message("Supports: TS, MP4, Sf, Ace ex type *d2 <Link Embed Maneh>")

      if cmd =="autovisitorblog" or cmd =="avb":
                 room.message("Please Visit This Blog http://openshift1.blogspot.com/ For Get Auto Visitor Blog")
          
                                             ###############
                                             ## User List ##
                                             ###############

      elif cmd == "userlist" or cmd == "ul":
         if args == "":
          usrs = []
          gay = []
          finale = []
          prop = 0
          prop = prop + len(room._userlist) - 1
          for i in room._userlist:
            i = str(i)
            usrs.append(i)
          while prop >= 0:
            j = usrs[prop].replace("<User: ", "")
            i = j.replace(">", "")
            gay.append(i)
            prop = prop - 1
          for i in gay:
            if i not in finale:
              finale.append(i)
          if len(finale) > 40:
            room.message("<font color='#9999FF'><b>40</b></font> of <b>%s</b> users in this room: %s"% (len(finale), ", ".join(finale[:41])), True)
          if len(finale) <=40 :
            room.message("Current <b>%s</b> users of this room: %s"% (len(finale),", ".join(finale)), True)
         if args != "":
           if args not in self.roomnames:
             room.message("I'm not there.")
             return
           users = getParticipant(str(args))
           if len(users) > 40:
             room.message("<font color='#9999FF'><b>40</b></font> of <b>%s</b> current users in <b>%s</b>: %s"% (len(users), args.title(), ", ".join(users[:41])), True)
           if len(users) <=40:
             room.message("Current <b>%s</b> users in <b>%s</b>: %s"% (len(users), args.title(), ", ".join(users)), True) 
          
                                             ###############
                                             ## Bot rooms ##
                                             ###############

      elif cmd == "rooms" : 
        j = [] 
        for i in self.roomnames: 
          j.append(i+'[%s]' % str(self.getRoom(i).usercount)) 
          j.sort() 
        room.message("Freya sedang berada di "+'[%s] rooms: '%(len(self.roomnames))+", ".join(j))
          
                                             ##########
                                             ## Mods ##
                                             ##########

      elif cmd == "mods":
          args = args.lower()
          if args == "":
            room.message("<font color='#ffffff'><b>Room</b>: "+room.name+" <br/><b>Owner</b>: <u>"+ (room.ownername) +"</u> <br/><b>Mods</b>: "+", ".join(room.modnames), True)
            return
          if args in self.roomnames:
              modask = self.getRoom(args).modnames
              owner = self.getRoom(args).ownername
              room.message("<font color='#ffffff'><b>Room</b>: "+args+" <br/><b>Owner</b>: <u>"+ (owner) +"</u> <br/><b>Mods</b>: "+", ".join(modask), True)
            
                                             ###########
                                             ## Dance ##
                                             ###########

        #Dance ? Of Course !!! ^_^
      elif cmd == "dance":
        for i, msg in enumerate(dancemoves):
          self.setTimeout(i / 2, room.message, msg)
      elif cmd == "song":
       if room.name == "rikoaizi":
        for i, msg in enumerate(song):
          self.setTimeout(i / 10, room.message, msg)
            
                                             ###############
                                             ## MultiChat ##
                                             ###############

      if cmd == "multichat" or cmd == "mc" or cmd == "mch":
          if args == (""):
            room.message("Nama Rooms yang inginkan ?. Contoh : .mch kurogaze, rikoaizi")
          else:
            room.message("http://"+args+".chatango.com/")

      if cmd == "multiroom" or cmd == "mr" or cmd == "mro":
        room.message("http://id.multichat.ml/")
        
                                             ##########
                                             ## Nick ##
                                             ##########

      elif cmd == "nick":
        # if user.name in reg or user.name in friends or user.name in trusted or user.name in owners:
            if args:
                nick = args 
                user = user.name 
                nicks[user] = json.dumps(nick)
                room.message(user +' Baiklah, kamu sekarang Freya panggil '+str(args)+'', True)
                try: 
                    print("[SAVING] NICKS...")
                    f = open("nicks.txt", "w")
                    for user in nicks:
                        nick = json.loads(nicks[user])
                        f.write(json.dumps([user,nick]) + "\n")
                except:
                       room.message("Gagal membuat Nama baru..");return
            else:
              room.message('Ketik .nick <spasi> nama yang di inginkan', True)
          
                                             ############
                                             ## MyNick ##
                                             ############

      elif cmd == "mynick" :
          user=user.name.lower()
          if user in nicks :
            nick = json.loads(nicks[user])
            room.message(user+" is nicked : "+nick,True)
          else:
            room.message("Belum membuat Nick di saya :D ", True)
          
                                             ##########
                                             ## MyIP ##
                                             ##########

      if cmd =="myip" or cmd == "MyIp" or cmd == "MyIP" or cmd == "My IP Adress":
        try:
         room.message("I.P. address kamu adalah : "+message.ip)
             
        except:
         room.message("IP lookup failed , bot is not a mod in this chat.")

   except Exception as e:
      try:
        et, ev, tb = sys.exc_info()
        lineno = tb.tb_lineno
        fn = tb.tb_frame.f_code.co_filename
        room.message("[Expectation Failed] %s Line %i - %s"% (fn, lineno, str(e)))
        return
      except:
        room.message("Undescribeable error detected !!")
        return

                                             ########$##
                                             ## SeeIP ##
                                             ########$##

      if cmd == "seeip" or cmd == "sip":
          args = args.lower()
          if args[0] == "+":
            args = args[1:]
          elif pars(args) != None and not args[0] == "+":
            args = pars(args)
          try:
            ##IPloc try
            ip_whois = dict()
            try:
              f = open("ip_whois.txt", "r")
              ip_whois = eval(f.read())
              f.close()
            except:pass
            inf = []
            ip_info = os.popen("curl ipinfo.io/%s"% ip_whois[args]).read()
            for i in ip_info:
              if len(i.strip())>0: inf.append(i.strip())
            room.message("<br/>".join(inf), True)
          except:
            room.message("Seek progress terminated.")

      #### LoveMeter
      if cmd == "lm" or cmd == "lovemeter" and not user.name in blacklist and not room.name in deathroom:
        try:
          nama1, nama2 = args.split(" ", 1)
          persen=["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58","59","60","61","62","63","64","65","66","67","68","69","70","71","72","73","74","75","76","77","78","79","80","81","82","83","84","85","86","87","88","89","90","91","92","93","94","95","96","97","98","99","100"]
          hasil=random.choice(persen)
          hasil=int(hasil)
          if nama2 =="":room.message(user.name+"@ type ;lm (name1)<space>(name2)");return
          if hasil == 0:
            room.message(" Love Meter "+nama1+" with "+nama2+" = %s"% hasil+"% | Nothing! Jones forever :P")
          if hasil < 50:
            room.message(" Love Meter "+nama1+" with "+nama2+" = %s"% hasil+"% | Frindzoned!")
          if hasil > 49 and hasil < 60:
            room.message(user.name+"@ Love Meter "+nama1+" with "+nama2+" = %s"% hasil+"% | Good!")
          if hasil > 59 and hasil < 100:
             room.message(" Love Meter "+nama1+" with "+nama2+" = %s"% hasil+"% | I'm jealous *rolleyes*")
          if hasil == 100 :
            room.message(" Love Meter "+nama1+" with "+nama2+" = %s"% hasil+"% | Wohg Great! Unbelievable!")
        except:room.message(" type =lm (name1)<space>(name2)")

               


  ##Other Crap here, Dont worry about it
  
  def check(self, room):
         try:
            feed = feedparser.parse('http://korenime.org/feed/atom')
            xml = feed.entries[0]
            lastupdated = xml['updated']
            time.sleep(1)
            feed = feedparser.parse('http://korenime.org/feed/atom')
            xml = feed.entries[0]
            updated = xml['updated']
            author = xml['author']
            title = xml['title']
            link = xml['id']
            if not (lastupdated == updated):
                print("New update on Korenime.org")
                mesg = ' published a new post named: '
                room.message(author + mesg + '"' + title + '"' + ' Link: ' + link)
            else:
                print("No new feed update on Korenime.org")
         except:
             print("Error")
  
  def onFloodWarning(self, room):
    room.reconnect()

  def onRestart(self, room):
    room.connect()
  
  def onJoin(self, room, user):
   print("[Join] "+user.name + " telah bergabung kedalam voice chat!")
  
  def onLeave(self, room, user):
   print("[Leave] "+user.name + " telah meninggalkan voice chat!")
    

        

if __name__ == "__main__":
  TestBot.easy_start(rooms, botname, password)

